// WARNING
//
// This file has been generated automatically by Visual Studio from the outlets and
// actions declared in your storyboard file.
// Manual changes to this file will not be maintained.
//
using Foundation;
using System;
using System.CodeDom.Compiler;
using UIKit;

namespace WELS.App.IOS
{
    [Register ("QuizController")]
    partial class QuizController
    {
        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UIButton btnCheckAnswer { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UIButton btnContinue { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UILabel lblResponse { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UIView vwCheckAnswer { get; set; }

        void ReleaseDesignerOutlets ()
        {
            if (btnCheckAnswer != null) {
                btnCheckAnswer.Dispose ();
                btnCheckAnswer = null;
            }

            if (btnContinue != null) {
                btnContinue.Dispose ();
                btnContinue = null;
            }

            if (lblResponse != null) {
                lblResponse.Dispose ();
                lblResponse = null;
            }

            if (vwCheckAnswer != null) {
                vwCheckAnswer.Dispose ();
                vwCheckAnswer = null;
            }
        }
    }
}