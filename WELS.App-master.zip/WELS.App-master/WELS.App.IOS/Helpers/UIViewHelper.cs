﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Foundation;
using UIKit;

namespace WELS.App.IOS.Helpers
{
    public class UIViewHelper
    {
        public static UIImage FromUrl(string uri)
        {
            if (string.IsNullOrEmpty(uri)) return null;
            using (var url = new NSUrl(uri))
            using (var data = NSData.FromUrl(url))
                return data == null ? null : UIImage.LoadFromData(data);
        }
    }
}