using CoreGraphics;
using Foundation;
using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.ComponentModel;
using System.Linq;
using System.Reflection;
using System.Threading.Tasks;
using UIKit;
using WELS.App.IOS.Controls;
using WELS.App.Shared.Data;

namespace WELS.App.IOS
{
    public partial class QuizController : UIViewController
    {
        public int CourseID { get; set; }
        public int LessonID { get; set; }
        Course _course { get; set; }
        Lesson _lesson { get; set; }
        private int? _currentQuestionIndex;
        private Question _currentQuestion;

        private const int topPadding = 48;
        private const int leftRightPadding = 24;
        private EventHandler handler;
        private UIScrollView vwScrollView;
        public QuizController (IntPtr handle) : base (handle)
        {
        }

        public async override void ViewDidLoad()
        {
            base.ViewDidLoad();

            Localize();

            // Hide keyboard on tap outside of textbox
            var g = new UITapGestureRecognizer(() => View.EndEditing(true));
            g.CancelsTouchesInView = false; //for iOS5
            View.AddGestureRecognizer(g);

            // Load course and lesson (assumes the IDs were instantiated
            _course = AppDelegate.Courses.FirstOrDefault(c => c.CourseNodeID == CourseID);
            _lesson = _course.Lessons.FirstOrDefault(c => c.LessonNodeID == LessonID);

            // HACK: Assume they watched the video if they started the quiz
            if (_lesson != null && _lesson.DateWatchedVideo == null)
            {
                _lesson.DateWatchedVideo = DateTime.UtcNow;
                await AppDelegate.DataHelper.SaveData(_lesson, AppDelegate.CurrentAccount);
            }

            btnContinue.TouchUpInside += async (sender, e) =>
            {
                await NextQuestion();
            };

            await NextQuestion();
        }

        private void Localize()
        {
            btnContinue.SetTitle(AppDelegate.BundleToUse.GetLocalizedString("quiz_continue"), UIControlState.Normal);
            btnCheckAnswer.SetTitle(AppDelegate.BundleToUse.GetLocalizedString("quiz_check_answer"), UIControlState.Normal);
        }

        public async Task NextQuestion()
        {
            // Clear the previous question
            if (vwScrollView != null)
            { 
                vwScrollView.RemoveFromSuperview();
            }

            // Remove any current event handler
            if (handler != null)
            {
                btnCheckAnswer.TouchUpInside -= handler;
            }

            //switch (questionIndex)
            //{
            //    case 0:
            //        BuildMultipleChoiceQuestion();
            //        break;
            //    case 1:
            //        BuildEssayQuestion();
            //        break;
            //    case 2:
            //        BuildCheckboxQuestion();
            //        break;
            //}

            if (_currentQuestionIndex == null)
            {
                _currentQuestionIndex = 0;
            }
            else
            {
                _currentQuestionIndex = _currentQuestionIndex + 1;
            }

            // HACK: If there are no lessons in this course, don't crash.  Just mark the course completed and return.
            if (_lesson == null)
            {
                _course.DateCompleted = DateTime.UtcNow;
                await AppDelegate.DataHelper.SaveData(_course, AppDelegate.CurrentAccount);

                PerformSegue("QuizEndSegue", this);
            }
            // If we've reached the last question, save lesson completion dates and go back to the course fragment
            else if (_currentQuestionIndex >= _lesson.Questions.Count)
            {
                foreach (var item in _lesson.LessonItems)
                {
                    item.DateCompleted = DateTime.UtcNow;
                    await AppDelegate.DataHelper.SaveData(item, AppDelegate.CurrentAccount);
                }
                _lesson.DateCompletedAllLessonItems = DateTime.UtcNow;
                _lesson.DateCompletedQuiz = DateTime.UtcNow;
                await AppDelegate.DataHelper.SaveData(_lesson, AppDelegate.CurrentAccount);

                // If all lessons are complete, set completion date on this course
                if (!_course.Lessons.Any(l => l.DateCompletedAllLessonItems == null))
                {
                    _course.DateCompleted = DateTime.UtcNow;
                    await AppDelegate.DataHelper.SaveData(_course, AppDelegate.CurrentAccount);
                }

                PerformSegue("QuizEndSegue", this);
            }
            else
            {
                // Move on to the next question
                _currentQuestion = _lesson.Questions.Skip(_currentQuestionIndex.Value).FirstOrDefault();

                var quizGroups = new List<string>();
                if (_currentQuestion.IsEvaluate) quizGroups.Add(AppDelegate.BundleToUse.GetLocalizedString("quiz_grouping_evaluate"));
                if (_currentQuestion.IsLearn) quizGroups.Add(AppDelegate.BundleToUse.GetLocalizedString("quiz_grouping_learn"));
                if (quizGroups.Any())
                {
                    
                }
                switch (_currentQuestion.Type)
                {
                    case Constants.QuestionType.Essay:
                        BuildEssayQuestion();
                        break;
                    case Constants.QuestionType.MultipleChoice:
                        BuildMultipleChoiceQuestion();
                        break;
                    case Constants.QuestionType.Checkbox:
                        BuildCheckboxQuestion();
                        break;
                }
            }
        }

        private void BuildMultipleChoiceQuestion()
        {
            btnCheckAnswer.Hidden = false;
            btnContinue.Hidden = true;
            lblResponse.Hidden = true;

            var lblHeader = new UILabel() { TranslatesAutoresizingMaskIntoConstraints = false };
            var lblQuestion = new UILabel() { TranslatesAutoresizingMaskIntoConstraints = false };

            var spacing = 24;

            vwScrollView = new UIScrollView() { TranslatesAutoresizingMaskIntoConstraints = false };
            this.View.Add(vwScrollView);
            vwScrollView.TopAnchor.ConstraintEqualTo(this.View.TopAnchor, 0).Active = true;
            vwScrollView.BottomAnchor.ConstraintEqualTo(vwCheckAnswer.TopAnchor, 0).Active = true;
            vwScrollView.LeadingAnchor.ConstraintEqualTo(this.View.LeadingAnchor, 0).Active = true;
            vwScrollView.TrailingAnchor.ConstraintEqualTo(this.View.TrailingAnchor, 0).Active = true;
            //vwScrollView.Layer.BackgroundColor = UIColor.Yellow.CGColor;

            // Create the content view
            var vwContent = new UIView() { TranslatesAutoresizingMaskIntoConstraints = false };
            //vwContent.Layer.BackgroundColor = UIColor.Red.CGColor;
            vwScrollView.Add(vwContent);
            vwContent.WidthAnchor.ConstraintEqualTo(vwScrollView.WidthAnchor).Active = true;
            //vwContent.HeightAnchor.ConstraintEqualTo(2000).Active = true;
            vwContent.TopAnchor.ConstraintEqualTo(vwScrollView.TopAnchor, 0).Active = true;
            vwContent.BottomAnchor.ConstraintEqualTo(vwScrollView.BottomAnchor, 0).Active = true;
            vwContent.LeadingAnchor.ConstraintEqualTo(vwScrollView.LeadingAnchor, 0).Active = true;
            vwContent.TrailingAnchor.ConstraintEqualTo(vwScrollView.TrailingAnchor, 0).Active = true;

            lblHeader.Text = AppDelegate.BundleToUse.GetLocalizedString("quiz_heading");
            lblHeader.Font = UIFont.SystemFontOfSize(20, UIFontWeight.Bold);
            lblHeader.TextAlignment = UITextAlignment.Left;
            lblHeader.LineBreakMode = UILineBreakMode.WordWrap;
            lblHeader.Lines = 0;
            vwContent.Add(lblHeader);
            lblHeader.TopAnchor.ConstraintEqualTo(vwContent.TopAnchor, topPadding).Active = true;
            lblHeader.LeadingAnchor.ConstraintEqualTo(vwContent.LeadingAnchor, spacing).Active = true;
            lblHeader.TrailingAnchor.ConstraintEqualTo(vwContent.TrailingAnchor, -spacing).Active = true;

            lblQuestion.Text = _currentQuestion.QuestionText;
            lblQuestion.Font = UIFont.SystemFontOfSize(17, UIFontWeight.Bold);
            lblQuestion.TextAlignment = UITextAlignment.Left;
            lblQuestion.LineBreakMode = UILineBreakMode.WordWrap;
            lblQuestion.Lines = 0;
            vwContent.Add(lblQuestion);
            lblQuestion.TopAnchor.ConstraintEqualTo(lblHeader.BottomAnchor, spacing).Active = true;
            lblQuestion.LeadingAnchor.ConstraintEqualTo(vwContent.LeadingAnchor, spacing).Active = true;
            lblQuestion.TrailingAnchor.ConstraintEqualTo(vwContent.TrailingAnchor, -spacing).Active = true;

            // Add multiple choice answers here
            var options = new List<KeyValuePair<string, string>>();

            char answerNumber = 'A';
            char correctAnswer = 'A';
            foreach (var answer in _currentQuestion.Answers)
            {
                options.Add(new KeyValuePair<string, string>(answerNumber.ToString(), answerNumber + ". " + answer.AnswerText));
                if (answer.IsCorrectAnswer) correctAnswer = answerNumber;
                answerNumber++;
            }

            var radioGroup = new RadioButtonGroup(options, spacing) { TranslatesAutoresizingMaskIntoConstraints = false };
            vwContent.Add(radioGroup);
            radioGroup.TopAnchor.ConstraintEqualTo(lblQuestion.BottomAnchor, spacing).Active = true;
            radioGroup.LeadingAnchor.ConstraintEqualTo(vwContent.LeadingAnchor, spacing).Active = true;
            radioGroup.TrailingAnchor.ConstraintEqualTo(vwContent.TrailingAnchor, -spacing).Active = true;
            radioGroup.BottomAnchor.ConstraintEqualTo(vwContent.BottomAnchor, 0).Active = true;

            handler = (sender, e) =>
            {
                if (radioGroup.SelectedItem == null)
                {
                    var alert = UIAlertController.Create("", AppDelegate.BundleToUse.GetLocalizedString("quiz_no_answer_selected"), UIAlertControllerStyle.Alert);
                    alert.AddAction(UIAlertAction.Create("OK", UIAlertActionStyle.Default, null));
                    PresentViewController(alert, true, null);
                }
                else
                {
                    // If we have the correct answer
                    if (radioGroup.SelectedItem.Value == correctAnswer.ToString())
                    {
                        radioGroup.SelectedItem.BackgroundColor = UIColor.FromRGB(223, 236, 222);
                        vwCheckAnswer.BackgroundColor = UIColor.FromRGB(49, 135, 45);
                        lblResponse.Text = AppDelegate.BundleToUse.GetLocalizedString("quiz_correct");
                    }
                    // we do not have the correct answer
                    else
                    {
                        radioGroup.SelectedItem.BackgroundColor = UIColor.FromRGB(239, 238, 237);
                        // Highlight the correct answer
                        foreach (var radio in radioGroup.RadioButtonItems)
                        {
                            if (radio.Value == correctAnswer.ToString())
                            {
                                radio.BackgroundColor = UIColor.FromRGB(223, 236, 222);
                            }
                        }
                        vwCheckAnswer.BackgroundColor = UIColor.FromRGB(78, 78, 78);
                        lblResponse.Text = string.Format(AppDelegate.BundleToUse.GetLocalizedString("quiz_incorrect"), correctAnswer);
                    }

                    // Hide the blue button and show the continue button
                    btnCheckAnswer.Hidden = true;
                    btnContinue.Hidden = false;
                    lblResponse.Hidden = false;
                }
            };

            btnCheckAnswer.TouchUpInside += handler;
        }

        private void BuildEssayQuestion()
        {
            btnCheckAnswer.Hidden = false;
            btnContinue.Hidden = true;
            lblResponse.Hidden = true;

            vwScrollView = new UIScrollView() { TranslatesAutoresizingMaskIntoConstraints = false };
            this.View.Add(vwScrollView);
            vwScrollView.TopAnchor.ConstraintEqualTo(this.View.TopAnchor, 0).Active = true;
            vwScrollView.BottomAnchor.ConstraintEqualTo(vwCheckAnswer.TopAnchor, 0).Active = true;
            vwScrollView.LeadingAnchor.ConstraintEqualTo(this.View.LeadingAnchor, 0).Active = true;
            vwScrollView.TrailingAnchor.ConstraintEqualTo(this.View.TrailingAnchor, 0).Active = true;
            //vwScrollView.Layer.BackgroundColor = UIColor.Yellow.CGColor;

            // Create the content view
            var vwContent = new UIView() { TranslatesAutoresizingMaskIntoConstraints = false };
            //vwContent.Layer.BackgroundColor = UIColor.Red.CGColor;
            vwScrollView.Add(vwContent);
            vwContent.WidthAnchor.ConstraintEqualTo(vwScrollView.WidthAnchor).Active = true;
            //vwContent.HeightAnchor.ConstraintEqualTo(2000).Active = true;
            vwContent.TopAnchor.ConstraintEqualTo(vwScrollView.TopAnchor, 0).Active = true;
            vwContent.BottomAnchor.ConstraintEqualTo(vwScrollView.BottomAnchor, 0).Active = true;
            vwContent.LeadingAnchor.ConstraintEqualTo(vwScrollView.LeadingAnchor, 0).Active = true;
            vwContent.TrailingAnchor.ConstraintEqualTo(vwScrollView.TrailingAnchor, 0).Active = true;

            var lblHeader = new UILabel() { TranslatesAutoresizingMaskIntoConstraints = false };
            var lblQuestion = new UILabel() { TranslatesAutoresizingMaskIntoConstraints = false };
            var lblAnswerHeader = new UILabel() { TranslatesAutoresizingMaskIntoConstraints = false };
            var txtAnswer = new UITextView() { TranslatesAutoresizingMaskIntoConstraints = false };
            var lblOurAnswerHeader = new UILabel() { TranslatesAutoresizingMaskIntoConstraints = false };
            var lblOurAnswer = new UILabel() { TranslatesAutoresizingMaskIntoConstraints = false };

            var spacing = 24;

            lblHeader.Text = AppDelegate.BundleToUse.GetLocalizedString("quiz_heading");
            lblHeader.Font = UIFont.SystemFontOfSize(20, UIFontWeight.Bold);
            lblHeader.TextAlignment = UITextAlignment.Left;
            lblHeader.LineBreakMode = UILineBreakMode.WordWrap;
            lblHeader.Lines = 0;
            vwContent.Add(lblHeader);
            lblHeader.TopAnchor.ConstraintEqualTo(vwContent.TopAnchor, topPadding).Active = true;
            lblHeader.LeadingAnchor.ConstraintEqualTo(vwContent.LeadingAnchor, spacing).Active = true;
            lblHeader.TrailingAnchor.ConstraintEqualTo(vwContent.TrailingAnchor, -spacing).Active = true;

            lblQuestion.Text = _currentQuestion.QuestionText;
            lblQuestion.Font = UIFont.SystemFontOfSize(17, UIFontWeight.Bold);
            lblQuestion.TextAlignment = UITextAlignment.Left;
            lblQuestion.LineBreakMode = UILineBreakMode.WordWrap;
            lblQuestion.Lines = 0;
            vwContent.Add(lblQuestion);
            lblQuestion.TopAnchor.ConstraintEqualTo(lblHeader.BottomAnchor, spacing).Active = true;
            lblQuestion.LeadingAnchor.ConstraintEqualTo(vwContent.LeadingAnchor, spacing).Active = true;
            lblQuestion.TrailingAnchor.ConstraintEqualTo(vwContent.TrailingAnchor, -spacing).Active = true;

            lblAnswerHeader.Text = "";
            lblAnswerHeader.Font = UIFont.SystemFontOfSize(17, UIFontWeight.Bold);
            lblAnswerHeader.TextAlignment = UITextAlignment.Left;
            lblAnswerHeader.LineBreakMode = UILineBreakMode.WordWrap;
            lblAnswerHeader.Lines = 0;
            vwContent.Add(lblAnswerHeader);
            lblAnswerHeader.TopAnchor.ConstraintEqualTo(lblQuestion.BottomAnchor, spacing).Active = true;
            lblAnswerHeader.LeadingAnchor.ConstraintEqualTo(vwContent.LeadingAnchor, spacing).Active = true;
            lblAnswerHeader.TrailingAnchor.ConstraintEqualTo(vwContent.TrailingAnchor, -spacing).Active = true;

            txtAnswer.TextAlignment = UITextAlignment.Left;
            txtAnswer.Layer.BorderWidth = 1;
            txtAnswer.Layer.BorderColor = UIColor.Black.CGColor;
            txtAnswer.BackgroundColor = UIColor.FromRGB(239, 238, 237);
            vwContent.Add(txtAnswer);
            txtAnswer.TopAnchor.ConstraintEqualTo(lblAnswerHeader.BottomAnchor, spacing).Active = true;
            txtAnswer.LeadingAnchor.ConstraintEqualTo(vwContent.LeadingAnchor, spacing).Active = true;
            txtAnswer.TrailingAnchor.ConstraintEqualTo(vwContent.TrailingAnchor, -spacing).Active = true;
            txtAnswer.HeightAnchor.ConstraintEqualTo(200).Active = true;

            lblOurAnswerHeader.Text = "";
            lblOurAnswerHeader.Font = UIFont.SystemFontOfSize(17, UIFontWeight.Bold);
            lblOurAnswerHeader.TextAlignment = UITextAlignment.Left;
            lblOurAnswerHeader.LineBreakMode = UILineBreakMode.WordWrap;
            lblOurAnswerHeader.Lines = 0;
            vwContent.Add(lblOurAnswerHeader);
            lblOurAnswerHeader.TopAnchor.ConstraintEqualTo(txtAnswer.BottomAnchor, spacing).Active = true;
            lblOurAnswerHeader.LeadingAnchor.ConstraintEqualTo(vwContent.LeadingAnchor, spacing).Active = true;
            lblOurAnswerHeader.TrailingAnchor.ConstraintEqualTo(vwContent.TrailingAnchor, -spacing).Active = true;

            lblOurAnswer.Text = "";
            lblOurAnswer.TextAlignment = UITextAlignment.Left;
            lblOurAnswer.LineBreakMode = UILineBreakMode.WordWrap;
            lblOurAnswer.Lines = 0;
            vwContent.Add(lblOurAnswer);
            lblOurAnswer.TopAnchor.ConstraintEqualTo(lblOurAnswerHeader.BottomAnchor, spacing).Active = true;
            lblOurAnswer.LeadingAnchor.ConstraintEqualTo(vwContent.LeadingAnchor, spacing).Active = true;
            lblOurAnswer.TrailingAnchor.ConstraintEqualTo(vwContent.TrailingAnchor, -spacing).Active = true;
            lblOurAnswer.BottomAnchor.ConstraintEqualTo(vwContent.BottomAnchor).Active = true;

            handler = (sender, e) =>
            {
                txtAnswer.Hidden = true;
                lblAnswerHeader.Text = AppDelegate.BundleToUse.GetLocalizedString("quiz_your_answer");
                lblAnswerHeader.SizeToFit();
                lblOurAnswerHeader.Text = AppDelegate.BundleToUse.GetLocalizedString("quiz_our_answer");
                lblOurAnswerHeader.SizeToFit();
                lblOurAnswer.Text = _currentQuestion.TeacherAnswer;
                lblOurAnswer.SizeToFit();

                var lblAnswer = new UILabel() { TranslatesAutoresizingMaskIntoConstraints = false };
                lblAnswer.TextAlignment = UITextAlignment.Left;
                lblAnswer.LineBreakMode = UILineBreakMode.WordWrap;
                lblAnswer.Lines = 0;
                lblAnswer.Text = txtAnswer.Text;
                vwContent.Add(lblAnswer);
                lblAnswer.TopAnchor.ConstraintEqualTo(lblAnswerHeader.BottomAnchor, spacing).Active = true;
                lblAnswer.LeadingAnchor.ConstraintEqualTo(vwContent.LeadingAnchor, spacing).Active = true;
                lblAnswer.TrailingAnchor.ConstraintEqualTo(vwContent.TrailingAnchor, -spacing).Active = true;

                // Hide the blue button and show the continue button
                btnCheckAnswer.Hidden = true;
                btnContinue.Hidden = false;
                lblResponse.Hidden = true;
            };

            btnCheckAnswer.TouchUpInside += handler;
        }
        private void BuildCheckboxQuestion()
        {
            btnCheckAnswer.Hidden = false;
            btnContinue.Hidden = true;
            lblResponse.Hidden = true;

            vwScrollView = new UIScrollView() { TranslatesAutoresizingMaskIntoConstraints = false };
            this.View.Add(vwScrollView);
            vwScrollView.TopAnchor.ConstraintEqualTo(this.View.TopAnchor, 0).Active = true;
            vwScrollView.BottomAnchor.ConstraintEqualTo(vwCheckAnswer.TopAnchor, 0).Active = true;
            vwScrollView.LeadingAnchor.ConstraintEqualTo(this.View.LeadingAnchor, 0).Active = true;
            vwScrollView.TrailingAnchor.ConstraintEqualTo(this.View.TrailingAnchor, 0).Active = true;
            //vwScrollView.Layer.BackgroundColor = UIColor.Yellow.CGColor;

            // Create the content view
            var vwContent = new UIView() { TranslatesAutoresizingMaskIntoConstraints = false };
            //vwContent.Layer.BackgroundColor = UIColor.Red.CGColor;
            vwScrollView.Add(vwContent);
            vwContent.WidthAnchor.ConstraintEqualTo(vwScrollView.WidthAnchor).Active = true;
            //vwContent.HeightAnchor.ConstraintEqualTo(2000).Active = true;
            vwContent.TopAnchor.ConstraintEqualTo(vwScrollView.TopAnchor, 0).Active = true;
            vwContent.BottomAnchor.ConstraintEqualTo(vwScrollView.BottomAnchor, 0).Active = true;
            vwContent.LeadingAnchor.ConstraintEqualTo(vwScrollView.LeadingAnchor, 0).Active = true;
            vwContent.TrailingAnchor.ConstraintEqualTo(vwScrollView.TrailingAnchor, 0).Active = true;

            var lblHeader = new UILabel() { TranslatesAutoresizingMaskIntoConstraints = false };
            var lblQuestion = new UILabel() { TranslatesAutoresizingMaskIntoConstraints = false };
            var chkAnswer = new UISwitch() { TranslatesAutoresizingMaskIntoConstraints = false };
            var lblAnswer = new UILabel() { TranslatesAutoresizingMaskIntoConstraints = false };

            var spacing = 24;

            lblHeader.Text = AppDelegate.BundleToUse.GetLocalizedString("quiz_heading");
            lblHeader.Font = UIFont.SystemFontOfSize(20, UIFontWeight.Bold);
            lblHeader.TextAlignment = UITextAlignment.Left;
            lblHeader.LineBreakMode = UILineBreakMode.WordWrap;
            lblHeader.Lines = 0;
            vwContent.Add(lblHeader);
            lblHeader.TopAnchor.ConstraintEqualTo(vwContent.TopAnchor, topPadding).Active = true;
            lblHeader.LeadingAnchor.ConstraintEqualTo(vwContent.LeadingAnchor, spacing).Active = true;
            lblHeader.TrailingAnchor.ConstraintEqualTo(vwContent.TrailingAnchor, -spacing).Active = true;

            lblQuestion.Text = _currentQuestion.QuestionText;
            lblQuestion.Font = UIFont.SystemFontOfSize(17, UIFontWeight.Bold);
            lblQuestion.TextAlignment = UITextAlignment.Left;
            lblQuestion.LineBreakMode = UILineBreakMode.WordWrap;
            lblQuestion.Lines = 0;
            vwContent.Add(lblQuestion);
            lblQuestion.TopAnchor.ConstraintEqualTo(lblHeader.BottomAnchor, spacing).Active = true;
            lblQuestion.LeadingAnchor.ConstraintEqualTo(vwContent.LeadingAnchor, spacing).Active = true;
            lblQuestion.TrailingAnchor.ConstraintEqualTo(vwContent.TrailingAnchor, -spacing).Active = true;

            vwContent.Add(chkAnswer);
            chkAnswer.TopAnchor.ConstraintEqualTo(lblQuestion.BottomAnchor, spacing).Active = true;
            chkAnswer.LeadingAnchor.ConstraintEqualTo(vwContent.LeadingAnchor, spacing).Active = true;
            chkAnswer.TrailingAnchor.ConstraintEqualTo(vwContent.TrailingAnchor, -spacing).Active = true;

            lblAnswer.Text = _currentQuestion.CheckboxText;
            lblAnswer.TextAlignment = UITextAlignment.Left;
            lblAnswer.LineBreakMode = UILineBreakMode.WordWrap;
            lblAnswer.Lines = 0;
            vwContent.Add(lblAnswer);
            lblAnswer.TopAnchor.ConstraintEqualTo(lblQuestion.BottomAnchor, spacing).Active = true;
            lblAnswer.LeadingAnchor.ConstraintEqualTo(vwContent.LeadingAnchor, spacing + chkAnswer.Frame.Width + spacing).Active = true;
            lblAnswer.TrailingAnchor.ConstraintEqualTo(vwContent.TrailingAnchor, -spacing).Active = true;
            lblAnswer.BottomAnchor.ConstraintEqualTo(vwContent.BottomAnchor).Active = true;


            handler = async (sender, e) =>
            {
                if (!chkAnswer.On)
                {
                    var alert = UIAlertController.Create("", AppDelegate.BundleToUse.GetLocalizedString("quiz_check_the_box"), UIAlertControllerStyle.Alert);
                    alert.AddAction(UIAlertAction.Create("OK", UIAlertActionStyle.Default, null));
                    PresentViewController(alert, true, null);
                }
                else
                {
                    await NextQuestion();
                }
            };

            btnCheckAnswer.TouchUpInside += handler;
        }

        public override void PrepareForSegue(UIStoryboardSegue segue, NSObject sender)
        {
            base.PrepareForSegue(segue, sender);

            var controller = segue.DestinationViewController as QuizEndController;
            controller.CourseID = this.CourseID;
            controller.LessonID = this.LessonID;
        }
    }
}