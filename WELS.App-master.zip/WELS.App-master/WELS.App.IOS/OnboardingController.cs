using CoreAnimation;
using CoreGraphics;
using Foundation;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Reflection;
using System.Threading.Tasks;
using UIKit;
using WELS.App.Shared.Models.Response;

namespace WELS.App.IOS
{
    public partial class OnboardingController : UIViewController
    {
        public OnboardingController() : base() { }
        public OnboardingController (IntPtr handle) : base (handle)
        {
        }
        Dictionary<int, int> CurrentQuestionScores = new Dictionary<int, int>();

        public async override void ViewDidLoad()
        {
            base.ViewDidLoad();

            Localize();

            btnAnswer1.Layer.BorderWidth = 2;
            btnAnswer1.Layer.BorderColor = UIColor.FromRGB(28, 117, 188).CGColor;
            btnAnswer1.TouchUpInside += BtnAnswer_TouchUpInside;
            btnAnswer2.Layer.BorderWidth = 2;
            btnAnswer2.Layer.BorderColor = UIColor.FromRGB(28, 117, 188).CGColor;
            btnAnswer2.TouchUpInside += BtnAnswer_TouchUpInside;
            btnAnswer3.Layer.BorderWidth = 2;
            btnAnswer3.Layer.BorderColor = UIColor.FromRGB(28, 117, 188).CGColor;
            btnAnswer3.TouchUpInside += BtnAnswer_TouchUpInside;
            btnAnswer4.Layer.BorderWidth = 2;
            btnAnswer4.Layer.BorderColor = UIColor.FromRGB(28, 117, 188).CGColor;
            btnAnswer4.TouchUpInside += BtnAnswer_TouchUpInside;

            vwProgress.Transform = CGAffineTransform.MakeScale(1, 3);

//#if (ACADEMIACRISTO)
//            var image = FindViewById<ImageView>(Resource.Id.logo);
//            image.SetImageResource(Resource.Drawable.academia_cristo_w_tagline);
//#endif

            Onboarding = await AppDelegate.DataHelper.GetOnboarding(AppDelegate.CurrentAccount.LanguageNodeID ?? 0);
            await NextQuestion();
        }

        public override void ViewDidLayoutSubviews()
        {
            base.ViewDidLayoutSubviews();

            // Drop-shadow
            UIBezierPath shadowPath = UIBezierPath.FromRect(vwContainer.Bounds);
            vwContainer.Layer.MasksToBounds = false;
            vwContainer.Layer.ShadowColor = UIColor.FromRGB(11, 48, 77).CGColor;
            vwContainer.Layer.ShadowOffset = new CGSize(0.0f, 2.0f);
            vwContainer.Layer.ShadowOpacity = 0.5f;
            vwContainer.Layer.ShadowPath = shadowPath.CGPath;

            // White gradient
            var rect = new CGRect(0, 0, this.View.Frame.Width, 150);
            var view = new UIView(rect);
            var gradientLayer = new CAGradientLayer();
            gradientLayer.Frame = rect;
            gradientLayer.Colors = new CGColor[] { UIColor.White.CGColor, UIColor.Clear.CGColor };
            gradientLayer.StartPoint = new CGPoint(0, 0);
            gradientLayer.EndPoint = new CGPoint(0, 1);
            view.BackgroundColor = UIColor.White;
            view.Layer.Mask = gradientLayer;

            this.View.AddSubview(view);

            this.View.SendSubviewToBack(imgBackground);
            this.View.SendSubviewToBack(view);
        }

        private void Localize()
        {
#if ACADEMIACRISTO
            imgLogo.Image = UIImage.FromBundle("academia_cristo_w_tagline.png");
#endif
            lblWelcome.Text = AppDelegate.BundleToUse.GetLocalizedString("onboarding_title");
            lblIntro.Text = AppDelegate.BundleToUse.GetLocalizedString("onboarding_intro");
        }

        private async void BtnAnswer_TouchUpInside(object sender, EventArgs e)
        {
            _score += CurrentQuestionScores[(int)((UIButton)sender).Tag];
            QuestionIndex++;
            await NextQuestion();
        }

        public int QuestionIndex = 0;
        public OnboardingResponse Onboarding { get; set; }
        private int _score { get; set; }

        public void UpdateProgress()
        {
            float progress = ((float)QuestionIndex + 1.0f) / ((float)Onboarding.Questions.Count() + 1.0f);
            vwProgress.Progress = progress;
        }

        public async Task NextQuestion()
        {
            // If we just completed the last question, update the account with the onboarding data and then start the Onboarding video activity
            if (QuestionIndex >= Onboarding.Questions.Count())
            {
                // Update the account onboarding data
                AppDelegate.CurrentAccount.OnBoardingTotalScore = _score;
                await AppDelegate.DataHelper.SaveAccount(AppDelegate.CurrentAccount);

                // Load the video based on the score:  Find the highest minimum score video where the user score is at least as high
                var sortedVideos = Onboarding.Videos.Where(v => _score >= v.MinimumScore).OrderBy(v => v.MinimumScore);
                var video = sortedVideos.FirstOrDefault();

                // If we have no video, just go to the next activity
                if (video == null)
                {
                    AppDelegate.CurrentAccount.DateCompletedOnboarding = DateTime.UtcNow;
                    await AppDelegate.DataHelper.SaveAccount(AppDelegate.CurrentAccount);
                    this.NavigationController.PopToRootViewController(false);
                }
                // if we have a video, go to the OnboardingFinishActivity
                else
                {
                    PerformSegue("OnboardingVideoSegue", this);
                }
            }
            // Otherwise move onto the next question
            else
            {
                var question = Onboarding.Questions.ElementAt(QuestionIndex);
                CurrentQuestionScores = new Dictionary<int, int>();
                for (int btnIndex = 0; btnIndex <= 3; btnIndex++)
                {
                    var btn = (UIButton)this.View.ViewWithTag((btnIndex + 1));
                    var answer = question.Answers.Skip(btnIndex).FirstOrDefault();
                    if (answer != null)
                    {
                        btn.Hidden = false;
                        btn.SetTitle(answer.AnswerText, UIControlState.Normal);
                        CurrentQuestionScores.Add(btnIndex + 1, answer.Score);
                    }
                    else
                    {
                        btn.Hidden = true;
                    }
                }
                txtQuestion.Text = question.QuestionText;

                UpdateProgress();
            }
        }
    }
}