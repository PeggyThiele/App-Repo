using CoreGraphics;
using Facebook.CoreKit;
using Foundation;
using System;
using System.Linq;
using UIKit;
using WELS.App.Shared.Models.Request;

namespace WELS.App.IOS
{
    public partial class LoginController : UIViewController
    {
        public LoginController() : base() { }
        public LoginController (IntPtr handle) : base (handle)
        {
            
        }

        public override void ViewDidLoad()
        {
            base.ViewDidLoad();

            Localize();

            var contraint = this.btnLogin?.Constraints?.Where(x => x.FirstAttribute.Equals(NSLayoutAttribute.Height) && x.Constant == 28f)?.FirstOrDefault() ?? null;
            if (contraint != null)
            {
                this.btnLogin.RemoveConstraint(contraint);
            }

            btnLogin.Permissions = new string[] { "email" };
            btnLogin.Completed += BtnLogin_Completed;

            Profile.Notifications.ObserveDidChange(async (sender, e) =>
            {
                var profile = e.NewProfile;
                if (profile != null && AccessToken.CurrentAccessToken != null)
                {
                    await AppDelegate.DataHelper.SetFacebookLogin(AccessToken.CurrentAccessToken.UserId, AccessToken.CurrentAccessToken.TokenString, Settings.AppId);
                    var languageID = (await AppDelegate.CurrentLanguage()).LanguageNodeID;
                    var name = profile.Name;
                    var profileUrl = profile.ImageUrl(ProfilePictureMode.Square, new CoreGraphics.CGSize(68, 68));
                    AppDelegate.CurrentAccount = await AppDelegate.DataHelper.GetAccount(languageID, AppDelegate.AccountSource, name, profileUrl != null ? profileUrl.AbsoluteString : "");
                    await AppDelegate.DataHelper.LoadAccountDataFromAPI(AppDelegate.CurrentAccount);
                    AppDelegate.CurrentAccount.HasAuthenticated = true;
                    await AppDelegate.DataHelper.SaveAccount(AppDelegate.CurrentAccount);

                    this.NavigationController.PopToRootViewController(false);
                }
            });

            // WhatsApp
            btnWhatsApp.SetTitle(AppDelegate.BundleToUse.GetLocalizedString("button_continue_with_whatsapp"), UIControlState.Normal);
            btnWhatsApp.TouchUpInside += (sender, e) =>
            {
                this.PerformSegue("WhatsAppLoginSegue", this);
            };
        }
        private void BtnLogin_Completed(object sender, Facebook.LoginKit.LoginButtonCompletedEventArgs e)
        {
            if (e.Error != null)
            {
                return;
            }

            if (e.Result.IsCancelled)
            {
                return;
            }

            btnLogin.Enabled = false;
        }

        public override void ViewDidLayoutSubviews()
        {
            base.ViewDidLayoutSubviews();

            // Drop-shadow
            UIBezierPath shadowPath = UIBezierPath.FromRect(vwContainer.Bounds);
            vwContainer.Layer.MasksToBounds = false;
            vwContainer.Layer.ShadowColor = UIColor.FromRGB(11, 48, 77).CGColor;
            vwContainer.Layer.ShadowOffset = new CGSize(0.0f, 2.0f);
            vwContainer.Layer.ShadowOpacity = 0.5f;
            vwContainer.Layer.ShadowPath = shadowPath.CGPath;
        }

        private void Localize()
        {
#if ACADEMIACRISTO
            imgLogo.Image = UIImage.FromBundle("academia_cristo_w_tagline.png");
#endif
            btnLogin.SetAttributedTitle(new NSAttributedString(AppDelegate.BundleToUse.GetLocalizedString("button_continue_with_facebook")), UIControlState.Normal);
        }
    }
}