// WARNING
//
// This file has been generated automatically by Visual Studio from the outlets and
// actions declared in your storyboard file.
// Manual changes to this file will not be maintained.
//
using Foundation;
using System;
using System.CodeDom.Compiler;
using UIKit;

namespace WELS.App.IOS
{
    [Register ("MoreMenuController")]
    partial class MoreMenuController
    {
        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UIButton btnContact { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UIButton btnInstagram { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UIButton btnShare { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UIButton btnWebsite { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UILabel lblContact { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UILabel lblInstagram { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UILabel lblShare { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UILabel lblWebsite { get; set; }

        void ReleaseDesignerOutlets ()
        {
            if (btnContact != null) {
                btnContact.Dispose ();
                btnContact = null;
            }

            if (btnInstagram != null) {
                btnInstagram.Dispose ();
                btnInstagram = null;
            }

            if (btnShare != null) {
                btnShare.Dispose ();
                btnShare = null;
            }

            if (btnWebsite != null) {
                btnWebsite.Dispose ();
                btnWebsite = null;
            }

            if (lblContact != null) {
                lblContact.Dispose ();
                lblContact = null;
            }

            if (lblInstagram != null) {
                lblInstagram.Dispose ();
                lblInstagram = null;
            }

            if (lblShare != null) {
                lblShare.Dispose ();
                lblShare = null;
            }

            if (lblWebsite != null) {
                lblWebsite.Dispose ();
                lblWebsite = null;
            }
        }
    }
}