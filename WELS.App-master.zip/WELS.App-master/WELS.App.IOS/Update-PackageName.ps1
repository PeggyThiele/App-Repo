param ([string] $ProjectDir, [string] $ConfigurationName)
$ProjectDir = $ProjectDir.Trim(" ")
Write-Host "ProjectDir: $ProjectDir"
Write-Host "ConfigurationName: $ConfigurationName"

$ManifestPath = $ProjectDir + "Info.plist"

Write-Host "Info.plist path: $ManifestPath"

$xpathfbid = "//key[text()='FacebookAppID']/following::string"
$xpathfbid2 = "//key[text()='CFBundleURLSchemes']/following::array/string"
$xpathappname = "//key[text()='CFBundleDisplayName']/following::string"
$xpathappid = "//key[text()='CFBundleIdentifier']/following::string"
$xpathicon = "//key[text()='XSAppIconAssets']/following::string"

[xml] $xdoc = Get-Content $ManifestPath

$fbappidnode = $xdoc.SelectSingleNode($xpathfbid)
$fbappidnode2 = $xdoc.SelectSingleNode($xpathfbid2)
$appnamenode = $xdoc.SelectSingleNode($xpathappname)
$appidnode = $xdoc.SelectSingleNode($xpathappid)
$iconnode = $xdoc.SelectSingleNode($xpathicon)

$package = $xdoc.manifest.package

If ($ConfigurationName -eq "ReleaseTell")
{
Write-Host "Updating configuration for Release"
$fbappidnode.InnerText = "2149559461758921"
$fbappidnode2.InnerText = "fb2149559461758921"
$appnamenode.InnerText = "TELL"
$appidnode.InnerText = "com.tellnetwork.tell"
$iconnode.InnerText = "Assets.xcassets/TELL.appiconset"
$xdoc.Save($ManifestPath)
}
If ($ConfigurationName -eq "ReleaseAcademiaCristo")
{
Write-Host "Updating configuration for ReleaseAcademiaCristo"
$fbappidnode.InnerText = "244363673216387"
$fbappidnode2.InnerText = "fb244363673216387"
$appnamenode.InnerText = "Academia Cristo"
$appidnode.InnerText = "com.tellnetwork.academiacristo"
$iconnode.InnerText = "Assets.xcassets/AC.appiconset"
$xdoc.Save($ManifestPath)
}
If ($ConfigurationName -eq "Debug")
{
Write-Host "Updating configuration for Debug"
$fbappidnode.InnerText = "2149559461758921"
$fbappidnode2.InnerText = "fb2149559461758921"
$appnamenode.InnerText = "TELL"
$appidnode.InnerText = "com.tellnetwork.tell"
$iconnode.InnerText = "Assets.xcassets/TELL.appiconset"
$xdoc.Save($ManifestPath)
}
If ($ConfigurationName -eq "DebugAcademiaCristo")
{
Write-Host "Updating configuration for DebugAcademiaCristo"
$fbappidnode.InnerText = "244363673216387"
$fbappidnode2.InnerText = "fb244363673216387"
$appnamenode.InnerText = "Academia Cristo"
$appidnode.InnerText = "com.tellnetwork.academiacristo"
$iconnode.InnerText = "Assets.xcassets/AC.appiconset"
$xdoc.Save($ManifestPath)
}
