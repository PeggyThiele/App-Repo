using Foundation;
using System;
using System.Linq;
using UIKit;
using WELS.App.Shared.Data;

namespace WELS.App.IOS
{
    public partial class QuizEndController : UIViewController
    {
        public int CourseID { get; set; }
        public int LessonID { get; set; }
        public Course Course { get; set; }
        public Lesson Lesson { get; set; }
        public QuizEndController (IntPtr handle) : base (handle)
        {
        }

        public async override void ViewDidLoad()
        {
            base.ViewDidLoad();

            Course = AppDelegate.Courses.FirstOrDefault(c => c.CourseNodeID == CourseID);
            Lesson = Course.Lessons.FirstOrDefault(c => c.LessonNodeID == LessonID);

            Localize();

            EncouragementMessage message = null;
            // If a specific encouragement message is set, assign it now
            if (Lesson.EncouragementMessageNodeID > 0)
            {
                message = AppDelegate.DataHelper.GetEncouragementMessages().FirstOrDefault(m => m.LanguageEncouragementMessageNodeID == Lesson.EncouragementMessageNodeID);
            }
            // If our message is still null, get a random one
            if (message == null)
            {
                message = await AppDelegate.DataHelper.GetRandomEncouragementMessage((await AppDelegate.CurrentLanguage()).LanguageNodeID);
            }
            lblEncouragementMessage.Text = message.Message;

            btnBack.Layer.BorderColor = UIColor.White.CGColor;
            btnBack.Layer.BorderWidth = 1;

            btnNext.TouchUpInside += BtnNext_TouchUpInside;
            btnBack.TouchUpInside += BtnBack_TouchUpInside;
        }

        private void Localize()
        {
            lblCongrats.Text = string.Format(AppDelegate.BundleToUse.GetLocalizedString("quiz_end_congrats"), Lesson.SortOrder);
            var nextLesson = Course.Lessons.FirstOrDefault(l => l.SortOrder > Lesson.SortOrder && l.DateCompletedAllLessonItems == null);
            if (nextLesson != null)
            {
                btnNext.SetTitle(string.Format(AppDelegate.BundleToUse.GetLocalizedString("quiz_end_next"), Lesson.SortOrder + 1), UIControlState.Normal);
            }
            else
            {
                btnNext.Hidden = true;
            }
            btnBack.SetTitle(AppDelegate.BundleToUse.GetLocalizedString("quiz_end_back"), UIControlState.Normal);
        }

        private void BtnNext_TouchUpInside(object sender, EventArgs e)
        {
            AppDelegate.GoRightToNextLesson = true;
            this.NavigationController.PopToRootViewController(false);
        }

        private void BtnBack_TouchUpInside(object sender, EventArgs e)
        {
            this.NavigationController.PopToRootViewController(false);
        }
    }
}