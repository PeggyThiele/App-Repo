﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Linq;
using System.Text;
using CoreGraphics;
using Foundation;
using UIKit;

namespace WELS.App.IOS.Controls
{
    public class RadioButtonGroup : UIView
    {
        public List<RadioButton> RadioButtonItems { get; set; } = new List<RadioButton>();
        public RadioButton SelectedItem { get; private set; }
        public RadioButtonGroup(List<KeyValuePair<string, string>> options, int spacing)
        {
            // TODO:  Add a RadioButton for each option in options
            UIView previousRadio = null;
            foreach (var option in options)
            {
                RadioButton radio;
                if (previousRadio != null)
                {
                    radio = new RadioButton(option.Key, option.Value) { TranslatesAutoresizingMaskIntoConstraints = false };
                    this.AddSubview(radio);
                    radio.TopAnchor.ConstraintEqualTo(previousRadio.BottomAnchor, spacing).Active = true;
                }
                else
                {
                    radio = new RadioButton(option.Key, option.Value) { TranslatesAutoresizingMaskIntoConstraints = false };
                    this.AddSubview(radio);
                    radio.TopAnchor.ConstraintEqualTo(this.TopAnchor, 0).Active = true;
                }
                radio.LeadingAnchor.ConstraintEqualTo(this.LeadingAnchor).Active = true;
                radio.TrailingAnchor.ConstraintEqualTo(this.TrailingAnchor).Active = true;
                //radio.Layer.BackgroundColor = UIColor.Green.CGColor;
                radio.Change += Radio_Change;
                previousRadio = radio;
                this.RadioButtonItems.Add(radio);
            }
            if (previousRadio != null)
            {
                previousRadio.BottomAnchor.ConstraintEqualTo(this.BottomAnchor).Active = true;
            }
        }

        private void Radio_Change(object sender, EventArgs e)
        {
            var radio = (RadioButton)sender;
            if (radio.Checked)
            {
                var oldSelectedItem = this.SelectedItem;
                // Be sure to switch selected item here, so event handlers triggered below here are referencing
                // the current SelectedItem
                this.SelectedItem = radio;
                // if we already had a selected item, uncheck the item
                if (oldSelectedItem != null && oldSelectedItem != radio)
                {
                    oldSelectedItem.Checked = false;
                }
            }
            else
            {
                // if we are unchecking the current item, don't allow it
                if (this.SelectedItem == radio)
                {
                    this.SelectedItem.Checked = true;
                }
            }
        }
    }
}