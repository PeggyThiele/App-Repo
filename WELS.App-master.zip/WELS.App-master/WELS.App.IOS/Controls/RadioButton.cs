﻿using CoreGraphics;
using System;
using UIKit;

namespace WELS.App.IOS.Controls
{
    public class RadioButton : UIView
    {
        private CircleView circleView;
        private UILabel lbTitle;
        public string Value { get; private set; }
        public string Title { get; private set; }
        public event EventHandler Change;

        public bool Checked
        {
            get
            {
                return circleView.Checked;
            }
            set
            {
                if (value != circleView.Checked)
                {
                    circleView.Checked = value;
                    Change.Invoke(this, new EventArgs());
                }
            }
        }

        public RadioButton(string value, string title)
        {
            this.Title = title;
            this.Value = value;

            int circleDiameter = 24;
            circleView = new CircleView(new CGRect(0, 0, circleDiameter, circleDiameter)) { TranslatesAutoresizingMaskIntoConstraints = false };
            lbTitle = new UILabel() { TranslatesAutoresizingMaskIntoConstraints = false };
            lbTitle.Text = title;
            lbTitle.TextAlignment = UITextAlignment.Left;
            lbTitle.Lines = 0;
            this.AddSubview(circleView);
            this.AddSubview(lbTitle);

            lbTitle.LeadingAnchor.ConstraintEqualTo(this.LeadingAnchor, circleDiameter).Active = true;
            lbTitle.TrailingAnchor.ConstraintEqualTo(this.TrailingAnchor).Active = true;
            lbTitle.TopAnchor.ConstraintEqualTo(this.TopAnchor).Active = true;
            lbTitle.BottomAnchor.ConstraintEqualTo(this.BottomAnchor).Active = true;

            circleView.TopAnchor.ConstraintEqualTo(this.TopAnchor).Active = true;
            circleView.LeadingAnchor.ConstraintEqualTo(this.LeadingAnchor).Active = true;
            circleView.WidthAnchor.ConstraintEqualTo(circleDiameter).Active = true;
            circleView.HeightAnchor.ConstraintEqualTo(circleDiameter).Active = true;

            UITapGestureRecognizer tapGR = new UITapGestureRecognizer(() =>
            {
                Checked = !Checked;
            });
            this.AddGestureRecognizer(tapGR);
        }
    }

    class CircleView : UIView
    {
        private bool _checked = false;
        public bool Checked
        {
            get
            {
                return _checked;
            }
            set
            {
                _checked = value;
                this.SetNeedsDisplay();
            }
        }

        public CircleView(CGRect frame)
        {
            this.BackgroundColor = UIColor.Clear;
            this.Frame = frame;
        }

        public override void Draw(CoreGraphics.CGRect rect)
        {
            CGContext con = UIGraphics.GetCurrentContext();

            float padding = 5;
            con.AddEllipseInRect(new CGRect(padding, padding, rect.Width - 2 * padding, rect.Height - 2 * padding));
            con.StrokePath();

            if (_checked)
            {
                float insidePadding = 8;
                con.AddEllipseInRect(new CGRect(insidePadding, insidePadding, rect.Width - 2 * insidePadding, rect.Height - 2 * insidePadding));
                con.FillPath();
            }
        }
    }
}