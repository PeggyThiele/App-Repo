// WARNING
//
// This file has been generated automatically by Visual Studio from the outlets and
// actions declared in your storyboard file.
// Manual changes to this file will not be maintained.
//
using Foundation;
using System;
using System.CodeDom.Compiler;
using UIKit;

namespace WELS.App.IOS
{
    [Register ("AccountController")]
    partial class AccountController
    {
        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UIButton btnEditWhatsApp { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UIButton btnLogOut { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UIButton btnSave { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UISwitch chkAllowPush { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UISwitch chkAllowText { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UIImageView imgProfileImage { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UILabel lblHeader { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UILabel lblJoinDate { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UILabel lblJoinDateLabel { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UILabel lblName { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UILabel lblNameLabel { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UILabel lblPreferences { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UILabel lblPushDescription { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UILabel lblPushLabel { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UILabel lblTextDescription { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UILabel lblTextLabel { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UILabel lblWhatsApp { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UILabel lblWhatsAppLabel { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UITextField txtWhatsApp { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UIView vwContainer { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UIScrollView vwScrollView { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UIView vwSpacer { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UIView vwSpacer2 { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UIView vwSpacer3 { get; set; }

        void ReleaseDesignerOutlets ()
        {
            if (btnEditWhatsApp != null) {
                btnEditWhatsApp.Dispose ();
                btnEditWhatsApp = null;
            }

            if (btnLogOut != null) {
                btnLogOut.Dispose ();
                btnLogOut = null;
            }

            if (btnSave != null) {
                btnSave.Dispose ();
                btnSave = null;
            }

            if (chkAllowPush != null) {
                chkAllowPush.Dispose ();
                chkAllowPush = null;
            }

            if (chkAllowText != null) {
                chkAllowText.Dispose ();
                chkAllowText = null;
            }

            if (imgProfileImage != null) {
                imgProfileImage.Dispose ();
                imgProfileImage = null;
            }

            if (lblHeader != null) {
                lblHeader.Dispose ();
                lblHeader = null;
            }

            if (lblJoinDate != null) {
                lblJoinDate.Dispose ();
                lblJoinDate = null;
            }

            if (lblJoinDateLabel != null) {
                lblJoinDateLabel.Dispose ();
                lblJoinDateLabel = null;
            }

            if (lblName != null) {
                lblName.Dispose ();
                lblName = null;
            }

            if (lblNameLabel != null) {
                lblNameLabel.Dispose ();
                lblNameLabel = null;
            }

            if (lblPreferences != null) {
                lblPreferences.Dispose ();
                lblPreferences = null;
            }

            if (lblPushDescription != null) {
                lblPushDescription.Dispose ();
                lblPushDescription = null;
            }

            if (lblPushLabel != null) {
                lblPushLabel.Dispose ();
                lblPushLabel = null;
            }

            if (lblTextDescription != null) {
                lblTextDescription.Dispose ();
                lblTextDescription = null;
            }

            if (lblTextLabel != null) {
                lblTextLabel.Dispose ();
                lblTextLabel = null;
            }

            if (lblWhatsApp != null) {
                lblWhatsApp.Dispose ();
                lblWhatsApp = null;
            }

            if (lblWhatsAppLabel != null) {
                lblWhatsAppLabel.Dispose ();
                lblWhatsAppLabel = null;
            }

            if (txtWhatsApp != null) {
                txtWhatsApp.Dispose ();
                txtWhatsApp = null;
            }

            if (vwContainer != null) {
                vwContainer.Dispose ();
                vwContainer = null;
            }

            if (vwScrollView != null) {
                vwScrollView.Dispose ();
                vwScrollView = null;
            }

            if (vwSpacer != null) {
                vwSpacer.Dispose ();
                vwSpacer = null;
            }

            if (vwSpacer2 != null) {
                vwSpacer2.Dispose ();
                vwSpacer2 = null;
            }

            if (vwSpacer3 != null) {
                vwSpacer3.Dispose ();
                vwSpacer3 = null;
            }
        }
    }
}