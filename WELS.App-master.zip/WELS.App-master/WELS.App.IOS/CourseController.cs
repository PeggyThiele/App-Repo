using CoreGraphics;
using Foundation;
using System;
using System.Linq;
using UIKit;
using WebKit;
using WELS.App.IOS.Helpers;
using WELS.App.Shared.Data;
using WELS.App.Shared.Helpers;

namespace WELS.App.IOS
{
    public partial class CourseController : UIViewController
    {
        public int CourseID { get; set; }
        public int? LessonIDToView { get; set; }
        Course Course { get; set; }
        Lesson CurrentLesson { get; set; }
        public CourseController (IntPtr handle) : base (handle)
        {
        }

        public async override void ViewDidLoad()
        {
            base.ViewDidLoad();

            this.Course = AppDelegate.Courses.FirstOrDefault(c => c.CourseNodeID == CourseID);

            var vwScrollView = new UIScrollView() { TranslatesAutoresizingMaskIntoConstraints = false };
            this.View.Add(vwScrollView);
            vwScrollView.TopAnchor.ConstraintEqualTo(this.View.SafeAreaLayoutGuide.TopAnchor, 0).Active = true;
            vwScrollView.BottomAnchor.ConstraintEqualTo(this.View.SafeAreaLayoutGuide.BottomAnchor, 0).Active = true;
            vwScrollView.LeadingAnchor.ConstraintEqualTo(this.View.LeadingAnchor, 0).Active = true;
            vwScrollView.TrailingAnchor.ConstraintEqualTo(this.View.TrailingAnchor, 0).Active = true;

            // Settings
            var margin = 16;

            // Create the content view
            var vwContent = new UIView() { TranslatesAutoresizingMaskIntoConstraints = false };
            //vwContent.Layer.BackgroundColor = UIColor.Red.CGColor;
            vwScrollView.Add(vwContent);
            vwContent.WidthAnchor.ConstraintEqualTo(vwScrollView.WidthAnchor).Active = true;
            //vwContent.HeightAnchor.ConstraintEqualTo(2000).Active = true;
            vwContent.TopAnchor.ConstraintEqualTo(vwScrollView.TopAnchor, 0).Active = true;
            vwContent.BottomAnchor.ConstraintEqualTo(vwScrollView.BottomAnchor, 0).Active = true;
            vwContent.LeadingAnchor.ConstraintEqualTo(vwScrollView.LeadingAnchor, 0).Active = true;
            vwContent.TrailingAnchor.ConstraintEqualTo(vwScrollView.TrailingAnchor, 0).Active = true;

            var lbl1 = new UILabel() { TranslatesAutoresizingMaskIntoConstraints = false };
            lbl1.Text = string.Format(AppDelegate.BundleToUse.GetLocalizedString("course_page_course_number"), Course.SortOrder);
            lbl1.TextAlignment = UITextAlignment.Center;
            vwContent.Add(lbl1);
            lbl1.TopAnchor.ConstraintEqualTo(vwContent.TopAnchor, margin).Active = true;
            lbl1.LeadingAnchor.ConstraintEqualTo(vwContent.LeadingAnchor, margin).Active = true;
            lbl1.TrailingAnchor.ConstraintEqualTo(vwContent.TrailingAnchor, -margin).Active = true;

            var lbl2 = new UILabel() { TranslatesAutoresizingMaskIntoConstraints = false };
            lbl2.Text = Course.Name;
            lbl2.Font = UIFont.SystemFontOfSize(20, UIFontWeight.Bold);
            lbl2.TextAlignment = UITextAlignment.Center;
            vwContent.Add(lbl2);
            lbl2.TopAnchor.ConstraintEqualTo(lbl1.BottomAnchor, margin).Active = true;
            lbl2.LeadingAnchor.ConstraintEqualTo(vwContent.LeadingAnchor, margin).Active = true;
            lbl2.TrailingAnchor.ConstraintEqualTo(vwContent.TrailingAnchor, -margin).Active = true;

            var lbl3 = new UILabel() { TranslatesAutoresizingMaskIntoConstraints = false };
            lbl3.Text = string.Format(AppDelegate.BundleToUse.GetLocalizedString("course_page_lesson_count_and_timing"), Course.Lessons.Count, Course.EstimatedDuration);
            lbl3.TextAlignment = UITextAlignment.Center;
            vwContent.Add(lbl3);
            lbl3.TopAnchor.ConstraintEqualTo(lbl2.BottomAnchor, margin).Active = true;
            lbl3.LeadingAnchor.ConstraintEqualTo(vwContent.LeadingAnchor, margin).Active = true;
            lbl3.TrailingAnchor.ConstraintEqualTo(vwContent.TrailingAnchor, -margin).Active = true;

            // Create the container view
            var vwLessonListContainer = new UIView() { TranslatesAutoresizingMaskIntoConstraints = false };
            vwLessonListContainer.Layer.BackgroundColor = new CGColor(1, 1, 1, 0);
            //vwLessonListContainer.Layer.BackgroundColor = UIColor.Yellow.CGColor;
            vwContent.Add(vwLessonListContainer);
            vwLessonListContainer.TopAnchor.ConstraintEqualTo(lbl3.BottomAnchor, margin).Active = true;
            vwLessonListContainer.BottomAnchor.ConstraintEqualTo(vwContent.BottomAnchor, 0).Active = true;
            vwLessonListContainer.LeadingAnchor.ConstraintEqualTo(vwContent.LeadingAnchor, margin).Active = true;
            vwLessonListContainer.TrailingAnchor.ConstraintEqualTo(vwContent.TrailingAnchor, -margin).Active = true;

            // add the course description
            var lblCourseDescription = new UILabel() { TranslatesAutoresizingMaskIntoConstraints = false };
            lblCourseDescription.Text = Course.Description;
            lblCourseDescription.TextAlignment = UITextAlignment.Left;
            lblCourseDescription.LineBreakMode = UILineBreakMode.WordWrap;
            lblCourseDescription.Lines = 0;
            vwLessonListContainer.Add(lblCourseDescription);
            lblCourseDescription.TopAnchor.ConstraintEqualTo(vwLessonListContainer.TopAnchor, margin).Active = true;
            lblCourseDescription.LeadingAnchor.ConstraintEqualTo(vwLessonListContainer.LeadingAnchor, 0).Active = true;
            lblCourseDescription.TrailingAnchor.ConstraintEqualTo(vwLessonListContainer.TrailingAnchor, 0).Active = true;

            var incomplete = Course.Lessons.Where(c => c.DateCompletedAllLessonItems == null).OrderBy(c => c.SortOrder).ToList();
            var complete = Course.Lessons.Where(c => c.DateCompletedAllLessonItems != null).OrderBy(c => c.SortOrder).ToList();

            if (Course.DateStarted == null)
            {
                Course.DateStarted = DateTime.UtcNow;
                await AppDelegate.DataHelper.SaveData(Course, AppDelegate.CurrentAccount);
            }

            if (incomplete.Any())
            {
                var lesson = incomplete.FirstOrDefault();
                if (lesson.DateStarted == null)
                {
                    lesson.DateStarted = DateTime.UtcNow;
                    await AppDelegate.DataHelper.SaveData(lesson, AppDelegate.CurrentAccount);
                }
            }

            var constraintTo = lblCourseDescription.BottomAnchor;

            // If a specific lesson ID was requested, show that lesson instead of the next lesson
            bool hideQuizButton = false;
            UIView view;
            if (this.LessonIDToView != null)
            {
                CurrentLesson = Course.Lessons.FirstOrDefault(l => l.LessonNodeID == LessonIDToView && l.DateCompletedAllLessonItems != null);
                hideQuizButton = true;
            }
            if (CurrentLesson == null)
            {
                CurrentLesson = incomplete.FirstOrDefault();
            }
            if (CurrentLesson != null)
            {
                view = BuildCurrentLessonContainer(vwLessonListContainer, constraintTo, hideQuizButton, CurrentLesson);
                constraintTo = view.BottomAnchor;

                LessonIDToView = CurrentLesson.LessonNodeID;
                if (incomplete.Count > 1)
                {
                    var lbl = new UILabel() { TranslatesAutoresizingMaskIntoConstraints = false };
                    lbl.Text = AppDelegate.BundleToUse.GetLocalizedString("course_page_up_next");

                    // add label as subview
                    vwLessonListContainer.Add(lbl);

                    // add the constraints
                    lbl.TopAnchor.ConstraintEqualTo(constraintTo, margin).Active = true;
                    lbl.LeadingAnchor.ConstraintEqualTo(vwLessonListContainer.LeadingAnchor, 0).Active = true;
                    lbl.TrailingAnchor.ConstraintEqualTo(vwLessonListContainer.TrailingAnchor, 0).Active = true;

                    constraintTo = lbl.BottomAnchor;

                    foreach (var lesson in incomplete.Skip(1))
                    {
                        view = BuildLessonContainer(vwLessonListContainer, constraintTo, false, lesson);
                        constraintTo = view.BottomAnchor;
                    }
                }
            }

            if (complete.Any())
            {
                var lbl = new UILabel() { TranslatesAutoresizingMaskIntoConstraints = false };
                lbl.Text = AppDelegate.BundleToUse.GetLocalizedString("course_page_completed");

                // add label as subview
                vwLessonListContainer.Add(lbl);

                // add the constraints
                lbl.TopAnchor.ConstraintEqualTo(constraintTo, margin).Active = true;
                lbl.LeadingAnchor.ConstraintEqualTo(vwLessonListContainer.LeadingAnchor, 0).Active = true;
                lbl.TrailingAnchor.ConstraintEqualTo(vwLessonListContainer.TrailingAnchor, 0).Active = true;

                constraintTo = lbl.BottomAnchor;

                foreach (var lesson in complete)
                {
                    view = BuildLessonContainer(vwLessonListContainer, constraintTo, true, lesson);
                    constraintTo = view.BottomAnchor;
                }
            }

            //// Add current, upcoming and then completed lessons
            //for (int i = 1; i <= 10; i++)
            //{
            //    // Add the lesson block
            //    if (i == 1)
            //    {
            //        view = BuildCurrentLessonContainer(vwLessonListContainer, constraintTo);
            //    }
            //    else
            //    {
            //        view = BuildLessonContainer(vwLessonListContainer, constraintTo, i >= 7);
            //    }

            //    constraintTo = view.BottomAnchor;

            //    // Test adding section labels
            //    if (i == 1 || i == 6)
            //    {
            //        var lbl = new UILabel() { TranslatesAutoresizingMaskIntoConstraints = false };
            //        if (i == 1)
            //            lbl.Text = "Upcoming:";
            //        else
            //            lbl.Text = "Completed:";

            //        // add label as subview
            //        vwLessonListContainer.Add(lbl);

            //        // add the constraints
            //        lbl.TopAnchor.ConstraintEqualTo(constraintTo, margin).Active = true;
            //        lbl.LeadingAnchor.ConstraintEqualTo(vwLessonListContainer.LeadingAnchor, 0).Active = true;
            //        lbl.TrailingAnchor.ConstraintEqualTo(vwLessonListContainer.TrailingAnchor, 0).Active = true;

            //        constraintTo = lbl.BottomAnchor;
            //    }
            //}

            // Now constrain the last label to the bottom of the container view
            vwLessonListContainer.BottomAnchor.ConstraintEqualTo(constraintTo, 0).Active = true;
        }


        private UIView BuildCurrentLessonContainer(UIView parent, NSLayoutYAxisAnchor anchorTopTo, bool hideQuizButton, Lesson lesson)
        {
            // All of our wonderful dynamic views
            var vwContainer = new UIView() { TranslatesAutoresizingMaskIntoConstraints = false };
            var vwVideo = new WKWebView(CGRect.Empty, new WKWebViewConfiguration()) { TranslatesAutoresizingMaskIntoConstraints = false };
            var lblCourseName = new UILabel() { TranslatesAutoresizingMaskIntoConstraints = false };
            var lblLessonName = new UILabel() { TranslatesAutoresizingMaskIntoConstraints = false };
            var lblLessonDescription = new UILabel() { TranslatesAutoresizingMaskIntoConstraints = false };
            var btnTakeQuiz = new UIButton() { TranslatesAutoresizingMaskIntoConstraints = false };

            // Some hard-coded settings
            var padding = 10;

            var lessonDescription = lesson.LessonItems.Where(i => i.Type == Constants.LessonItemType.Text).Select(i => i.Text).FirstOrDefault();
            var lessonVideo = lesson.LessonItems.Where(i => i.Type == Constants.LessonItemType.Video).Select(i => i.VideoURL).FirstOrDefault();

            // add the constraints
            parent.Add(vwContainer);
            vwContainer.Layer.BackgroundColor = UIColor.White.CGColor;
            vwContainer.TopAnchor.ConstraintEqualTo(anchorTopTo, padding).Active = true;
            vwContainer.LeadingAnchor.ConstraintEqualTo(parent.LeadingAnchor).Active = true;
            vwContainer.TrailingAnchor.ConstraintEqualTo(parent.TrailingAnchor).Active = true;

            // add the video
            var youtubeID = VideoHelper.ParseYouTubeID(lessonVideo);
            var url = $"https://www.youtube-nocookie.com/embed/{youtubeID}?modestbranding=1";
            vwContainer.Add(vwVideo);
            vwVideo.TopAnchor.ConstraintEqualTo(vwContainer.TopAnchor, 0).Active = true;
            vwVideo.LeadingAnchor.ConstraintEqualTo(vwContainer.LeadingAnchor, 0).Active = true;
            vwVideo.TrailingAnchor.ConstraintEqualTo(vwContainer.TrailingAnchor, 0).Active = true;
            vwVideo.HeightAnchor.ConstraintEqualTo(vwVideo.WidthAnchor, 9.0f / 16.0f).Active = true;
            var iframesrc = $"<meta name=\"viewport\" content=\"width=device-width, user-scalable=no\"><iframe width=\"100%\" height=\"100%\" src=\"{url}\" frameborder=\"0\" allowfullscreen></iframe>";
            vwVideo.LoadHtmlString(iframesrc, new NSUrl(url));

            // add the rest
            lblCourseName.Text = Course.Name;
            vwContainer.Add(lblCourseName);
            lblCourseName.TopAnchor.ConstraintEqualTo(vwVideo.BottomAnchor, padding).Active = true;
            lblCourseName.LeadingAnchor.ConstraintEqualTo(vwContainer.LeadingAnchor, padding).Active = true;
            lblCourseName.TrailingAnchor.ConstraintEqualTo(vwContainer.TrailingAnchor, -padding).Active = true;

            lblLessonName.Text = lesson.Name;
            lblLessonName.Font = UIFont.SystemFontOfSize(20, UIFontWeight.Bold);
            vwContainer.Add(lblLessonName);
            lblLessonName.TopAnchor.ConstraintEqualTo(lblCourseName.BottomAnchor, padding).Active = true;
            lblLessonName.LeadingAnchor.ConstraintEqualTo(vwContainer.LeadingAnchor, padding).Active = true;
            lblLessonName.TrailingAnchor.ConstraintEqualTo(vwContainer.TrailingAnchor, -padding).Active = true;

            lblLessonDescription.Text = lessonDescription;
            lblLessonDescription.TextAlignment = UITextAlignment.Left;
            lblLessonDescription.LineBreakMode = UILineBreakMode.WordWrap;
            lblLessonDescription.Lines = 0;
            vwContainer.Add(lblLessonDescription);
            lblLessonDescription.TopAnchor.ConstraintEqualTo(lblLessonName.BottomAnchor, padding).Active = true;
            lblLessonDescription.LeadingAnchor.ConstraintEqualTo(vwContainer.LeadingAnchor, padding).Active = true;
            lblLessonDescription.TrailingAnchor.ConstraintEqualTo(vwContainer.TrailingAnchor, -padding).Active = true;

            btnTakeQuiz.SetTitle(AppDelegate.BundleToUse.GetLocalizedString("lesson_card_take_quiz"), UIControlState.Normal);
            btnTakeQuiz.SetTitleColor(UIColor.White, UIControlState.Normal);
            btnTakeQuiz.BackgroundColor = UIColor.FromRGB(28, 117, 188);
            vwContainer.Add(btnTakeQuiz);
            btnTakeQuiz.TopAnchor.ConstraintEqualTo(lblLessonDescription.BottomAnchor, padding).Active = true;
            btnTakeQuiz.LeadingAnchor.ConstraintEqualTo(vwContainer.LeadingAnchor, 0).Active = true;
            btnTakeQuiz.TrailingAnchor.ConstraintEqualTo(vwContainer.TrailingAnchor, 0).Active = true;
            btnTakeQuiz.HeightAnchor.ConstraintEqualTo(50).Active = true;
            btnTakeQuiz.BottomAnchor.ConstraintEqualTo(vwContainer.BottomAnchor).Active = true;
            btnTakeQuiz.TouchUpInside += BtnTakeQuiz_TouchUpInside;

            return vwContainer;
        }

        private void BtnTakeQuiz_TouchUpInside(object sender, EventArgs e)
        {
            this.PerformSegue("QuizSegue", this);
        }

        public override void PrepareForSegue(UIStoryboardSegue segue, NSObject sender)
        {
            base.PrepareForSegue(segue, sender);

            var controller = segue.DestinationViewController as QuizController;
            controller.CourseID = this.CourseID;
            controller.LessonID = this.CurrentLesson.LessonNodeID;
        }

        private UIView BuildLessonContainer(UIView parent, NSLayoutYAxisAnchor anchorTopTo, bool includeVideo, Lesson lesson)
        {
            // All of our wonderful dynamic views
            var vwContainer = new UIView() { TranslatesAutoresizingMaskIntoConstraints = false };
            var imgVideo = new UIImageView() { TranslatesAutoresizingMaskIntoConstraints = false };
            var lblCourseName = new UILabel() { TranslatesAutoresizingMaskIntoConstraints = false };
            var lblLessonName = new UILabel() { TranslatesAutoresizingMaskIntoConstraints = false };

            // Some hard-coded settings
            var padding = 10;
            var videowidth = 100;

            // add the constraints
            parent.Add(vwContainer);
            vwContainer.Layer.BackgroundColor = UIColor.White.CGColor;
            vwContainer.TopAnchor.ConstraintEqualTo(anchorTopTo, padding).Active = true;
            vwContainer.LeadingAnchor.ConstraintEqualTo(parent.LeadingAnchor).Active = true;
            vwContainer.TrailingAnchor.ConstraintEqualTo(parent.TrailingAnchor).Active = true;

            // add the video
            if (includeVideo && lesson.LessonItems.Any(i => i.Type == Constants.LessonItemType.Video))
            {
                var youtubeUrl = lesson.LessonItems.FirstOrDefault(i => i.Type == Constants.LessonItemType.Video).VideoURL;
                var youtubeID = VideoHelper.ParseYouTubeID(youtubeUrl);
                var youtubeImageUrl = $"https://img.youtube.com/vi/{youtubeID}/default.jpg";
                imgVideo.Image = UIViewHelper.FromUrl(youtubeImageUrl);
                vwContainer.Add(imgVideo);
                imgVideo.LeadingAnchor.ConstraintEqualTo(vwContainer.LeadingAnchor, 0).Active = true;
                imgVideo.TopAnchor.ConstraintEqualTo(vwContainer.TopAnchor).Active = true;
                imgVideo.BottomAnchor.ConstraintEqualTo(vwContainer.BottomAnchor).Active = true;
                imgVideo.HeightAnchor.ConstraintEqualTo(80).Active = true;
                imgVideo.WidthAnchor.ConstraintEqualTo(100).Active = true;

                lblCourseName.Text = Course.Name;
                vwContainer.Add(lblCourseName);
                lblCourseName.TopAnchor.ConstraintEqualTo(vwContainer.TopAnchor, padding).Active = true;
                lblCourseName.LeadingAnchor.ConstraintEqualTo(imgVideo.TrailingAnchor, padding).Active = true;
                lblCourseName.TrailingAnchor.ConstraintEqualTo(vwContainer.TrailingAnchor, -padding).Active = true;

                lblLessonName.Text = lesson.Name;
                lblLessonName.Font = UIFont.SystemFontOfSize(20, UIFontWeight.Bold);
                vwContainer.Add(lblLessonName);
                lblLessonName.TopAnchor.ConstraintEqualTo(lblCourseName.BottomAnchor, padding).Active = true;
                lblLessonName.LeadingAnchor.ConstraintEqualTo(imgVideo.TrailingAnchor, padding).Active = true;
                lblLessonName.TrailingAnchor.ConstraintEqualTo(vwContainer.TrailingAnchor, -padding).Active = true;
                lblLessonName.BottomAnchor.ConstraintEqualTo(vwContainer.BottomAnchor).Active = true;
            }
            else
            {
                lblCourseName.Text = Course.Name;
                vwContainer.Add(lblCourseName);
                lblCourseName.TopAnchor.ConstraintEqualTo(vwContainer.TopAnchor, padding).Active = true;
                lblCourseName.LeadingAnchor.ConstraintEqualTo(vwContainer.LeadingAnchor, padding).Active = true;
                lblCourseName.TrailingAnchor.ConstraintEqualTo(vwContainer.TrailingAnchor, -padding).Active = true;

                lblLessonName.Text = lesson.Name;
                lblLessonName.Font = UIFont.SystemFontOfSize(20, UIFontWeight.Bold);
                vwContainer.Add(lblLessonName);
                lblLessonName.TopAnchor.ConstraintEqualTo(lblCourseName.BottomAnchor, padding).Active = true;
                lblLessonName.LeadingAnchor.ConstraintEqualTo(vwContainer.LeadingAnchor, padding).Active = true;
                lblLessonName.TrailingAnchor.ConstraintEqualTo(vwContainer.TrailingAnchor, -padding).Active = true;
                lblLessonName.BottomAnchor.ConstraintEqualTo(vwContainer.BottomAnchor).Active = true;
            }


            return vwContainer;
        }
    }
}