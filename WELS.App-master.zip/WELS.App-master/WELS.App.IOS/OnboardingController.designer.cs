// WARNING
//
// This file has been generated automatically by Visual Studio from the outlets and
// actions declared in your storyboard file.
// Manual changes to this file will not be maintained.
//
using Foundation;
using System;
using System.CodeDom.Compiler;
using UIKit;

namespace WELS.App.IOS
{
    [Register ("OnboardingController")]
    partial class OnboardingController
    {
        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UIButton btnAnswer1 { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UIButton btnAnswer2 { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UIButton btnAnswer3 { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UIButton btnAnswer4 { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UIImageView imgBackground { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UIImageView imgLogo { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UILabel lblIntro { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UILabel lblWelcome { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UILabel txtQuestion { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UIView vwContainer { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UIProgressView vwProgress { get; set; }

        void ReleaseDesignerOutlets ()
        {
            if (btnAnswer1 != null) {
                btnAnswer1.Dispose ();
                btnAnswer1 = null;
            }

            if (btnAnswer2 != null) {
                btnAnswer2.Dispose ();
                btnAnswer2 = null;
            }

            if (btnAnswer3 != null) {
                btnAnswer3.Dispose ();
                btnAnswer3 = null;
            }

            if (btnAnswer4 != null) {
                btnAnswer4.Dispose ();
                btnAnswer4 = null;
            }

            if (imgBackground != null) {
                imgBackground.Dispose ();
                imgBackground = null;
            }

            if (imgLogo != null) {
                imgLogo.Dispose ();
                imgLogo = null;
            }

            if (lblIntro != null) {
                lblIntro.Dispose ();
                lblIntro = null;
            }

            if (lblWelcome != null) {
                lblWelcome.Dispose ();
                lblWelcome = null;
            }

            if (txtQuestion != null) {
                txtQuestion.Dispose ();
                txtQuestion = null;
            }

            if (vwContainer != null) {
                vwContainer.Dispose ();
                vwContainer = null;
            }

            if (vwProgress != null) {
                vwProgress.Dispose ();
                vwProgress = null;
            }
        }
    }
}