using Foundation;
using System;
using UIKit;

namespace WELS.App.IOS
{
    public partial class MainController : UITabBarController
    {
        public MainController(IntPtr handle) : base(handle)
        {
        }

        public override void ViewDidLoad()
        {
            base.ViewDidLoad();

            Localize();
        }

        private void Localize()
        {
            navMenu.Items[0].Title = AppDelegate.BundleToUse.GetLocalizedString("title_courses");
            navMenu.Items[1].Title = AppDelegate.BundleToUse.GetLocalizedString("title_profile");
            navMenu.Items[2].Title = AppDelegate.BundleToUse.GetLocalizedString("title_menu");
        }
    }
}