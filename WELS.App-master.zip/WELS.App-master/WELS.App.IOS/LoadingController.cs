using Facebook.CoreKit;
using Foundation;
using System;
using System.Linq;
using System.Threading.Tasks;
using UIKit;

namespace WELS.App.IOS
{
    public partial class LoadingController : UIViewController
    {
        public LoadingController (IntPtr handle) : base (handle)
        {
        }

        public override void ViewDidLoad()
        {
            base.ViewDidLoad();

            Localize();

            NavigationController.NavigationBarHidden = true;
        }

        public async override void ViewWillAppear(bool animated)
        {
            base.ViewWillAppear(animated);

            await NextSegue();
        }

        private void Localize()
        {
            lblLoading.Text = AppDelegate.BundleToUse.GetLocalizedString("loading_message");
        }

        public async Task NextSegue()
        {
#if (ACADEMIACRISTO)
            AppDelegate.AccountSource = "AC App (iOS)";
#else
            AppDelegate.AccountSource = "TELL App (iOS)";
#endif
            var accessToken = AccessToken.CurrentAccessToken;
            var isLoggedInToFacebook = accessToken != null && !accessToken.IsExpired;
            var isLoggedInViaWhatsApp = !string.IsNullOrEmpty(AppDelegate.DataHelper.WhatsAppNumberForLogin) && AppDelegate.DataHelper.IsApiTokenActive();
            var completedFirstCourse = await AppDelegate.DataHelper.HasAccountCompletedFirstCourse((await AppDelegate.CurrentLanguage()).LanguageNodeID);

            // Redirect to welcome video if we haven't watched it yet
            if (!AppDelegate.DataHelper.UserHasWatchedWelcomeVideo)
            {
                this.TabBarController.TabBar.Hidden = true;
                this.PerformSegue("WelcomeVideoSegue", this);
            }
            else if (!isLoggedInToFacebook && !isLoggedInViaWhatsApp && completedFirstCourse)
            {
                this.TabBarController.TabBar.Hidden = true;
                this.PerformSegue("LoginSegue", this);
            }
            else
            {
                if (isLoggedInToFacebook)
                {
                    Profile.CurrentProfile = await Profile.LoadCurrentProfileAsync();
                    await AppDelegate.DataHelper.SetFacebookLogin(accessToken.UserId, accessToken.TokenString, accessToken.AppId);
                    AppDelegate.CurrentAccount = await AppDelegate.DataHelper.GetAccount((await AppDelegate.CurrentLanguage()).LanguageNodeID, AppDelegate.AccountSource, Profile.CurrentProfile.Name, Profile.CurrentProfile.ImageUrl(ProfilePictureMode.Square, new CoreGraphics.CGSize(68, 68)).AbsoluteString);
                }
                else
                {
                    AppDelegate.CurrentAccount = await AppDelegate.DataHelper.GetAccount((await AppDelegate.CurrentLanguage()).LanguageNodeID, AppDelegate.AccountSource);
                }
                // Failsafe for pre-existing accounts that have logged in, but haven't had the new HasAuthenticated flag set
                if ((isLoggedInToFacebook | isLoggedInViaWhatsApp) && !AppDelegate.CurrentAccount.HasAuthenticated)
                {
                    AppDelegate.CurrentAccount.HasAuthenticated = true;
                    await AppDelegate.DataHelper.SaveAccount(AppDelegate.CurrentAccount);
                }

                // Reload static Courses var from DB in case anything has changed
                AppDelegate.ReloadCoursesFromDB();

                this.TabBarController.TabBar.Hidden = false;
                // HACK: Loading profile doesn't always work right away, so keep trying
                //while (Profile.CurrentProfile == null)
                //{
                //    Profile.LoadCurrentProfile(null);
                //}
                
                // TOOD: REMOVE THIS TEMPORARY LINE FOR TESTING VARIOUS SEGUES
                //this.PerformSegue("CourseEndSegue", this);
                //return;

                if (AppDelegate.CurrentAccount.LanguageNodeID == null)
                {
                    if ((await AppDelegate.CurrentLanguage()) != null)
                    {
                        AppDelegate.CurrentAccount.LanguageNodeID = (await AppDelegate.CurrentLanguage()).LanguageNodeID;

                        await AppDelegate.DataHelper.SyncEncouragementMessages(AppDelegate.CurrentAccount.LanguageNodeID.Value);
                        await AppDelegate.DataHelper.SaveAccount(AppDelegate.CurrentAccount);
                        await NextSegue();
                    }
                    else
                    {
                        // TODO: Pop up error message
                        //// No languages found
                        //Intent messageIntent = new Intent(currentActivity, typeof(MessageActivity));
                        //messageIntent.PutExtra("Message", currentActivity.GetString(Resource.String.error_missing_languages));
                        //currentActivity.StartActivity(messageIntent);
                    }
                }
                else if (AppDelegate.CurrentAccount.DateCompletedOnboarding == null && completedFirstCourse)
                {
                    var onboarding = await AppDelegate.DataHelper.GetOnboarding(AppDelegate.CurrentAccount.LanguageNodeID ?? 0);
                    var sortedVideos = onboarding.Videos.OrderBy(v => v.MinimumScore);
                    var video = sortedVideos.FirstOrDefault();

                    // If there are no videos, complete onboarding and move on
                    if (video == null || string.IsNullOrWhiteSpace(video.VideoURL))
                    {
                        AppDelegate.CurrentAccount.OnBoardingTotalScore = 99;
                        AppDelegate.CurrentAccount.DateCompletedOnboarding = DateTime.UtcNow;
                        await AppDelegate.DataHelper.SaveAccount(AppDelegate.CurrentAccount);
                        await NextSegue();
                    }
                    else
                    {
                        // START ONBOARDING ACTIVITY
                        this.PerformSegue("OnboardingVideoSegue", this);
                    }
                }
                else if (AppDelegate.Courses.Any() && (AppDelegate.CurrentAccount.HasDownloadedAllCourses || !completedFirstCourse))
                {
                    if (AppDelegate.CurrentAccount.DateCompletedAllCourses == null || AppDelegate.GoRightToCourseList)
                    {
                        this.PerformSegue("CourseListSegue", this);
                    }
                    else
                    {
                        this.PerformSegue("CourseEndSegue", this);
                    }
                }
                else
                {
                    AppDelegate.CourseDownloadStarted = true;

                    // Get all course data, then go to the next activity
                    await AppDelegate.DataHelper.SyncCourses((await AppDelegate.CurrentLanguage()).LanguageNodeID);
                    AppDelegate.ReloadCoursesFromDB();
                    if (!AppDelegate.Courses.Any())
                    {
                        // No courses?
                    }
                    else
                    {
                        await NextSegue();
                    }
                }
            }
        }
    }
}