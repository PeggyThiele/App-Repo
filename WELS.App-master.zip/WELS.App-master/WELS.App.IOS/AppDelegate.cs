﻿using Facebook.CoreKit;
using Facebook.LoginKit;
using Foundation;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using UIKit;
using WELS.App.Shared.Data;
using WELS.App.Shared.Helpers;
using WELS.App.Shared.Models.Response;
using Xamarin;
using Xamarin.Essentials;

namespace WELS.App.IOS
{
    // The UIApplicationDelegate for the application. This class is responsible for launching the
    // User Interface of the application, as well as listening (and optionally responding) to application events from iOS.
    [Register ("AppDelegate")]
    public class AppDelegate : UIResponder, IUIApplicationDelegate {
        public static bool GoRightToNextLesson { get; set; } = false;
        public static bool GoRightToCourseList { get; set; } = false;
        public static Account CurrentAccount { get; set; }
        public static string AccountSource { get; set; }
        public static bool CourseDownloadStarted { get; set; } = false;
        public static List<Course> Courses { get; private set; } = new List<Course>();
        public static AppDataHelper DataHelper { get; } = new AppDataHelper(new AppDataHelperSettings()
        {
            DefaultEncouragementMessage = "May God bless you on your spiritual journey!"
        });
        public static NSBundle BundleToUse { get; private set; }

        [Export("window")]
        public UIWindow Window { get; set; }

        [Export ("application:didFinishLaunchingWithOptions:")]
        public bool FinishedLaunching (UIApplication application, NSDictionary launchOptions)
        {
#if ACADEMIACRISTO
            BundleToUse = new NSBundle(NSBundle.MainBundle.PathForResource("es", "lproj"));
            CultureInfo.DefaultThreadCurrentCulture = new CultureInfo("es-MX");
            CultureInfo.DefaultThreadCurrentUICulture = new CultureInfo("es-MX");
#else
            BundleToUse = new NSBundle(NSBundle.MainBundle.PathForResource("Base", "lproj"));
            CultureInfo.DefaultThreadCurrentCulture = new CultureInfo("en-US");
            CultureInfo.DefaultThreadCurrentUICulture = new CultureInfo("en-US");
#endif

            Facebook.CoreKit.ApplicationDelegate.SharedInstance.FinishedLaunching(application, launchOptions);
            Profile.EnableUpdatesOnAccessTokenChange(true);

            // If this is a reinstall, clear any old token on first run
            if (VersionTracking.IsFirstLaunchEver)
            {
                DataHelper.ClearToken();
                DataHelper.UserHasWatchedWelcomeVideo = false;
            }

            IQKeyboardManager.SharedManager.Enable = true;

            return true;
        }

        [Export("application:openURL:options:")]
        public virtual bool OpenUrl(UIApplication application, NSUrl url, NSDictionary options)
        {
            Facebook.CoreKit.ApplicationDelegate.SharedInstance.OpenUrl(application, url, options);
            return true;
        }

        // UISceneSession Lifecycle

        [Export ("application:configurationForConnectingSceneSession:options:")]
        public UISceneConfiguration GetConfiguration (UIApplication application, UISceneSession connectingSceneSession, UISceneConnectionOptions options)
        {
            // Called when a new scene session is being created.
            // Use this method to select a configuration to create the new scene with.
            return UISceneConfiguration.Create ("Default Configuration", connectingSceneSession.Role);
        }

        [Export ("application:didDiscardSceneSessions:")]
        public void DidDiscardSceneSessions (UIApplication application, NSSet<UISceneSession> sceneSessions)
        {
            // Called when the user discards a scene session.
            // If any sessions were discarded while the application was not running, this will be called shortly after `FinishedLaunching`.
            // Use this method to release any resources that were specific to the discarded scenes, as they will not return.
        }

        /// <summary>
        /// Call this every time we change users or enable/disable notifications within the app
        /// </summary>
        public static void RefreshPushNotificationTags()
        {
            Task.Run(() =>
            {
                if (AppDelegate.CurrentAccount != null)
                {
                    //TODO: Wire this up for iOS push notifications
                    //var hub = new NotificationHub(App.NotificationHubName,
                    //                            App.ListenConnectionString, App.Context);
                    //if (App.CurrentAccount.EnablePushNotifications)
                    //{

                    //    string[] tags = new string[] { $"user:{FacebookSdk.ApplicationId}_{AccessToken.CurrentAccessToken.UserId}" };
                    //    hub.Register(FirebaseInstanceId.Instance.Token, tags);
                    //    Log.Debug("App", $"Registered {FirebaseInstanceId.Instance.Token} Push Notification Tag: {tags[0]}");
                    //}
                    //else
                    //{
                    //    hub.UnregisterAll(FirebaseInstanceId.Instance.Token);
                    //    Log.Debug("App", $"Unregistered {FirebaseInstanceId.Instance.Token} all tags");
                    //}
                }
            });
        }

        public static void ReloadCoursesFromDB()
        {
            if (CurrentAccount.LanguageNodeID != null)
            {
                Courses = DataHelper.GetCoursesFromDB(CurrentAccount.LanguageNodeID.Value).ToList();
            }
        }

        public static List<LanguageResponse> Languages;
        private static LanguageResponse _currentLanguage;
        public static async Task<LanguageResponse> CurrentLanguage()
        {
            if (_currentLanguage == null)
            {
                if (Languages == null || !Languages.Any())
                {
                    Languages = (await AppDelegate.DataHelper.GetLanguages()).ToList();
#if (ACADEMIACRISTO)
            _currentLanguage = Languages.FirstOrDefault(l => l.CultureCode.ToLower() == "es-mx");
#else
                    _currentLanguage = Languages.FirstOrDefault(l => l.CultureCode.ToLower() == "en-us");
#endif
                }
            }
            return _currentLanguage;
        }

        public static void Logout()
        {
            (new LoginManager()).LogOut();
            DataHelper.WhatsAppNumberForLogin = null;
            DataHelper.ClearToken();
            DataHelper.ClearData();
            Courses = new List<Course>();
            CourseDownloadStarted = false;
        }
    }
}

