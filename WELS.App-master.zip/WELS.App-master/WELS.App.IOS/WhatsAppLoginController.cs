using System;
using System.Collections.Generic;
using System.Drawing;
using System.Text.RegularExpressions;
using Foundation;
using UIKit;
using WELS.App.IOS.ViewModels;

namespace WELS.App.IOS
{
	public partial class WhatsAppLoginController : UIViewController
	{
        // Login view controls
        protected UIView vwContainer;
        protected UIImageView imgLogo;
        protected UIView vwControls;
        protected UITextField txtFullName;
        protected UITextField txtCountry;
        protected UIPickerView ddlCountries;
        protected UITextField txtWhatsAppNumber;
        protected UILabel lblError;
        protected UIButton btnSubmit;

        // Verification view controls
        protected UITextView txtVerificationCode;
        protected UIButton btnVerify;

		public WhatsAppLoginController (IntPtr handle) : base (handle)
		{
		}

        public override void ViewDidLoad()
        {
            base.ViewDidLoad();

            BuildLoginView();
        }

        private void BuildLoginView()
        {
            if (vwContainer != null)
            {
                vwContainer.RemoveFromSuperview();
            }

            vwContainer = new UIView() { TranslatesAutoresizingMaskIntoConstraints = false };
            this.View.Add(vwContainer);
            vwContainer.BackgroundColor = UIColor.White;
            vwContainer.Layer.CornerRadius = 7;
            vwContainer.CenterYAnchor.ConstraintEqualTo(this.View.CenterYAnchor, 0).Active = true;
            vwContainer.LeadingAnchor.ConstraintEqualTo(this.View.LeadingAnchor, 16).Active = true;
            vwContainer.TrailingAnchor.ConstraintEqualTo(this.View.TrailingAnchor, -16).Active = true;

            imgLogo = new UIImageView() { TranslatesAutoresizingMaskIntoConstraints = false };
            imgLogo.ContentMode = UIViewContentMode.ScaleAspectFit;
#if ACADEMIACRISTO
            imgLogo.Image = UIImage.FromBundle("academia_cristo_w_tagline.png");
#else
            imgLogo.Image = UIImage.FromBundle("tell_logo_w_tagline.png");
#endif
            vwContainer.Add(imgLogo);
            imgLogo.HeightAnchor.ConstraintEqualTo(140).Active = true;
            imgLogo.TopAnchor.ConstraintEqualTo(vwContainer.TopAnchor, 16).Active = true;
            imgLogo.LeadingAnchor.ConstraintEqualTo(vwContainer.LeadingAnchor, 16).Active = true;
            imgLogo.TrailingAnchor.ConstraintEqualTo(vwContainer.TrailingAnchor, -16).Active = true;

            vwControls = new UIView() { TranslatesAutoresizingMaskIntoConstraints = false };
            vwContainer.Add(vwControls);
            vwControls.TopAnchor.ConstraintEqualTo(imgLogo.BottomAnchor, 0).Active = true;
            vwControls.BottomAnchor.ConstraintEqualTo(vwContainer.BottomAnchor, 0).Active = true;
            vwControls.LeadingAnchor.ConstraintEqualTo(vwContainer.LeadingAnchor, 0).Active = true;
            vwControls.TrailingAnchor.ConstraintEqualTo(vwContainer.TrailingAnchor, 0).Active = true;
            int margin = 16;

            var lbl1 = new UILabel() { TranslatesAutoresizingMaskIntoConstraints = false };
            lbl1.Text = AppDelegate.BundleToUse.GetLocalizedString("enter_full_name");
            lbl1.Font = UIFont.SystemFontOfSize(12);
            lbl1.TextAlignment = UITextAlignment.Center;
            lbl1.TextColor = UIColor.FromRGB(11, 48, 77);
            vwControls.Add(lbl1);
            lbl1.TopAnchor.ConstraintEqualTo(vwControls.TopAnchor, margin).Active = true;
            lbl1.LeadingAnchor.ConstraintEqualTo(vwControls.LeadingAnchor, margin).Active = true;
            lbl1.TrailingAnchor.ConstraintEqualTo(vwControls.TrailingAnchor, -margin).Active = true;
            //lbl1.BottomAnchor.ConstraintEqualTo(vwContainer.BottomAnchor, -margin).Active = true;
            //return;

            txtFullName = new UITextField() { TranslatesAutoresizingMaskIntoConstraints = false };
            txtFullName.Layer.BorderWidth = 1;
            txtFullName.Layer.BorderColor = UIColor.FromRGB(72, 89, 108).CGColor;
            txtFullName.TextColor = UIColor.FromRGB(72, 89, 108);
            txtFullName.BackgroundColor = UIColor.FromRGB(239, 238, 237);
            AddDoneButton(txtFullName);
            vwControls.Add(txtFullName);
            txtFullName.TopAnchor.ConstraintEqualTo(lbl1.BottomAnchor, margin).Active = true;
            txtFullName.LeadingAnchor.ConstraintEqualTo(vwControls.LeadingAnchor, margin).Active = true;
            txtFullName.TrailingAnchor.ConstraintEqualTo(vwControls.TrailingAnchor, -margin).Active = true;
            txtFullName.HeightAnchor.ConstraintEqualTo(30).Active = true;

            var lbl2 = new UILabel() { TranslatesAutoresizingMaskIntoConstraints = false };
            lbl2.Text = AppDelegate.BundleToUse.GetLocalizedString("enter_whatsapp_number");
            lbl2.Font = UIFont.SystemFontOfSize(12);
            lbl2.TextAlignment = UITextAlignment.Center;
            lbl2.TextColor = UIColor.FromRGB(11, 48, 77);
            lbl2.Lines = 2;
            vwControls.Add(lbl2);
            lbl2.TopAnchor.ConstraintEqualTo(txtFullName.BottomAnchor, margin).Active = true;
            lbl2.LeadingAnchor.ConstraintEqualTo(vwContainer.LeadingAnchor, margin).Active = true;
            lbl2.TrailingAnchor.ConstraintEqualTo(vwContainer.TrailingAnchor, -margin).Active = true;

            txtCountry = new UITextField() { TranslatesAutoresizingMaskIntoConstraints = false };
            ddlCountries = new UIPickerView() { TranslatesAutoresizingMaskIntoConstraints = false };
            ddlCountries.Layer.BorderWidth = 1;
            ddlCountries.Layer.BorderColor = UIColor.FromRGB(72, 89, 108).CGColor;
            ddlCountries.BackgroundColor = UIColor.FromRGB(239, 238, 237);
            ddlCountries.Model = new StringListPickerViewModel(countries);
            ddlCountries.ShowSelectionIndicator = true;
            var screenWidth = UIScreen.MainScreen.Bounds.Width;
            var pickerToolBar = new UIToolbar(new RectangleF(0, 0, (float)screenWidth, 44)) { BarStyle = UIBarStyle.Default, Translucent = true };
            var flexibleSpaceButton = new UIBarButtonItem(UIBarButtonSystemItem.FlexibleSpace);
            var doneButton = new UIBarButtonItem(UIBarButtonSystemItem.Done, (sender, e) =>
            {
                txtCountry.Text = ((StringListPickerViewModel)ddlCountries.Model).SelectedItem;
                txtCountry.ResignFirstResponder();
            });
            pickerToolBar.SetItems(new[] { flexibleSpaceButton, doneButton }, false);
            //vwContainer.Add(ddlCountries);
            //ddlCountries.TopAnchor.ConstraintEqualTo(lbl2.BottomAnchor, margin).Active = true;
            //ddlCountries.LeadingAnchor.ConstraintEqualTo(vwContainer.LeadingAnchor, margin).Active = true;
            //ddlCountries.TrailingAnchor.ConstraintEqualTo(vwContainer.TrailingAnchor, -margin).Active = true;
            //ddlCountries.HeightAnchor.ConstraintEqualTo(30).Active = true;

            txtCountry.Layer.BorderWidth = 1;
            txtCountry.Layer.BorderColor = UIColor.FromRGB(72, 89, 108).CGColor;
            txtCountry.TextColor = UIColor.FromRGB(72, 89, 108);
            txtCountry.BackgroundColor = UIColor.FromRGB(239, 238, 237);
            txtCountry.InputView = ddlCountries;
            txtCountry.InputAccessoryView = pickerToolBar;
            txtCountry.Placeholder = AppDelegate.BundleToUse.GetLocalizedString("country");
            vwControls.Add(txtCountry);
            txtCountry.TopAnchor.ConstraintEqualTo(lbl2.BottomAnchor, margin).Active = true;
            txtCountry.LeadingAnchor.ConstraintEqualTo(vwControls.LeadingAnchor, margin).Active = true;
            txtCountry.TrailingAnchor.ConstraintEqualTo(vwControls.TrailingAnchor, -margin).Active = true;
            txtCountry.HeightAnchor.ConstraintEqualTo(30).Active = true;

            txtWhatsAppNumber = new UITextField() { TranslatesAutoresizingMaskIntoConstraints = false };
            txtWhatsAppNumber.Layer.BorderWidth = 1;
            txtWhatsAppNumber.Layer.BorderColor = UIColor.FromRGB(72, 89, 108).CGColor;
            txtWhatsAppNumber.TextColor = UIColor.FromRGB(72, 89, 108);
            txtWhatsAppNumber.BackgroundColor = UIColor.FromRGB(239, 238, 237);
            txtWhatsAppNumber.KeyboardType = UIKeyboardType.NumberPad;
            AddDoneButton(txtWhatsAppNumber);
            vwControls.Add(txtWhatsAppNumber);
            txtWhatsAppNumber.TopAnchor.ConstraintEqualTo(txtCountry.BottomAnchor, margin).Active = true;
            txtWhatsAppNumber.LeadingAnchor.ConstraintEqualTo(vwControls.LeadingAnchor, margin).Active = true;
            txtWhatsAppNumber.TrailingAnchor.ConstraintEqualTo(vwControls.TrailingAnchor, -margin).Active = true;
            txtWhatsAppNumber.HeightAnchor.ConstraintEqualTo(30).Active = true;

            var btnSubmit = new UIButton() { TranslatesAutoresizingMaskIntoConstraints = false };
            btnSubmit.BackgroundColor = UIColor.FromRGB(28, 117, 188);
            btnSubmit.SetTitle(AppDelegate.BundleToUse.GetLocalizedString("button_whatsapp_verify"), UIControlState.Normal);
            vwControls.Add(btnSubmit);
            btnSubmit.TopAnchor.ConstraintEqualTo(txtWhatsAppNumber.BottomAnchor, margin).Active = true;
            btnSubmit.LeadingAnchor.ConstraintEqualTo(vwControls.LeadingAnchor, margin).Active = true;
            btnSubmit.TrailingAnchor.ConstraintEqualTo(vwControls.TrailingAnchor, -margin).Active = true;
            btnSubmit.HeightAnchor.ConstraintEqualTo(50).Active = true;

            lblError = new UILabel() { TranslatesAutoresizingMaskIntoConstraints = false };
            lblError.Text = AppDelegate.BundleToUse.GetLocalizedString("error_whatsapp_fields_required");
            lblError.Font = UIFont.SystemFontOfSize(12);
            lblError.TextAlignment = UITextAlignment.Center;
            lblError.TextColor = UIColor.Red;
            lblError.Lines = 2;
            lblError.Hidden = true;
            vwControls.Add(lblError);
            lblError.TopAnchor.ConstraintEqualTo(btnSubmit.BottomAnchor, margin).Active = true;
            lblError.LeadingAnchor.ConstraintEqualTo(vwControls.LeadingAnchor, margin).Active = true;
            lblError.TrailingAnchor.ConstraintEqualTo(vwControls.TrailingAnchor, -margin).Active = true;
            lblError.BottomAnchor.ConstraintEqualTo(vwControls.BottomAnchor, -margin).Active = true;

            // Event handlers
            btnSubmit.TouchUpInside += async (sender, e) =>
            {
                // Get user-entered name and whatsapp number
                txtFullName.Text = txtFullName.Text.Trim();
                var fullName = txtFullName.Text;
                var countryCode = (string)txtCountry.Text;
                var whatsAppNumber = txtWhatsAppNumber.Text;

                if (fullName.Length < 3 || whatsAppNumber.Length < 7 || string.IsNullOrEmpty(countryCode) || countryCode == "Country" || countryCode == "Pa�s")
                {
                    lblError.Hidden = false;
                    return;
                }

                // Normalize the whatsapp number - remove all non-numeric chars and prefix with "+"
                whatsAppNumber = "+" + Regex.Replace(countryCode + whatsAppNumber, "[^0-9]", "");
                txtWhatsAppNumber.Text = whatsAppNumber;

                AppDelegate.DataHelper.SendWhatsAppVerificationCode((await AppDelegate.CurrentLanguage()).LanguageNodeID, whatsAppNumber);

                BuildVerificationView();
            };
        }

        private void BuildVerificationView()
        {
            if (vwControls != null)
            {
                vwControls.RemoveFromSuperview();
            }
            vwControls = new UIView() { TranslatesAutoresizingMaskIntoConstraints = false };
            vwContainer.Add(vwControls);
            vwControls.TopAnchor.ConstraintEqualTo(imgLogo.BottomAnchor, 0).Active = true;
            vwControls.BottomAnchor.ConstraintEqualTo(vwContainer.BottomAnchor, 0).Active = true;
            vwControls.LeadingAnchor.ConstraintEqualTo(vwContainer.LeadingAnchor, 0).Active = true;
            vwControls.TrailingAnchor.ConstraintEqualTo(vwContainer.TrailingAnchor, 0).Active = true;
            int margin = 16;

            var lbl1 = new UILabel() { TranslatesAutoresizingMaskIntoConstraints = false };
            lbl1.Text = AppDelegate.BundleToUse.GetLocalizedString("enter_verification_code");
            lbl1.Font = UIFont.SystemFontOfSize(12);
            lbl1.TextAlignment = UITextAlignment.Center;
            lbl1.TextColor = UIColor.FromRGB(11, 48, 77);
            vwControls.Add(lbl1);
            lbl1.TopAnchor.ConstraintEqualTo(vwControls.TopAnchor, margin).Active = true;
            lbl1.LeadingAnchor.ConstraintEqualTo(vwControls.LeadingAnchor, margin).Active = true;
            lbl1.TrailingAnchor.ConstraintEqualTo(vwControls.TrailingAnchor, -margin).Active = true;

            txtVerificationCode = new UITextView() { TranslatesAutoresizingMaskIntoConstraints = false };
            txtVerificationCode.Layer.BorderWidth = 1;
            txtVerificationCode.Layer.BorderColor = UIColor.FromRGB(72, 89, 108).CGColor;
            txtVerificationCode.TextColor = UIColor.FromRGB(72, 89, 108);
            txtVerificationCode.BackgroundColor = UIColor.FromRGB(239, 238, 237);
            vwControls.Add(txtVerificationCode);
            txtVerificationCode.TopAnchor.ConstraintEqualTo(lbl1.BottomAnchor, margin).Active = true;
            txtVerificationCode.LeadingAnchor.ConstraintEqualTo(vwControls.LeadingAnchor, margin).Active = true;
            txtVerificationCode.TrailingAnchor.ConstraintEqualTo(vwControls.TrailingAnchor, -margin).Active = true;
            txtVerificationCode.HeightAnchor.ConstraintEqualTo(30).Active = true;

            btnVerify = new UIButton() { TranslatesAutoresizingMaskIntoConstraints = false };
            btnVerify.BackgroundColor = UIColor.FromRGB(28, 117, 188);
            btnVerify.SetTitle(AppDelegate.BundleToUse.GetLocalizedString("button_verify"), UIControlState.Normal);
            vwControls.Add(btnVerify);
            btnVerify.TopAnchor.ConstraintEqualTo(txtVerificationCode.BottomAnchor, margin).Active = true;
            btnVerify.LeadingAnchor.ConstraintEqualTo(vwControls.LeadingAnchor, margin).Active = true;
            btnVerify.TrailingAnchor.ConstraintEqualTo(vwControls.TrailingAnchor, -margin).Active = true;
            btnVerify.HeightAnchor.ConstraintEqualTo(50).Active = true;

            lblError = new UILabel() { TranslatesAutoresizingMaskIntoConstraints = false };
            lblError.Text = AppDelegate.BundleToUse.GetLocalizedString("error_invalid_whatsapp_code");
            lblError.Font = UIFont.SystemFontOfSize(12);
            lblError.TextAlignment = UITextAlignment.Center;
            lblError.TextColor = UIColor.Red;
            lblError.Lines = 2;
            lblError.Hidden = true;
            vwControls.Add(lblError);
            lblError.TopAnchor.ConstraintEqualTo(btnVerify.BottomAnchor, margin).Active = true;
            lblError.LeadingAnchor.ConstraintEqualTo(vwControls.LeadingAnchor, margin).Active = true;
            lblError.TrailingAnchor.ConstraintEqualTo(vwControls.TrailingAnchor, -margin).Active = true;
            lblError.BottomAnchor.ConstraintEqualTo(vwControls.BottomAnchor, -margin).Active = true;

            // Event handlers
            btnVerify.TouchUpInside += async (sender, e) =>
            {
                lblError.Hidden = true;

                var code = txtVerificationCode.Text;

                // Attempt to login with this code as the password
                try
                {
                    await AppDelegate.DataHelper.SetWhatsAppLogin(txtWhatsAppNumber.Text, (await AppDelegate.CurrentLanguage()).LanguageNodeID, code);
                    AppDelegate.CurrentAccount = await AppDelegate.DataHelper.GetAccount((await AppDelegate.CurrentLanguage()).LanguageNodeID, AppDelegate.AccountSource, txtFullName.Text);
                    await AppDelegate.DataHelper.LoadAccountDataFromAPI(AppDelegate.CurrentAccount);
                    AppDelegate.CurrentAccount.HasAuthenticated = true;
                    await AppDelegate.DataHelper.SaveAccount(AppDelegate.CurrentAccount);

                    // Store this for later
                    AppDelegate.DataHelper.WhatsAppNumberForLogin = txtWhatsAppNumber.Text;

                    this.NavigationController.PopToRootViewController(false);
                }
                catch (System.Exception ex)
                {
                    lblError.Hidden = false;
                }
            };
        }
        protected void AddDoneButton(UITextField textField)
        {
            UIToolbar toolbar = new UIToolbar(new RectangleF(0.0f, 0.0f, 50.0f, 44.0f));
            var doneButton = new UIBarButtonItem(UIBarButtonSystemItem.Done, delegate
            {
                textField.ResignFirstResponder();
            });

            toolbar.Items = new UIBarButtonItem[] {
                new UIBarButtonItem (UIBarButtonSystemItem.FlexibleSpace),
                doneButton
            };

            textField.InputAccessoryView = toolbar;
        }
#if ACADEMIACRISTO
        List<string> countries = new List<string>()
        {
            "Pa�s",
            "Alemania (+49)",
            "Andorra (+376)",
            "Angola (+244)",
            "Anguilla (+1264)",
            "Antigua y Barbuda (+1268)",
            "Arabia Saudita (+966)",
            "Argelia (+213)",
            "Argentina (+54)",
            "Armenia (+374)",
            "Aruba (+297)",
            "Australia (+61)",
            "Austria (+43)",
            "Azerbaiy�n (+994)",
            "Bahamas (+1242)",
            "Banglades (+880)",
            "Barbados (+1246)",
            "Bar�in (+973)",
            "B�lgica (+32)",
            "Belice (+501)",
            "Benin (+229)",
            "Bermudas (+1441)",
            "Bielorrusia (+375)",
            "Birmania (+95)",
            "Bolivia (+591)",
            "Bosnia Herzegovina (+387)",
            "Botsuana (+267)",
            "Brasil (+55)",
            "Brunei (+673)",
            "Bulgaria (+359)",
            "Burkina Faso (+226)",
            "Burundi (+257)",
            "Butan (+975)",
            "Cabo Verde (+238)",
            "Camboya (+855)",
            "Camer�n (+237)",
            "Canad� (+1)",
            "Chequia (+420)",
            "Chile (+56)",
            "China (+86)",
            "Chipre (+357)",
            "Colombia (+57)",
            "Comoras (+269)",
            "Congo (+242)",
            "Corea del Norte (+850)",
            "Corea del Sur (+82)",
            "Costa Rica (+506)",
            "Croatia (+385)",
            "Cuba (+53)",
            "Dinamarca (+45)",
            "Dominica (+1809)",
            "Ecuador (+593)",
            "Egipto (+20)",
            "El Salvador (+503)",
            "Emiratos �rabes Unidos (+971)",
            "Eritrea (+291)",
            "Eslovenia (+386)",
            "Espa�a (+34)",
            "Estados Unidos (+1)",
            "Estonia (+372)",
            "Etiop�a (+251)",
            "Filipinas (+63)",
            "Finlandia (+358)",
            "Fiyi (+679)",
            "Francia (+33)",
            "Gab�n (+241)",
            "Gambia (+220)",
            "Georgia (+7880)",
            "Ghana (+233)",
            "Gibraltar (+350)",
            "Granada (+1473)",
            "Grecia (+30)",
            "Groenlandi (+299)",
            "Guadalupe (+590)",
            "Guam (+671)",
            "Guatemala (+502)",
            "Guayana Francesa (+594)",
            "Guinea - Bissau (+245)",
            "Guinea (+224)",
            "Guinea Ecuatorial (+240)",
            "Guyana (+592)",
            "Haiti (+509)",
            "Holanda (+31)",
            "Honduras (+504)",
            "Hong Kong (+852)",
            "Hungr�a (+36)",
            "India (+91)",
            "Indonesia (+62)",
            "Ir�n (+98)",
            "Iraq (+964)",
            "Irlanda (+353)",
            "Islandia (+354)",
            "IslaNorfolk (+672)",
            "Islas Caim�n (+1345)",
            "Islas Cook (+682)",
            "Islas Feroe (+298)",
            "Islas Malvinas (+500)",
            "Islas Marshall (+692)",
            "Islas Salom�n (+677)",
            "Islas Turks & Caicos (+1649)",
            "Islas V�rgenes Brit�nicas (+1284)",
            "Islas V�rgenes de los Estados Unidos (+1340)",
            "IslasMarianasdelNorte (+670)",
            "Israel (+972)",
            "Italia (+39)",
            "Jamaica (+1876)",
            "Jap�n (+81)",
            "Jordania (+962)",
            "Kazajist�n (+7)",
            "Kenia (+254)",
            "Kirguist�n (+996)",
            "Kiribati (+686)",
            "Kuwait (+965)",
            "Laos (+856)",
            "Lesoto (+266)",
            "Letonia (+371)",
            "L�bano (+961)",
            "Liberia (+231)",
            "Libia (+218)",
            "Liechtenstein (+417)",
            "Lituania (+370)",
            "Luxemburgo (+352)",
            "Macao (+853)",
            "Macedonia (+389)",
            "Madagascar (+261)",
            "Malasia (+60)",
            "Malaui (+265)",
            "Maldivas (+960)",
            "Mal� (+223)",
            "Malta (+356)",
            "Marruecos (+212)",
            "Martinica (+596)",
            "Mauritania (+222)",
            "Mayotte (+269)",
            "M�xico (+52)",
            "Micronesia (+691)",
            "Moldavia (+373)",
            "Monaco (+377)",
            "Mongolia (+976)",
            "Montserrat (+1664)",
            "Mozambique (+258)",
            "Namibia (+264)",
            "Nauru (+674)",
            "Nepal (+977)",
            "Nicaragua (+505)",
            "Niger (+227)",
            "Nigeria (+234)",
            "Niue (+683)",
            "Noruega (+47)",
            "Nueva Caledonia (+687)",
            "Nueva Zealand (+64)",
            "Om�n (+968)",
            "Palaos (+680)",
            "Panam� (+507)",
            "Pap�a Nueva Guinea (+675)",
            "Paraguay (+595)",
            "Per� (+51)",
            "Polania (+48)",
            "Polinesia Francesa (+689)",
            "Portugal (+351)",
            "Puerto Rico (+1787)",
            "Qatar (+974)",
            "Reino Unido (+44)",
            "Rep�blica Centroafricana (+236)",
            "Rep�blica Dominicana (+1809)",
            "Reunion (+262)",
            "Ruanda (+250)",
            "Rumania (+40)",
            "Rusia (+7)",
            "Samoa (+685)",
            "San Crist�bal (+1869)",
            "San Marino (+378)",
            "Santa Elena (+290)",
            "Santa Luc�a (+1758)",
            "Santo Tom� y Pr�ncipe (+239)",
            "Senegal (+221)",
            "Serbia (+381)",
            "Seychelles (+248)",
            "Sierra Leone (+232)",
            "Singapur (+65)",
            "Siria (+963)",
            "Slovak Republic (+421)",
            "Somalia (+252)",
            "Sri Lanka (+94)",
            "Suazilandia (+268)",
            "Sud�frica (+27)",
            "Sud�n (+249)",
            "Suecia (+46)",
            "Suiza (+41)",
            "Surinam (+597)",
            "Tailandia (+66)",
            "Taiw�n (+886)",
            "Tajikstan (+7)",
            "Togo (+228)",
            "Tonga (+676)",
            "Trinidad & Tobago (+1868)",
            "T�nez (+216)",
            "Turkmenist�n (+993)",
            "Turqu�a (+90)",
            "Tuvalu (+688)",
            "Ucrania (+380)",
            "Uganda (+256)",
            "Uruguay (+598)",
            "Uzbekist�n (+7)",
            "Vanuatu (+678)",
            "Vatican City (+379)",
            "Venezuela (+58)",
            "Vietnam (+84)",
            "Wallis & Futuna (+681)",
            "Yemen (+967)",
            "Yibuti (+253)",
            "Zambia (+260)",
            "Zimbabue (+263)"
        };

#else
        List<string> countries = new List<string>()
        {
            "Country",
            "Algeria (+213)",
            "Andorra (+376)",
            "Angola (+244)",
            "Anguilla (+1264)",
            "Antigua & Barbuda(+1268)",
            "Argentina(+54)",
            "Armenia(+374)",
            "Aruba(+297)",
            "Australia(+61)",
            "Austria(+43)",
            "Azerbaijan(+994)",
            "Bahamas(+1242)",
            "Bahrain(+973)",
            "Bangladesh(+880)",
            "Barbados(+1246)",
            "Belarus(+375)",
            "Belgium(+32)",
            "Belize(+501)",
            "Benin(+229)",
            "Bermuda(+1441)",
            "Bhutan(+975)",
            "Bolivia(+591)",
            "Bosnia Herzegovina(+387)",
            "Botswana(+267)",
            "Brazil(+55)",
            "Brunei(+673)",
            "Bulgaria(+359)",
            "Burkina Faso(+226)",
            "Burundi(+257)",
            "Cambodia(+855)",
            "Cameroon(+237)",
            "Canada(+1)",
            "Cape Verde Islands(+238)",
            "Cayman Islands(+1345)",
            "Central African Republic(+236)",
            "Chile(+56)",
            "China(+86)",
            "Colombia(+57)",
            "Comoros(+269)",
            "Congo(+242)",
            "Cook Islands(+682)",
            "Costa Rica(+506)",
            "Croatia(+385)",
            "Cuba(+53)",
            "Cyprus North(+90392)",
            "Cyprus South(+357)",
            "Czech Republic(+42)",
            "Denmark(+45)",
            "Djibouti(+253)",
            "Dominica(+1809)",
            "Dominican Republic(+1809)",
            "Ecuador(+593)",
            "Egypt(+20)",
            "El Salvador(+503)",
            "Equatorial Guinea(+240)",
            "Eritrea(+291)",
            "Estonia(+372)",
            "Ethiopia(+251)",
            "Falkland Islands(+500)",
            "Faroe Islands(+298)",
            "Fiji(+679)",
            "Finland(+358)",
            "France(+33)",
            "French Guiana(+594)",
            "French Polynesia(+689)",
            "Gabon(+241)",
            "Gambia(+220)",
            "Georgia(+7880)",
            "Germany(+49)",
            "Ghana(+233)",
            "Gibraltar(+350)",
            "Greece(+30)",
            "Greenland(+299)",
            "Grenada(+1473)",
            "Guadeloupe(+590)",
            "Guam(+671)",
            "Guatemala(+502)",
            "Guinea(+224)",
            "Guinea - Bissau(+245)",
            "Guyana(+592)",
            "Haiti(+509)",
            "Honduras(+504)",
            "Hong Kong(+852)",
            "Hungary(+36)",
            "Iceland(+354)",
            "India(+91)",
            "Indonesia(+62)",
            "Iran(+98)",
            "Iraq(+964)",
            "Ireland(+353)",
            "Israel(+972)",
            "Italy(+39)",
            "Jamaica(+1876)",
            "Japan(+81)",
            "Jordan(+962)",
            "Kazakhstan(+7)",
            "Kenya(+254)",
            "Kiribati(+686)",
            "Korea North(+850)",
            "Korea South(+82)",
            "Kuwait(+965)",
            "Kyrgyzstan(+996)",
            "Laos(+856)",
            "Latvia(+371)",
            "Lebanon(+961)",
            "Lesotho(+266)",
            "Liberia(+231)",
            "Libya(+218)",
            "Liechtenstein(+417)",
            "Lithuania(+370)",
            "Luxembourg(+352)",
            "Macao(+853)",
            "Macedonia(+389)",
            "Madagascar(+261)",
            "Malawi(+265)",
            "Malaysia(+60)",
            "Maldives(+960)",
            "Mali(+223)",
            "Malta(+356)",
            "Marshall Islands(+692)",
            "Martinique(+596)",
            "Mauritania(+222)",
            "Mayotte(+269)",
            "Mexico(+52)",
            "Micronesia(+691)",
            "Moldova(+373)",
            "Monaco(+377)",
            "Mongolia(+976)",
            "Montserrat(+1664)",
            "Morocco(+212)",
            "Mozambique(+258)",
            "Myanmar(+95)",
            "Namibia(+264)",
            "Nauru(+674)",
            "Nepal(+977)",
            "Netherlands(+31)",
            "New Caledonia(+687)",
            "New Zealand(+64)",
            "Nicaragua(+505)",
            "Niger(+227)",
            "Nigeria(+234)",
            "Niue(+683)",
            "Norfolk Islands(+672)",
            "Northern Marianas(+670)",
            "Norway(+47)",
            "Oman(+968)",
            "Palau(+680)",
            "Panama(+507)",
            "Papua New Guinea(+675)",
            "Paraguay(+595)",
            "Peru(+51)",
            "Philippines(+63)",
            "Poland(+48)",
            "Portugal(+351)",
            "Puerto Rico(+1787)",
            "Qatar(+974)",
            "Reunion(+262)",
            "Romania(+40)",
            "Russia(+7)",
            "Rwanda(+250)",
            "San Marino(+378)",
            "Sao Tome & Principe(+239)",
            "Saudi Arabia(+966)",
            "Senegal(+221)",
            "Serbia(+381)",
            "Seychelles(+248)",
            "Sierra Leone(+232)",
            "Singapore(+65)",
            "Slovak Republic(+421)",
            "Slovenia(+386)",
            "Solomon Islands(+677)",
            "Somalia(+252)",
            "South Africa(+27)",
            "Spain(+34)",
            "Sri Lanka(+94)",
            "St.Helena(+290)",
            "St.Kitts(+1869)",
            "St.Lucia(+1758)",
            "Sudan(+249)",
            "Suriname(+597)",
            "Swaziland(+268)",
            "Sweden(+46)",
            "Switzerland(+41)",
            "Syria(+963)",
            "Taiwan(+886)",
            "Tajikstan(+7)",
            "Thailand(+66)",
            "Togo(+228)",
            "Tonga(+676)",
            "Trinidad & Tobago(+1868)",
            "Tunisia(+216)",
            "Turkey(+90)",
            "Turkmenistan(+7)",
            "Turkmenistan(+993)",
            "Turks & Caicos Islands(+1649)",
            "Tuvalu(+688)",
            "Uganda(+256)",
            "UK(+44)",
            "Ukraine(+380)",
            "United Arab Emirates(+971)",
            "Uruguay(+598)",
            "USA(+1)",
            "Uzbekistan(+7)",
            "Vanuatu(+678)",
            "Vatican City(+379)",
            "Venezuela(+58)",
            "Vietnam(+84)",
            "Virgin Islands - British(+1284)",
            "Virgin Islands - US(+1340)",
            "Wallis & Futuna(+681)",
            "Yemen(North)(+969)",
            "Yemen(South)(+967)",
            "Zambia(+260)",
            "Zimbabwe(+263)"
        };
#endif
    }
}
