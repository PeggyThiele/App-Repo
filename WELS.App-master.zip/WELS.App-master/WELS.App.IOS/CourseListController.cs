using AudioToolbox;
using CoreAnimation;
using CoreGraphics;
using Foundation;
using OpenTK.Graphics.ES11;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using UIKit;
using WELS.App.Shared.Data;

namespace WELS.App.IOS
{
    public partial class CourseListController : UIViewController
    {
        static int coursenumber = 0;
        int CourseIDToView;
        UIScrollView vwScrollView;
        List<UIView> containerViews = new List<UIView>();

        public CourseListController (IntPtr handle) : base (handle)
        {
            
        }

        public async override void ViewDidAppear(bool animated)
        {
            base.ViewDidAppear(animated);

            // If we've completed all courses, set date completed all courses and redirect to the Course End fragment
            if (!AppDelegate.GoRightToCourseList)
            {
                if (!AppDelegate.Courses.Any(c => c.DateCompleted == null))
                {
                    if (AppDelegate.CurrentAccount.DateCompletedAllCourses == null)
                    {
                        AppDelegate.CurrentAccount.DateCompletedAllCourses = DateTime.UtcNow;
                        await AppDelegate.DataHelper.SaveAccount(AppDelegate.CurrentAccount);
                    }
                    this.NavigationController.PopToRootViewController(false);
                    return;
                }
            }

            AppDelegate.GoRightToCourseList = false;

            var incomplete = AppDelegate.Courses.Where(c => c.DateCompleted == null).OrderBy(c => c.SortOrder).ToList();
            var complete = AppDelegate.Courses.Where(c => c.DateCompleted != null).OrderBy(c => c.SortOrder).ToList();

            // If we want to go right to the next lesson, go now
            if (AppDelegate.GoRightToNextLesson && incomplete.Any())
            {
                AppDelegate.GoRightToNextLesson = false;

                this.CourseIDToView = incomplete.First().CourseNodeID;
                this.PerformSegue("CourseSegue", this);
            }

            // Completely refresh the view
            if (vwScrollView != null)
            {
                vwScrollView.RemoveFromSuperview();
            }

            vwScrollView = new UIScrollView() { TranslatesAutoresizingMaskIntoConstraints = false };
            this.View.Add(vwScrollView);
            vwScrollView.TopAnchor.ConstraintEqualTo(this.View.SafeAreaLayoutGuide.TopAnchor, 0).Active = true;
            vwScrollView.BottomAnchor.ConstraintEqualTo(this.View.SafeAreaLayoutGuide.BottomAnchor, 0).Active = true;
            vwScrollView.LeadingAnchor.ConstraintEqualTo(this.View.LeadingAnchor, 0).Active = true;
            vwScrollView.TrailingAnchor.ConstraintEqualTo(this.View.TrailingAnchor, 0).Active = true;

            // Settings
            var margin = 16;


            // Create the content view
            var vwContent = new UIView() { TranslatesAutoresizingMaskIntoConstraints = false };
            //vwContent.Layer.BackgroundColor = UIColor.Red.CGColor;
            vwScrollView.Add(vwContent);
            vwContent.WidthAnchor.ConstraintEqualTo(vwScrollView.WidthAnchor).Active = true;
            //vwContent.HeightAnchor.ConstraintEqualTo(2000).Active = true;
            vwContent.TopAnchor.ConstraintEqualTo(vwScrollView.TopAnchor, 0).Active = true;
            vwContent.BottomAnchor.ConstraintEqualTo(vwScrollView.BottomAnchor, 0).Active = true;
            vwContent.LeadingAnchor.ConstraintEqualTo(vwScrollView.LeadingAnchor, 0).Active = true;
            vwContent.TrailingAnchor.ConstraintEqualTo(vwScrollView.TrailingAnchor, 0).Active = true;

            var lbl1 = new UILabel() { TranslatesAutoresizingMaskIntoConstraints = false };
            lbl1.Text = AppDelegate.BundleToUse.GetLocalizedString("courses_welcome");
            lbl1.Font = UIFont.SystemFontOfSize(20, UIFontWeight.Bold);
            lbl1.TextAlignment = UITextAlignment.Center;
            vwContent.Add(lbl1);
            lbl1.TopAnchor.ConstraintEqualTo(vwContent.TopAnchor, margin).Active = true;
            lbl1.LeadingAnchor.ConstraintEqualTo(vwContent.LeadingAnchor, margin).Active = true;
            lbl1.TrailingAnchor.ConstraintEqualTo(vwContent.TrailingAnchor, -margin).Active = true;

            var lbl2 = new UILabel() { TranslatesAutoresizingMaskIntoConstraints = false };
            lbl2.Text = AppDelegate.BundleToUse.GetLocalizedString("courses_headline");
            lbl2.Lines = 3;
            lbl2.TextAlignment = UITextAlignment.Center;
            vwContent.Add(lbl2);
            lbl2.TopAnchor.ConstraintEqualTo(lbl1.BottomAnchor, margin).Active = true;
            lbl2.LeadingAnchor.ConstraintEqualTo(vwContent.LeadingAnchor, margin).Active = true;
            lbl2.TrailingAnchor.ConstraintEqualTo(vwContent.TrailingAnchor, -margin).Active = true;

            // Create the course container view
            var vwCourseListContainer = new UIView() { TranslatesAutoresizingMaskIntoConstraints = false };
            //vwCourseListContainer.Layer.BackgroundColor = UIColor.Yellow.CGColor;
            vwContent.Add(vwCourseListContainer);
            vwCourseListContainer.TopAnchor.ConstraintEqualTo(vwContent.TopAnchor, 140).Active = true;
            vwCourseListContainer.BottomAnchor.ConstraintEqualTo(vwContent.BottomAnchor, -margin).Active = true;
            vwCourseListContainer.LeadingAnchor.ConstraintEqualTo(vwContent.LeadingAnchor, margin).Active = true;
            vwCourseListContainer.TrailingAnchor.ConstraintEqualTo(vwContent.TrailingAnchor, -margin).Active = true;


            var constraintTo = vwCourseListContainer.TopAnchor;
            //for (int i = 1; i <= 10; i++)
            //{
            //    // Add the course block
            //    var view = BuildCourseContainer(vwCourseListContainer, constraintTo, i % 3 == 0, i % 3 < 2);

            //    constraintTo = view.BottomAnchor;

            //    // Test adding section labels
            //    if (i == 2 || i == 7)
            //    {
            //        var lbl = new UILabel() { TranslatesAutoresizingMaskIntoConstraints = false };
            //        lbl.Text = "Section Label:";

            //        // add label as subview
            //        vwCourseListContainer.Add(lbl);

            //        // add the constraints
            //        lbl.TopAnchor.ConstraintEqualTo(constraintTo, margin).Active = true;
            //        lbl.LeadingAnchor.ConstraintEqualTo(vwCourseListContainer.LeadingAnchor, 0).Active = true;
            //        lbl.TrailingAnchor.ConstraintEqualTo(vwCourseListContainer.TrailingAnchor, 0).Active = true;

            //        constraintTo = lbl.BottomAnchor;
            //    }
            //}


            // Organize course list into "Current", "Next", and "Completed" sections
            if (incomplete.Any())
            {
                var view = BuildCourseContainer(vwCourseListContainer, constraintTo, false, true, incomplete.Take(1).FirstOrDefault());
                constraintTo = view.BottomAnchor;
            }
            if (incomplete.Count > 1)
            {
                var lbl = new UILabel() { TranslatesAutoresizingMaskIntoConstraints = false };
                lbl.Text = AppDelegate.BundleToUse.GetLocalizedString("courses_up_next");

                // add label as subview
                vwCourseListContainer.Add(lbl);

                // add the constraints
                lbl.TopAnchor.ConstraintEqualTo(constraintTo, margin).Active = true;
                lbl.LeadingAnchor.ConstraintEqualTo(vwCourseListContainer.LeadingAnchor, 0).Active = true;
                lbl.TrailingAnchor.ConstraintEqualTo(vwCourseListContainer.TrailingAnchor, 0).Active = true;

                constraintTo = lbl.BottomAnchor;
                foreach (var course in incomplete.Skip(1))
                {
                    var view = BuildCourseContainer(vwCourseListContainer, constraintTo, true, false, course);
                    constraintTo = view.BottomAnchor;
                }
            }
            if (complete.Any())
            {
                var lbl = new UILabel() { TranslatesAutoresizingMaskIntoConstraints = false };
                lbl.Text = AppDelegate.BundleToUse.GetLocalizedString("course_page_completed");

                // add label as subview
                vwCourseListContainer.Add(lbl);

                // add the constraints
                lbl.TopAnchor.ConstraintEqualTo(constraintTo, margin).Active = true;
                lbl.LeadingAnchor.ConstraintEqualTo(vwCourseListContainer.LeadingAnchor, 0).Active = true;
                lbl.TrailingAnchor.ConstraintEqualTo(vwCourseListContainer.TrailingAnchor, 0).Active = true;

                constraintTo = lbl.BottomAnchor;

                foreach (var course in complete)
                {
                    var view = BuildCourseContainer(vwCourseListContainer, constraintTo, false, false, course);
                    constraintTo = view.BottomAnchor;
                }
            }

            //Now constrain the last view to the bottom of the container view
            vwCourseListContainer.BottomAnchor.ConstraintEqualTo(constraintTo, 0).Active = true;
        }

        public override void ViewDidLayoutSubviews()
        {
            base.ViewDidLayoutSubviews();

            // White gradient
            var rect = new CGRect(0, 0, this.View.Frame.Width, 150);
            var view = new UIView(rect);
            var gradientLayer = new CAGradientLayer();
            gradientLayer.Frame = rect;
            gradientLayer.Colors = new CGColor[] { UIColor.White.CGColor, UIColor.Clear.CGColor };
            gradientLayer.StartPoint = new CGPoint(0, 0);
            gradientLayer.EndPoint = new CGPoint(0, 1);
            view.BackgroundColor = UIColor.White;
            view.Layer.Mask = gradientLayer;

            this.View.AddSubview(view);

            this.View.SendSubviewToBack(imgBackground);
            this.View.SendSubviewToBack(view);


            // rounded bottom corners on all containers
            foreach (var vwContainer in containerViews)
            {
                var maskPath = UIBezierPath.FromRoundedRect(vwContainer.Bounds, UIRectCorner.BottomLeft | UIRectCorner.BottomRight, new CGSize(7, 7));
                var shape = new CAShapeLayer();
                shape.Path = maskPath.CGPath;
                vwContainer.Layer.Mask = shape;
            }
        }

        private UIView BuildCourseContainer(UIView parent, NSLayoutYAxisAnchor anchorTopTo, bool showLockedIcon, bool showStartButton, Course course)
        {
            // All of our wonderful dynamic views
            var vwContainer = new UIView() { TranslatesAutoresizingMaskIntoConstraints = false };
            var vwLine = new UIView() { TranslatesAutoresizingMaskIntoConstraints = false };
            var lblCourseNumber = new UILabel() { TranslatesAutoresizingMaskIntoConstraints = false };
            var lblCourseName = new UILabel() { TranslatesAutoresizingMaskIntoConstraints = false };
            var lblLessonCount = new UILabel() { TranslatesAutoresizingMaskIntoConstraints = false };
            var lblTime = new UILabel() { TranslatesAutoresizingMaskIntoConstraints = false };
            var lblDescription = new UILabel() { TranslatesAutoresizingMaskIntoConstraints = false };
            var btnGo = new UIButton() { TranslatesAutoresizingMaskIntoConstraints = false };
            var btnStart = new UIButton() { TranslatesAutoresizingMaskIntoConstraints = false };

            // Some hard-coded settings
            var padding = 24;

            // add the constraints
            parent.Add(vwContainer);
            vwContainer.Layer.BackgroundColor = UIColor.White.CGColor;
            vwContainer.TopAnchor.ConstraintEqualTo(anchorTopTo, padding).Active = true;
            vwContainer.LeadingAnchor.ConstraintEqualTo(parent.LeadingAnchor, 0).Active = true;
            vwContainer.TrailingAnchor.ConstraintEqualTo(parent.TrailingAnchor, 0).Active = true;

            // add the colorful line
            vwLine.Layer.BackgroundColor = UIColor.FromRGB(247, 148, 30).CGColor;
            vwContainer.Add(vwLine);
            vwLine.TopAnchor.ConstraintEqualTo(vwContainer.TopAnchor, 0).Active = true;
            vwLine.LeadingAnchor.ConstraintEqualTo(vwContainer.LeadingAnchor, 0).Active = true;
            vwLine.TrailingAnchor.ConstraintEqualTo(vwContainer.TrailingAnchor, 0).Active = true;
            vwLine.HeightAnchor.ConstraintEqualTo(1).Active = true;

            // add the rest
            lblCourseNumber.Text = string.Format(AppDelegate.BundleToUse.GetLocalizedString("course_card_course_number"), course.SortOrder);
            vwContainer.Add(lblCourseNumber);
            lblCourseNumber.TopAnchor.ConstraintEqualTo(vwLine.BottomAnchor, padding).Active = true;
            lblCourseNumber.LeadingAnchor.ConstraintEqualTo(vwContainer.LeadingAnchor, padding).Active = true;
            lblCourseNumber.TrailingAnchor.ConstraintEqualTo(vwContainer.TrailingAnchor, -padding).Active = true;

            lblCourseName.Text = course.Name;
            lblCourseName.Font = UIFont.SystemFontOfSize(20, UIFontWeight.Bold);
            vwContainer.Add(lblCourseName);
            lblCourseName.TopAnchor.ConstraintEqualTo(lblCourseNumber.BottomAnchor, padding).Active = true;
            lblCourseName.LeadingAnchor.ConstraintEqualTo(vwContainer.LeadingAnchor, padding).Active = true;
            lblCourseName.TrailingAnchor.ConstraintEqualTo(vwContainer.TrailingAnchor, -padding).Active = true;

            lblLessonCount.Text = string.Format(AppDelegate.BundleToUse.GetLocalizedString("course_card_lesson_count"), course.Lessons.Count());
            vwContainer.Add(lblLessonCount);
            lblLessonCount.TopAnchor.ConstraintEqualTo(lblCourseName.BottomAnchor, 2).Active = true;
            lblLessonCount.LeadingAnchor.ConstraintEqualTo(vwContainer.LeadingAnchor, padding).Active = true;
            lblLessonCount.TrailingAnchor.ConstraintEqualTo(vwContainer.TrailingAnchor, -padding).Active = true;

            lblTime.Text = course.EstimatedDuration;
            vwContainer.Add(lblTime);
            lblTime.TopAnchor.ConstraintEqualTo(lblLessonCount.BottomAnchor, 2).Active = true;
            lblTime.LeadingAnchor.ConstraintEqualTo(vwContainer.LeadingAnchor, padding).Active = true;
            lblTime.TrailingAnchor.ConstraintEqualTo(vwContainer.TrailingAnchor, -padding).Active = true;

            lblDescription.Text = course.ShortDescription;
            lblDescription.TextAlignment = UITextAlignment.Left;
            lblDescription.LineBreakMode = UILineBreakMode.WordWrap;
            lblDescription.Lines = 0;
            vwContainer.Add(lblDescription);
            lblDescription.TopAnchor.ConstraintEqualTo(lblTime.BottomAnchor, padding).Active = true;
            lblDescription.LeadingAnchor.ConstraintEqualTo(vwContainer.LeadingAnchor, padding).Active = true;
            lblDescription.TrailingAnchor.ConstraintEqualTo(vwContainer.TrailingAnchor, -padding).Active = true;

            if (showStartButton)
            {
                btnStart.SetTitle(AppDelegate.BundleToUse.GetLocalizedString("course_card_start_lesson"), UIControlState.Normal);
                btnStart.SetTitleColor(UIColor.White, UIControlState.Normal);
                btnStart.BackgroundColor = UIColor.FromRGB(28, 117, 188);
                vwContainer.Add(btnStart);
                btnStart.TopAnchor.ConstraintEqualTo(lblDescription.BottomAnchor, padding).Active = true;
                btnStart.LeadingAnchor.ConstraintEqualTo(vwContainer.LeadingAnchor, 0).Active = true;
                btnStart.TrailingAnchor.ConstraintEqualTo(vwContainer.TrailingAnchor, 0).Active = true;
                btnStart.HeightAnchor.ConstraintEqualTo(50).Active = true;
                btnStart.BottomAnchor.ConstraintEqualTo(vwContainer.BottomAnchor, 0).Active = true;
                btnStart.TouchUpInside += BtnStart_TouchUpInside;
                btnStart.Tag = course.CourseNodeID;
                btnStart.Layer.CornerRadius = 7;
            }
            else
            {
                lblDescription.BottomAnchor.ConstraintEqualTo(vwContainer.BottomAnchor, -padding).Active = true;
            }

            // Anything below here will not affect the size of the container
            vwContainer.Add(btnGo);
            if (showLockedIcon)
            {
                btnGo.SetBackgroundImage(UIImage.FromBundle("ic_lock.png"), UIControlState.Normal);
                btnGo.Enabled = false;
                btnGo.WidthAnchor.ConstraintEqualTo(40).Active = true;
                btnGo.HeightAnchor.ConstraintEqualTo(46).Active = true;
            }
            else
            {
                btnGo.SetBackgroundImage(UIImage.FromBundle("ic_arrow_btn.png"), UIControlState.Normal);
                btnGo.WidthAnchor.ConstraintEqualTo(50).Active = true;
                btnGo.HeightAnchor.ConstraintEqualTo(50).Active = true;
                btnGo.TouchUpInside += BtnStart_TouchUpInside;
                btnGo.Tag = course.CourseNodeID;
            }
            btnGo.TrailingAnchor.ConstraintEqualTo(vwContainer.TrailingAnchor, -padding).Active = true;
            btnGo.TopAnchor.ConstraintEqualTo(vwContainer.TopAnchor, padding).Active = true;

            containerViews.Add(vwContainer);

            return vwContainer;
        }

        private void BtnStart_TouchUpInside(object sender, EventArgs e)
        {
            this.CourseIDToView = (int)((UIButton)sender).Tag;
            this.PerformSegue("CourseSegue", this);
        }

        public override void PrepareForSegue(UIStoryboardSegue segue, NSObject sender)
        {
            base.PrepareForSegue(segue, sender);

            var controller = segue.DestinationViewController as CourseController;
            controller.CourseID = this.CourseIDToView;
        }
    }
}