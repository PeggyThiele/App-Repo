using Foundation;
using System;
using System.Linq;
using UIKit;

namespace WELS.App.IOS
{
    public partial class CoursesEndController : UIViewController
    {
        public CoursesEndController(IntPtr handle) : base(handle)
        {

        }

        public override void ViewDidAppear(bool animated)
        {
            base.ViewDidAppear(animated);

            Localize();
            lblCourseInfo.Text = string.Format(AppDelegate.BundleToUse.GetLocalizedString("course_end_summary"), AppDelegate.Courses.Count(), AppDelegate.Courses.Sum(c => c.Lessons.Count()), AppDelegate.CurrentAccount.Name);

            btnNext.TouchUpInside += BtnNext_TouchUpInside;
            btnBack.TouchUpInside += BtnBack_TouchUpInside;
        }

        private void Localize()
        {
            lblCongrats.Text = AppDelegate.BundleToUse.GetLocalizedString("course_end_congrats");
            lblQuestion.Text = AppDelegate.BundleToUse.GetLocalizedString("course_end_question");
            lblProceed.Text = AppDelegate.BundleToUse.GetLocalizedString("course_end_proceed");
            btnNext.SetTitle(AppDelegate.BundleToUse.GetLocalizedString("course_end_sign_up"), UIControlState.Normal);
            btnBack.SetTitle(AppDelegate.BundleToUse.GetLocalizedString("course_end_no_thanks"), UIControlState.Normal);
        }
        private void BtnBack_TouchUpInside(object sender, EventArgs e)
        {
            AppDelegate.GoRightToCourseList = true;
            this.NavigationController.PopToRootViewController(false);
        }

        private void BtnNext_TouchUpInside(object sender, EventArgs e)
        {
            //UIApplication.SharedApplication.OpenUrl(new NSUrl(AppDelegate.BundleToUse.GetLocalizedString("course_end_sign_up_link")));
            PerformSegue("RegisterSegue", this);
        }
    }
}