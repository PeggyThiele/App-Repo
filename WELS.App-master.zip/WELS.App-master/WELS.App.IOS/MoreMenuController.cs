using Foundation;
using System;
using UIKit;

namespace WELS.App.IOS
{
    public partial class MoreMenuController : UIViewController
    {
        public MoreMenuController (IntPtr handle) : base (handle)
        {
        }

        public override void ViewDidLoad()
        {
            base.ViewDidLoad();

            Localize();

            btnContact.TouchUpInside += BtnContact_TouchUpInside;
            btnShare.TouchUpInside += BtnShare_TouchUpInside;
            btnInstagram.TouchUpInside += BtnInstagram_TouchUpInside;
            btnWebsite.TouchUpInside += BtnWebsite_TouchUpInside;
        }

        private void Localize()
        {
            lblContact.Text = AppDelegate.BundleToUse.GetLocalizedString("title_contact");
            lblWebsite.Text = AppDelegate.BundleToUse.GetLocalizedString("title_website");
            lblInstagram.Text = AppDelegate.BundleToUse.GetLocalizedString("title_instagram");
            lblShare.Text = AppDelegate.BundleToUse.GetLocalizedString("title_share");
        }

        private void BtnInstagram_TouchUpInside(object sender, EventArgs e)
        {
            UIApplication.SharedApplication.OpenUrl(new NSUrl(AppDelegate.BundleToUse.GetLocalizedString("nav_instagram_link")));
        }

        private void BtnWebsite_TouchUpInside(object sender, EventArgs e)
        {
            UIApplication.SharedApplication.OpenUrl(new NSUrl(AppDelegate.BundleToUse.GetLocalizedString("nav_website_link")));
        }

        private void BtnShare_TouchUpInside(object sender, EventArgs e)
        {
            UIPasteboard.General.String = AppDelegate.BundleToUse.GetLocalizedString("nav_share_link");
            var alert = UIAlertController.Create("", AppDelegate.BundleToUse.GetLocalizedString("nav_link_copied"), UIAlertControllerStyle.Alert);
            alert.AddAction(UIAlertAction.Create("OK", UIAlertActionStyle.Default, null));
            PresentViewController(alert, true, null);
        }

        private void BtnContact_TouchUpInside(object sender, EventArgs e)
        {
            UIApplication.SharedApplication.OpenUrl(new NSUrl(AppDelegate.BundleToUse.GetLocalizedString("nav_contact_link")));
        }
    }
}