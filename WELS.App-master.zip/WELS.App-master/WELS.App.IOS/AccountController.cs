using CoreGraphics;
using Facebook.CoreKit;
using Facebook.LoginKit;
using Foundation;
using System;
using UIKit;
using WELS.App.IOS.Helpers;

namespace WELS.App.IOS
{
    public partial class AccountController : UIViewController
    {
        public AccountController (IntPtr handle) : base (handle)
        {
        }

        public override void ViewDidLoad()
        {
            base.ViewDidLoad();

            Localize();

            vwContainer.Layer.BorderColor = UIColor.FromRGB(177, 188, 190).CGColor;
            vwContainer.Layer.BorderWidth = 1;

            imgProfileImage.Image = UIViewHelper.FromUrl(AppDelegate.CurrentAccount.FacebookProfileImageURL);
            lblName.Text = AppDelegate.CurrentAccount.Name;
            lblJoinDate.Text = AppDelegate.CurrentAccount.DateCreated.ToLongDateString();
            lblWhatsApp.Text = string.IsNullOrEmpty(AppDelegate.CurrentAccount.WhatsAppNumber) ? "(Not set)" : AppDelegate.CurrentAccount.WhatsAppNumber;
            txtWhatsApp.Text = AppDelegate.CurrentAccount.WhatsAppNumber;
            chkAllowPush.On = AppDelegate.CurrentAccount.EnablePushNotifications;
            chkAllowText.On = AppDelegate.CurrentAccount.EnableTextNotifications;

            txtWhatsApp.Hidden = true;
            btnSave.Hidden = true;

            btnEditWhatsApp.TouchUpInside += BtnEditWhatsApp_TouchUpInside;
            btnSave.TouchUpInside += BtnSave_TouchUpInside;
            chkAllowPush.ValueChanged += ChkAllowPush_ValueChanged;
            chkAllowText.ValueChanged += ChkAllowText_ValueChanged;

            btnLogOut.TouchUpInside += BtnLogOut_TouchUpInside;
        }
        public override void ViewDidLayoutSubviews()
        {
            base.ViewDidLayoutSubviews();
        }

        private void BtnLogOut_TouchUpInside(object sender, EventArgs e)
        {
            AppDelegate.Logout();
            this.TabBarController.SelectedIndex = 0;
            this.TabBarController.TabBar.Hidden = true;
            ((UINavigationController)this.TabBarController.SelectedViewController).PopToRootViewController(false);
        }

        private void Localize()
        {
            lblHeader.Text = AppDelegate.BundleToUse.GetLocalizedString("account_header");
            lblNameLabel.Text = AppDelegate.BundleToUse.GetLocalizedString("account_name_label");
            lblJoinDateLabel.Text = AppDelegate.BundleToUse.GetLocalizedString("account_joined_label");
            lblWhatsAppLabel.Text = AppDelegate.BundleToUse.GetLocalizedString("account_number_label");
            lblPreferences.Text = AppDelegate.BundleToUse.GetLocalizedString("account_prefs_label");
            lblPushLabel.Text = AppDelegate.BundleToUse.GetLocalizedString("account_push_label");
            lblPushDescription.Text = AppDelegate.BundleToUse.GetLocalizedString("account_push_description");
            lblTextLabel.Text = AppDelegate.BundleToUse.GetLocalizedString("account_text_label");
            lblTextDescription.Text = AppDelegate.BundleToUse.GetLocalizedString("account_text_description");
            btnLogOut.SetTitle(AppDelegate.BundleToUse.GetLocalizedString("account_log_out"), UIControlState.Normal);
        }

        private async void ChkAllowText_ValueChanged(object sender, EventArgs e)
        {
            AppDelegate.CurrentAccount.EnableTextNotifications = chkAllowText.On;
            await AppDelegate.DataHelper.SaveAccount(AppDelegate.CurrentAccount);
        }

        private async void ChkAllowPush_ValueChanged(object sender, EventArgs e)
        {
            AppDelegate.CurrentAccount.EnablePushNotifications = chkAllowPush.On;
            await AppDelegate.DataHelper.SaveAccount(AppDelegate.CurrentAccount);

            AppDelegate.RefreshPushNotificationTags();
        }

        private async void BtnSave_TouchUpInside(object sender, EventArgs e)
        {
            AppDelegate.CurrentAccount.WhatsAppNumber = txtWhatsApp.Text;
            await AppDelegate.DataHelper.SaveAccount(AppDelegate.CurrentAccount);

            lblWhatsApp.Hidden = false;
            lblWhatsApp.Text = txtWhatsApp.Text;
            txtWhatsApp.Hidden = true;
            btnSave.Hidden = true;
        }

        private void BtnEditWhatsApp_TouchUpInside(object sender, EventArgs e)
        {
            lblWhatsApp.Hidden = true;
            txtWhatsApp.Hidden = false;
            btnSave.Hidden = false;
        }
    }
}