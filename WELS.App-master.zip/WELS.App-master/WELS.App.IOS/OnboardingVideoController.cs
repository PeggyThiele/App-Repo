using CoreAnimation;
using CoreGraphics;
using Foundation;
using System;
using System.Linq;
using UIKit;

namespace WELS.App.IOS
{
    public partial class OnboardingVideoController : UIViewController
    {
        public OnboardingVideoController (IntPtr handle) : base (handle)
        {
        }

        public async override void ViewDidLoad()
        {
            base.ViewDidLoad();

            Localize();

            // Since we're skipping the onboarding questions, set score to 99 so it can easily be queried
            AppDelegate.CurrentAccount.OnBoardingTotalScore = 99;
            await AppDelegate.DataHelper.SaveAccount(AppDelegate.CurrentAccount);

            var onboarding = await AppDelegate.DataHelper.GetOnboarding(AppDelegate.CurrentAccount.LanguageNodeID ?? 0);
            var sortedVideos = onboarding.Videos.Where(v => AppDelegate.CurrentAccount.OnBoardingTotalScore >= v.MinimumScore).OrderBy(v => v.MinimumScore);
            var video = sortedVideos.FirstOrDefault();

            if (video != null)
            {
                //var url = "https://www.youtube.com/embed/C0DPdy98e4c";
                var url = video.VideoURL;

                wvVideo.LoadRequest(new NSUrlRequest(new NSUrl(url)));
            }

            btnNext.TouchUpInside += BtnNext_TouchUpInside;

            vwProgress.Transform = CGAffineTransform.MakeScale(1, 3);
        }
        public override void ViewDidLayoutSubviews()
        {
            base.ViewDidLayoutSubviews();

            // Drop-shadow
            UIBezierPath shadowPath = UIBezierPath.FromRect(vwContainer.Bounds);
            vwContainer.Layer.MasksToBounds = false;
            vwContainer.Layer.ShadowColor = UIColor.FromRGB(11, 48, 77).CGColor;
            vwContainer.Layer.ShadowOffset = new CGSize(0.0f, 2.0f);
            vwContainer.Layer.ShadowOpacity = 0.5f;
            vwContainer.Layer.ShadowPath = shadowPath.CGPath;

            // White gradient
            var rect = new CGRect(0, 0, this.View.Frame.Width, 150);
            var view = new UIView(rect);
            var gradientLayer = new CAGradientLayer();
            gradientLayer.Frame = rect;
            gradientLayer.Colors = new CGColor[] { UIColor.White.CGColor, UIColor.Clear.CGColor };
            gradientLayer.StartPoint = new CGPoint(0, 0);
            gradientLayer.EndPoint = new CGPoint(0, 1);
            view.BackgroundColor = UIColor.White;
            view.Layer.Mask = gradientLayer;

            this.View.AddSubview(view);

            this.View.SendSubviewToBack(imgBackground);
            this.View.SendSubviewToBack(view);
        }

        private void Localize()
        {
#if ACADEMIACRISTO
            imgLogo.Image = UIImage.FromBundle("academia_cristo_w_tagline.png");
#endif
            btnNext.SetTitle(AppDelegate.BundleToUse.GetLocalizedString("button_next"), UIControlState.Normal);
            lblThanks.Text = AppDelegate.BundleToUse.GetLocalizedString("onboarding_finish_title");
            lblShare.Text = AppDelegate.BundleToUse.GetLocalizedString("onboarding_finish_intro");
            lblWatch.Text = AppDelegate.BundleToUse.GetLocalizedString("onboarding_watch");
        }

        private async void BtnNext_TouchUpInside(object sender, EventArgs e)
        {
            AppDelegate.CurrentAccount.DateCompletedOnboarding = DateTime.UtcNow;
            await AppDelegate.DataHelper.SaveAccount(AppDelegate.CurrentAccount);
            this.NavigationController.PopToRootViewController(false);
        }
    }
}