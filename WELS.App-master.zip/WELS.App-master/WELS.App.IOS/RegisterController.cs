using Foundation;
using System;
using System.Collections.Generic;
using System.Net.Http;
using UIKit;

namespace WELS.App.IOS
{
    public partial class RegisterController : UIViewController
    {
        public RegisterController (IntPtr handle) : base (handle)
        {
        }

        public override void ViewDidLoad()
        {
            base.ViewDidLoad();

            // Settings
            var margin = 16;
            var fieldSpacing = 8;

            // Create the content view
            var vwContent = new UIView() { TranslatesAutoresizingMaskIntoConstraints = false };
            //vwContent.Layer.BackgroundColor = UIColor.Red.CGColor;
            vwScrollView.Add(vwContent);
            vwContent.WidthAnchor.ConstraintEqualTo(vwScrollView.WidthAnchor).Active = true;
            //vwContent.HeightAnchor.ConstraintEqualTo(2000).Active = true;
            vwContent.TopAnchor.ConstraintEqualTo(vwScrollView.TopAnchor, 0).Active = true;
            vwContent.BottomAnchor.ConstraintEqualTo(vwScrollView.BottomAnchor, 0).Active = true;
            vwContent.LeadingAnchor.ConstraintEqualTo(vwScrollView.LeadingAnchor, 0).Active = true;
            vwContent.TrailingAnchor.ConstraintEqualTo(vwScrollView.TrailingAnchor, 0).Active = true;

            var lbl1 = new UILabel() { TranslatesAutoresizingMaskIntoConstraints = false };
            lbl1.Text = "Register";
            lbl1.Font = UIFont.SystemFontOfSize(20, UIFontWeight.Bold);
            lbl1.TextAlignment = UITextAlignment.Center;
            vwContent.Add(lbl1);
            lbl1.TopAnchor.ConstraintEqualTo(vwContent.TopAnchor, margin).Active = true;
            lbl1.LeadingAnchor.ConstraintEqualTo(vwContent.LeadingAnchor, margin).Active = true;
            lbl1.TrailingAnchor.ConstraintEqualTo(vwContent.TrailingAnchor, -margin).Active = true;

            var lbl2 = new UILabel() { TranslatesAutoresizingMaskIntoConstraints = false };
            lbl2.Text = $"You and other students will study God's Word together in a live video classroom led by a TELL Pastor.  We look forward to meeting you, {AppDelegate.CurrentAccount.Name}";
            lbl2.Lines = 0;
            lbl2.TextAlignment = UITextAlignment.Center;
            lbl2.LineBreakMode = UILineBreakMode.WordWrap;
            vwContent.Add(lbl2);
            lbl2.TopAnchor.ConstraintEqualTo(lbl1.BottomAnchor, margin).Active = true;
            lbl2.LeadingAnchor.ConstraintEqualTo(vwContent.LeadingAnchor, margin).Active = true;
            lbl2.TrailingAnchor.ConstraintEqualTo(vwContent.TrailingAnchor, -margin).Active = true;

            var imgBlueCircle = new UIImageView() { TranslatesAutoresizingMaskIntoConstraints = false };
            imgBlueCircle.Image = UIImage.FromBundle("blue_round_top.png");
            vwContent.Add(imgBlueCircle);
            imgBlueCircle.HeightAnchor.ConstraintEqualTo(35).Active = true;
            imgBlueCircle.TopAnchor.ConstraintEqualTo(lbl2.BottomAnchor, margin).Active = true;
            imgBlueCircle.LeadingAnchor.ConstraintEqualTo(vwContent.LeadingAnchor, 0).Active = true;
            imgBlueCircle.TrailingAnchor.ConstraintEqualTo(vwContent.TrailingAnchor, 0).Active = true;

            var vwBlueBG = new UIView() { TranslatesAutoresizingMaskIntoConstraints = false };
            vwBlueBG.BackgroundColor = UIColor.FromRGB(28, 117, 188);
            vwContent.Add(vwBlueBG);
            vwBlueBG.TopAnchor.ConstraintEqualTo(imgBlueCircle.BottomAnchor, 0).Active = true;
            vwBlueBG.LeadingAnchor.ConstraintEqualTo(vwContent.LeadingAnchor, 0).Active = true;
            vwBlueBG.TrailingAnchor.ConstraintEqualTo(vwContent.TrailingAnchor, 0).Active = true;
            vwBlueBG.BottomAnchor.ConstraintEqualTo(vwContent.BottomAnchor, 0).Active = true;
            //vwBlueBG.HeightAnchor.ConstraintEqualTo(1000).Active = true;

            var imgLogo = new UIImageView() { TranslatesAutoresizingMaskIntoConstraints = false };
            imgLogo.Image = UIImage.FromBundle("bird_green.png");
            vwContent.Add(imgLogo);
            imgLogo.HeightAnchor.ConstraintEqualTo(32).Active = true;
            imgLogo.TopAnchor.ConstraintEqualTo(vwContent.TopAnchor, margin).Active = true;
            imgLogo.WidthAnchor.ConstraintEqualTo(44).Active = true;
            imgLogo.TrailingAnchor.ConstraintEqualTo(vwContent.TrailingAnchor, 0).Active = true;


            // Now set up the form within the blue background view

            // ***** VALIDATION LABEL *****
            var lblValidation = new UILabel() { TranslatesAutoresizingMaskIntoConstraints = false };
            lblValidation.Lines = 0;
            lblValidation.TextColor = UIColor.Red;
            lblValidation.Hidden = true;
            vwBlueBG.Add(lblValidation);
            lblValidation.TopAnchor.ConstraintEqualTo(vwBlueBG.TopAnchor, margin).Active = true;
            lblValidation.LeadingAnchor.ConstraintEqualTo(vwBlueBG.LeadingAnchor, margin).Active = true;
            lblValidation.TrailingAnchor.ConstraintEqualTo(vwBlueBG.TrailingAnchor, -margin).Active = true;

            // ***** FIRST NAME *****
            var lblAsterisk1 = new UILabel() { TranslatesAutoresizingMaskIntoConstraints = false };
            lblAsterisk1.Text = "*";
            lblAsterisk1.TextColor = UIColor.FromRGB(181, 59, 27);
            lblAsterisk1.TextAlignment = UITextAlignment.Left;
            lblAsterisk1.Font = UIFont.SystemFontOfSize(10);
            vwBlueBG.Add(lblAsterisk1);
            lblAsterisk1.TopAnchor.ConstraintEqualTo(lblValidation.BottomAnchor, margin).Active = true;
            lblAsterisk1.LeadingAnchor.ConstraintEqualTo(vwBlueBG.LeadingAnchor, margin).Active = true;
            lblAsterisk1.WidthAnchor.ConstraintEqualTo(10).Active = true;

            var lblFullName = new UILabel() { TranslatesAutoresizingMaskIntoConstraints = false };
            lblFullName.Text = AppDelegate.BundleToUse.GetLocalizedString("register_fullname");
            lblFullName.TextColor = UIColor.White;
            lblFullName.TextAlignment = UITextAlignment.Left;
            lblFullName.Font = UIFont.SystemFontOfSize(10);
            vwBlueBG.Add(lblFullName);
            lblFullName.TopAnchor.ConstraintEqualTo(lblValidation.BottomAnchor, margin).Active = true;
            lblFullName.LeadingAnchor.ConstraintEqualTo(lblAsterisk1.TrailingAnchor, 2).Active = true;
            lblFullName.TrailingAnchor.ConstraintEqualTo(vwBlueBG.TrailingAnchor, -margin).Active = true;

            var txtFullName = new UITextView() { TranslatesAutoresizingMaskIntoConstraints = false };
            txtFullName.Layer.CornerRadius = 7;
            txtFullName.Layer.BorderColor = UIColor.Black.CGColor;
            txtFullName.Layer.BorderWidth = 1;
            vwBlueBG.Add(txtFullName);
            txtFullName.TopAnchor.ConstraintEqualTo(lblFullName.BottomAnchor).Active = true;
            txtFullName.LeadingAnchor.ConstraintEqualTo(vwBlueBG.LeadingAnchor, margin).Active = true;
            txtFullName.TrailingAnchor.ConstraintEqualTo(vwBlueBG.TrailingAnchor, -margin).Active = true;
            txtFullName.HeightAnchor.ConstraintEqualTo(30).Active = true;


            // ***** CITY *****
            var lblAsterisk2 = new UILabel() { TranslatesAutoresizingMaskIntoConstraints = false };
            lblAsterisk2.Text = "*";
            lblAsterisk2.TextColor = UIColor.FromRGB(181, 59, 27);
            lblAsterisk2.TextAlignment = UITextAlignment.Left;
            lblAsterisk2.Font = UIFont.SystemFontOfSize(10);
            vwBlueBG.Add(lblAsterisk2);
            lblAsterisk2.TopAnchor.ConstraintEqualTo(txtFullName.BottomAnchor, fieldSpacing).Active = true;
            lblAsterisk2.LeadingAnchor.ConstraintEqualTo(vwBlueBG.LeadingAnchor, margin).Active = true;
            lblAsterisk2.WidthAnchor.ConstraintEqualTo(10).Active = true;

            var lblCity = new UILabel() { TranslatesAutoresizingMaskIntoConstraints = false };
            lblCity.Text = AppDelegate.BundleToUse.GetLocalizedString("register_city");
            lblCity.TextColor = UIColor.White;
            lblCity.TextAlignment = UITextAlignment.Left;
            lblCity.Font = UIFont.SystemFontOfSize(10);
            vwBlueBG.Add(lblCity);
            lblCity.TopAnchor.ConstraintEqualTo(txtFullName.BottomAnchor, fieldSpacing).Active = true;
            lblCity.LeadingAnchor.ConstraintEqualTo(lblAsterisk2.TrailingAnchor, 2).Active = true;
            lblCity.TrailingAnchor.ConstraintEqualTo(vwBlueBG.CenterXAnchor, -margin / 2).Active = true;

            var txtCity = new UITextView() { TranslatesAutoresizingMaskIntoConstraints = false };
            txtCity.Layer.CornerRadius = 7;
            txtCity.Layer.BorderColor = UIColor.Black.CGColor;
            txtCity.Layer.BorderWidth = 1;
            vwBlueBG.Add(txtCity);
            txtCity.TopAnchor.ConstraintEqualTo(lblCity.BottomAnchor).Active = true;
            txtCity.LeadingAnchor.ConstraintEqualTo(vwBlueBG.LeadingAnchor, margin).Active = true;
            txtCity.TrailingAnchor.ConstraintEqualTo(vwBlueBG.CenterXAnchor, -margin / 2).Active = true;
            txtCity.HeightAnchor.ConstraintEqualTo(30).Active = true;


            // ***** COUNTRY *****
            var lblAsterisk3 = new UILabel() { TranslatesAutoresizingMaskIntoConstraints = false };
            lblAsterisk3.Text = "*";
            lblAsterisk3.TextColor = UIColor.FromRGB(181, 59, 27);
            lblAsterisk3.TextAlignment = UITextAlignment.Left;
            lblAsterisk3.Font = UIFont.SystemFontOfSize(10);
            vwBlueBG.Add(lblAsterisk3);
            lblAsterisk3.TopAnchor.ConstraintEqualTo(txtFullName.BottomAnchor, fieldSpacing).Active = true;
            lblAsterisk3.LeadingAnchor.ConstraintEqualTo(vwBlueBG.CenterXAnchor, margin / 2).Active = true;
            lblAsterisk3.WidthAnchor.ConstraintEqualTo(10).Active = true;

            var lblCountry = new UILabel() { TranslatesAutoresizingMaskIntoConstraints = false };
            lblCountry.Text = AppDelegate.BundleToUse.GetLocalizedString("register_country");
            lblCountry.TextColor = UIColor.White;
            lblCountry.TextAlignment = UITextAlignment.Left;
            lblCountry.Font = UIFont.SystemFontOfSize(10);
            vwBlueBG.Add(lblCountry);
            lblCountry.TopAnchor.ConstraintEqualTo(txtFullName.BottomAnchor, fieldSpacing).Active = true;
            lblCountry.LeadingAnchor.ConstraintEqualTo(lblAsterisk3.TrailingAnchor, 2).Active = true;
            lblCountry.TrailingAnchor.ConstraintEqualTo(vwBlueBG.TrailingAnchor, -margin).Active = true;

            var txtCountry = new UITextView() { TranslatesAutoresizingMaskIntoConstraints = false };
            txtCountry.Layer.CornerRadius = 7;
            txtCountry.Layer.BorderColor = UIColor.Black.CGColor;
            txtCountry.Layer.BorderWidth = 1;
            vwBlueBG.Add(txtCountry);
            txtCountry.TopAnchor.ConstraintEqualTo(lblCountry.BottomAnchor).Active = true;
            txtCountry.LeadingAnchor.ConstraintEqualTo(vwBlueBG.CenterXAnchor, margin / 2).Active = true;
            txtCountry.TrailingAnchor.ConstraintEqualTo(vwBlueBG.TrailingAnchor, -margin).Active = true;
            txtCountry.HeightAnchor.ConstraintEqualTo(30).Active = true;

            // ***** FACEBOOK USERNAME *****
            var lblAsterisk4 = new UILabel() { TranslatesAutoresizingMaskIntoConstraints = false };
            lblAsterisk4.Text = "*";
            lblAsterisk4.TextColor = UIColor.FromRGB(181, 59, 27);
            lblAsterisk4.TextAlignment = UITextAlignment.Left;
            lblAsterisk4.Font = UIFont.SystemFontOfSize(10);
            vwBlueBG.Add(lblAsterisk4);
            lblAsterisk4.TopAnchor.ConstraintEqualTo(txtCountry.BottomAnchor, fieldSpacing).Active = true;
            lblAsterisk4.LeadingAnchor.ConstraintEqualTo(vwBlueBG.LeadingAnchor, margin).Active = true;
            lblAsterisk4.WidthAnchor.ConstraintEqualTo(10).Active = true;

            var lblFacebookUsername = new UILabel() { TranslatesAutoresizingMaskIntoConstraints = false };
            lblFacebookUsername.Text = AppDelegate.BundleToUse.GetLocalizedString("register_facebook_username");
            lblFacebookUsername.Lines = 2;
            lblFacebookUsername.TextColor = UIColor.White;
            lblFacebookUsername.TextAlignment = UITextAlignment.Left;
            lblFacebookUsername.Font = UIFont.SystemFontOfSize(10);
            vwBlueBG.Add(lblFacebookUsername);
            lblFacebookUsername.TopAnchor.ConstraintEqualTo(txtCountry.BottomAnchor, fieldSpacing).Active = true;
            lblFacebookUsername.LeadingAnchor.ConstraintEqualTo(lblAsterisk4.TrailingAnchor, 2).Active = true;
            lblFacebookUsername.TrailingAnchor.ConstraintEqualTo(vwBlueBG.CenterXAnchor, -margin / 2).Active = true;

            var txtFacebookUsername = new UITextView() { TranslatesAutoresizingMaskIntoConstraints = false };
            txtFacebookUsername.Layer.CornerRadius = 7;
            txtFacebookUsername.Layer.BorderColor = UIColor.Black.CGColor;
            txtFacebookUsername.Layer.BorderWidth = 1;
            vwBlueBG.Add(txtFacebookUsername);
            txtFacebookUsername.TopAnchor.ConstraintEqualTo(lblFacebookUsername.BottomAnchor).Active = true;
            txtFacebookUsername.LeadingAnchor.ConstraintEqualTo(vwBlueBG.LeadingAnchor, margin).Active = true;
            txtFacebookUsername.TrailingAnchor.ConstraintEqualTo(vwBlueBG.CenterXAnchor, -margin / 2).Active = true;
            txtFacebookUsername.HeightAnchor.ConstraintEqualTo(30).Active = true;

            // ***** WHATSAPP NUMBER *****
            // Create this backwards in order to align the textboxes
            var txtWhatsAppNumber = new UITextView() { TranslatesAutoresizingMaskIntoConstraints = false };
            txtWhatsAppNumber.Layer.CornerRadius = 7;
            txtWhatsAppNumber.Layer.BorderColor = UIColor.Black.CGColor;
            txtWhatsAppNumber.Layer.BorderWidth = 1;
            vwBlueBG.Add(txtWhatsAppNumber);
            txtWhatsAppNumber.BottomAnchor.ConstraintEqualTo(txtFacebookUsername.BottomAnchor).Active = true;
            txtWhatsAppNumber.LeadingAnchor.ConstraintEqualTo(vwBlueBG.CenterXAnchor, margin / 2).Active = true;
            txtWhatsAppNumber.TrailingAnchor.ConstraintEqualTo(vwBlueBG.TrailingAnchor, -margin).Active = true;
            txtWhatsAppNumber.HeightAnchor.ConstraintEqualTo(30).Active = true;

            var lblWhatsAppNumber = new UILabel() { TranslatesAutoresizingMaskIntoConstraints = false };
            lblWhatsAppNumber.Text = AppDelegate.BundleToUse.GetLocalizedString("register_whatsapp_number");
            lblWhatsAppNumber.TextColor = UIColor.White;
            lblWhatsAppNumber.TextAlignment = UITextAlignment.Left;
            lblWhatsAppNumber.Font = UIFont.SystemFontOfSize(10);
            vwBlueBG.Add(lblWhatsAppNumber);
            lblWhatsAppNumber.LeadingAnchor.ConstraintEqualTo(vwBlueBG.CenterXAnchor, margin / 2).Active = true;
            lblWhatsAppNumber.TrailingAnchor.ConstraintEqualTo(vwBlueBG.TrailingAnchor, -margin).Active = true;
            lblWhatsAppNumber.BottomAnchor.ConstraintEqualTo(txtWhatsAppNumber.TopAnchor).Active = true;

            // ***** QUESTION 1 *****
            var lblAsterisk5 = new UILabel() { TranslatesAutoresizingMaskIntoConstraints = false };
            lblAsterisk5.Text = "*";
            lblAsterisk5.TextColor = UIColor.FromRGB(181, 59, 27);
            lblAsterisk5.TextAlignment = UITextAlignment.Left;
            lblAsterisk5.Font = UIFont.SystemFontOfSize(10);
            vwBlueBG.Add(lblAsterisk5);
            lblAsterisk5.TopAnchor.ConstraintEqualTo(txtFacebookUsername.BottomAnchor, fieldSpacing).Active = true;
            lblAsterisk5.LeadingAnchor.ConstraintEqualTo(vwBlueBG.LeadingAnchor, margin).Active = true;
            lblAsterisk5.WidthAnchor.ConstraintEqualTo(10).Active = true;

            var lblQuestion1 = new UILabel() { TranslatesAutoresizingMaskIntoConstraints = false };
            lblQuestion1.Lines = 0;
            lblQuestion1.Text = AppDelegate.BundleToUse.GetLocalizedString("register_finished_beginner_courses");
            lblQuestion1.TextColor = UIColor.White;
            lblQuestion1.TextAlignment = UITextAlignment.Left;
            lblQuestion1.Font = UIFont.SystemFontOfSize(10);
            vwBlueBG.Add(lblQuestion1);
            lblQuestion1.TopAnchor.ConstraintEqualTo(txtFacebookUsername.BottomAnchor, fieldSpacing).Active = true;
            lblQuestion1.LeadingAnchor.ConstraintEqualTo(lblAsterisk5.TrailingAnchor, 2).Active = true;
            lblQuestion1.TrailingAnchor.ConstraintEqualTo(vwBlueBG.TrailingAnchor, -margin).Active = true;

            var txtQuestion1 = new UITextView() { TranslatesAutoresizingMaskIntoConstraints = false };
            txtQuestion1.Layer.CornerRadius = 7;
            txtQuestion1.Layer.BorderColor = UIColor.Black.CGColor;
            txtQuestion1.Layer.BorderWidth = 1;
            vwBlueBG.Add(txtQuestion1);
            txtQuestion1.TopAnchor.ConstraintEqualTo(lblQuestion1.BottomAnchor).Active = true;
            txtQuestion1.LeadingAnchor.ConstraintEqualTo(vwBlueBG.LeadingAnchor, margin).Active = true;
            txtQuestion1.TrailingAnchor.ConstraintEqualTo(vwBlueBG.TrailingAnchor, -margin).Active = true;
            txtQuestion1.HeightAnchor.ConstraintEqualTo(30).Active = true;

            // ***** QUESTION 2 *****
            var lblAsterisk6 = new UILabel() { TranslatesAutoresizingMaskIntoConstraints = false };
            lblAsterisk6.Text = "*";
            lblAsterisk6.TextColor = UIColor.FromRGB(181, 59, 27);
            lblAsterisk6.TextAlignment = UITextAlignment.Left;
            lblAsterisk6.Font = UIFont.SystemFontOfSize(10);
            vwBlueBG.Add(lblAsterisk6);
            lblAsterisk6.TopAnchor.ConstraintEqualTo(txtQuestion1.BottomAnchor, fieldSpacing).Active = true;
            lblAsterisk6.LeadingAnchor.ConstraintEqualTo(vwBlueBG.LeadingAnchor, margin).Active = true;
            lblAsterisk6.WidthAnchor.ConstraintEqualTo(10).Active = true;

            var lblQuestion2 = new UILabel() { TranslatesAutoresizingMaskIntoConstraints = false };
            lblQuestion2.Lines = 0;
            lblQuestion2.Text = AppDelegate.BundleToUse.GetLocalizedString("register_local_church");
            lblQuestion2.TextColor = UIColor.White;
            lblQuestion2.TextAlignment = UITextAlignment.Left;
            lblQuestion2.Font = UIFont.SystemFontOfSize(10);
            vwBlueBG.Add(lblQuestion2);
            lblQuestion2.TopAnchor.ConstraintEqualTo(txtQuestion1.BottomAnchor, fieldSpacing).Active = true;
            lblQuestion2.LeadingAnchor.ConstraintEqualTo(lblAsterisk6.TrailingAnchor, 2).Active = true;
            lblQuestion2.TrailingAnchor.ConstraintEqualTo(vwBlueBG.TrailingAnchor, -margin).Active = true;

            var txtQuestion2 = new UITextView() { TranslatesAutoresizingMaskIntoConstraints = false };
            txtQuestion2.Layer.CornerRadius = 7;
            txtQuestion2.Layer.BorderColor = UIColor.Black.CGColor;
            txtQuestion2.Layer.BorderWidth = 1;
            vwBlueBG.Add(txtQuestion2);
            txtQuestion2.TopAnchor.ConstraintEqualTo(lblQuestion2.BottomAnchor).Active = true;
            txtQuestion2.LeadingAnchor.ConstraintEqualTo(vwBlueBG.LeadingAnchor, margin).Active = true;
            txtQuestion2.TrailingAnchor.ConstraintEqualTo(vwBlueBG.TrailingAnchor, -margin).Active = true;
            txtQuestion2.HeightAnchor.ConstraintEqualTo(30).Active = true;

            // ***** QUESTION 3 *****
            var lblAsterisk7 = new UILabel() { TranslatesAutoresizingMaskIntoConstraints = false };
            lblAsterisk7.Text = "*";
            lblAsterisk7.TextColor = UIColor.FromRGB(181, 59, 27);
            lblAsterisk7.TextAlignment = UITextAlignment.Left;
            lblAsterisk7.Font = UIFont.SystemFontOfSize(10);
            vwBlueBG.Add(lblAsterisk7);
            lblAsterisk7.TopAnchor.ConstraintEqualTo(txtQuestion2.BottomAnchor, fieldSpacing).Active = true;
            lblAsterisk7.LeadingAnchor.ConstraintEqualTo(vwBlueBG.LeadingAnchor, margin).Active = true;
            lblAsterisk7.WidthAnchor.ConstraintEqualTo(10).Active = true;

            var lblQuestion3 = new UILabel() { TranslatesAutoresizingMaskIntoConstraints = false };
            lblQuestion3.Lines = 0;
            lblQuestion3.Text = AppDelegate.BundleToUse.GetLocalizedString("register_tell_training");
            lblQuestion3.TextColor = UIColor.White;
            lblQuestion3.TextAlignment = UITextAlignment.Left;
            lblQuestion3.Font = UIFont.SystemFontOfSize(10);
            vwBlueBG.Add(lblQuestion3);
            lblQuestion3.TopAnchor.ConstraintEqualTo(txtQuestion2.BottomAnchor, fieldSpacing).Active = true;
            lblQuestion3.LeadingAnchor.ConstraintEqualTo(lblAsterisk7.TrailingAnchor, 2).Active = true;
            lblQuestion3.TrailingAnchor.ConstraintEqualTo(vwBlueBG.TrailingAnchor, -margin).Active = true;

            var txtQuestion3 = new UITextView() { TranslatesAutoresizingMaskIntoConstraints = false };
            txtQuestion3.Layer.CornerRadius = 7;
            txtQuestion3.Layer.BorderColor = UIColor.Black.CGColor;
            txtQuestion3.Layer.BorderWidth = 1;
            vwBlueBG.Add(txtQuestion3);
            txtQuestion3.TopAnchor.ConstraintEqualTo(lblQuestion3.BottomAnchor).Active = true;
            txtQuestion3.LeadingAnchor.ConstraintEqualTo(vwBlueBG.LeadingAnchor, margin).Active = true;
            txtQuestion3.TrailingAnchor.ConstraintEqualTo(vwBlueBG.TrailingAnchor, -margin).Active = true;
            txtQuestion3.HeightAnchor.ConstraintEqualTo(30).Active = true;

            // ***** COMMENTS *****
            var lblAsterisk8 = new UILabel() { TranslatesAutoresizingMaskIntoConstraints = false };
            lblAsterisk8.Text = "*";
            lblAsterisk8.TextColor = UIColor.FromRGB(181, 59, 27);
            lblAsterisk8.TextAlignment = UITextAlignment.Left;
            lblAsterisk8.Font = UIFont.SystemFontOfSize(10);
            vwBlueBG.Add(lblAsterisk8);
            lblAsterisk8.TopAnchor.ConstraintEqualTo(txtQuestion3.BottomAnchor, fieldSpacing).Active = true;
            lblAsterisk8.LeadingAnchor.ConstraintEqualTo(vwBlueBG.LeadingAnchor, margin).Active = true;
            lblAsterisk8.WidthAnchor.ConstraintEqualTo(10).Active = true;

            var lblComments = new UILabel() { TranslatesAutoresizingMaskIntoConstraints = false };
            lblComments.Lines = 0;
            lblComments.Text = AppDelegate.BundleToUse.GetLocalizedString("register_comments");
            lblComments.TextColor = UIColor.White;
            lblComments.TextAlignment = UITextAlignment.Left;
            lblComments.Font = UIFont.SystemFontOfSize(10);
            vwBlueBG.Add(lblComments);
            lblComments.TopAnchor.ConstraintEqualTo(txtQuestion3.BottomAnchor, fieldSpacing).Active = true;
            lblComments.LeadingAnchor.ConstraintEqualTo(lblAsterisk8.TrailingAnchor, 2).Active = true;
            lblComments.TrailingAnchor.ConstraintEqualTo(vwBlueBG.TrailingAnchor, -margin).Active = true;

            var txtComments = new UITextView() { TranslatesAutoresizingMaskIntoConstraints = false };
            txtComments.Layer.CornerRadius = 7;
            txtComments.Layer.BorderColor = UIColor.Black.CGColor;
            txtComments.Layer.BorderWidth = 1;
            vwBlueBG.Add(txtComments);
            txtComments.TopAnchor.ConstraintEqualTo(lblComments.BottomAnchor).Active = true;
            txtComments.LeadingAnchor.ConstraintEqualTo(vwBlueBG.LeadingAnchor, margin).Active = true;
            txtComments.TrailingAnchor.ConstraintEqualTo(vwBlueBG.TrailingAnchor, -margin).Active = true;
            txtComments.HeightAnchor.ConstraintEqualTo(150).Active = true;


            //***** SUBMIT *****
            var btnSubmit = new UIButton() { TranslatesAutoresizingMaskIntoConstraints = false };
            btnSubmit.SetTitle(AppDelegate.BundleToUse.GetLocalizedString("register_button_text"), UIControlState.Normal);
            btnSubmit.SetTitleColor(UIColor.FromRGB(28, 117, 188), UIControlState.Normal);
            btnSubmit.BackgroundColor = UIColor.White;
            btnSubmit.Layer.CornerRadius = 4;
            vwBlueBG.Add(btnSubmit);
            btnSubmit.TopAnchor.ConstraintEqualTo(txtComments.BottomAnchor, margin).Active = true;
            btnSubmit.WidthAnchor.ConstraintEqualTo(100).Active = true;
            btnSubmit.CenterXAnchor.ConstraintEqualTo(vwBlueBG.CenterXAnchor).Active = true;
            btnSubmit.BottomAnchor.ConstraintEqualTo(vwBlueBG.BottomAnchor, -margin).Active = true;


            btnSubmit.TouchUpInside += async delegate
            {
                // Validate all required fields
                if (string.IsNullOrWhiteSpace(txtFullName.Text))
                {
                    lblValidation.Text = AppDelegate.BundleToUse.GetLocalizedString("register_v_fullname");
                    lblValidation.Hidden = false;
                    vwScrollView.SetContentOffset(new CoreGraphics.CGPoint(0, -vwScrollView.ContentInset.Top), true);
                    return;
                }
                if (string.IsNullOrWhiteSpace(txtCity.Text))
                {
                    lblValidation.Text = AppDelegate.BundleToUse.GetLocalizedString("register_v_city");
                    lblValidation.Hidden = false;
                    vwScrollView.SetContentOffset(new CoreGraphics.CGPoint(0, -vwScrollView.ContentInset.Top), true);
                    return;
                }
                if (string.IsNullOrWhiteSpace(txtCountry.Text))
                {
                    lblValidation.Text = AppDelegate.BundleToUse.GetLocalizedString("register_v_country");
                    lblValidation.Hidden = false;
                    vwScrollView.SetContentOffset(new CoreGraphics.CGPoint(0, -vwScrollView.ContentInset.Top), true);
                    return;
                }
                if (string.IsNullOrWhiteSpace(txtFacebookUsername.Text))
                {
                    lblValidation.Text = AppDelegate.BundleToUse.GetLocalizedString("register_v_facebook_username");
                    lblValidation.Hidden = false;
                    vwScrollView.SetContentOffset(new CoreGraphics.CGPoint(0, -vwScrollView.ContentInset.Top), true);
                    return;
                }
                if (string.IsNullOrWhiteSpace(txtQuestion1.Text))
                {
                    lblValidation.Text = AppDelegate.BundleToUse.GetLocalizedString("register_v_finished_beginner_courses");
                    lblValidation.Hidden = false;
                    vwScrollView.SetContentOffset(new CoreGraphics.CGPoint(0, -vwScrollView.ContentInset.Top), true);
                    return;
                }
                if (string.IsNullOrWhiteSpace(txtQuestion2.Text))
                {
                    lblValidation.Text = AppDelegate.BundleToUse.GetLocalizedString("register_v_local_church");
                    lblValidation.Hidden = false;
                    vwScrollView.SetContentOffset(new CoreGraphics.CGPoint(0, -vwScrollView.ContentInset.Top), true);
                    return;
                }
                if (string.IsNullOrWhiteSpace(txtQuestion3.Text))
                {
                    lblValidation.Text = AppDelegate.BundleToUse.GetLocalizedString("register_v_tell_training");
                    lblValidation.Hidden = false;
                    vwScrollView.SetContentOffset(new CoreGraphics.CGPoint(0, -vwScrollView.ContentInset.Top), true);
                    return;
                }

                var postTo = AppDelegate.BundleToUse.GetLocalizedString("register_post_url");
                var source = AppDelegate.BundleToUse.GetLocalizedString("register_source");

                var parms = new Dictionary<string, string>();
                parms.Add("Name", txtFullName.Text);
                parms.Add("City", txtCity.Text);
                parms.Add("Country", txtCountry.Text);
                parms.Add("FacebookUserName", txtFacebookUsername.Text);
                parms.Add("WhatsAppNum", txtWhatsAppNumber.Text);
                parms.Add("CoursesCompleted", txtQuestion1.Text);
                parms.Add("Local", txtQuestion2.Text);
                parms.Add("Training", txtQuestion3.Text);
                parms.Add("MoreInfo", txtComments.Text);
                parms.Add("Source", source);

                var request = new HttpRequestMessage(System.Net.Http.HttpMethod.Post, postTo) { Content = new FormUrlEncodedContent(parms) };

                var client = new HttpClient();
                await client.SendAsync(request);

                vwBlueBG.RemoveFromSuperview();

                var newvwBlueBG = new UIView() { TranslatesAutoresizingMaskIntoConstraints = false };
                newvwBlueBG.BackgroundColor = UIColor.FromRGB(28, 117, 188);
                vwContent.Add(newvwBlueBG);
                newvwBlueBG.TopAnchor.ConstraintEqualTo(imgBlueCircle.BottomAnchor, 0).Active = true;
                newvwBlueBG.LeadingAnchor.ConstraintEqualTo(vwContent.LeadingAnchor, 0).Active = true;
                newvwBlueBG.TrailingAnchor.ConstraintEqualTo(vwContent.TrailingAnchor, 0).Active = true;
                newvwBlueBG.BottomAnchor.ConstraintEqualTo(vwContent.BottomAnchor, 0).Active = true;
                newvwBlueBG.HeightAnchor.ConstraintEqualTo(vwScrollView.HeightAnchor).Active = true;

                var lblThankYou = new UILabel() { TranslatesAutoresizingMaskIntoConstraints = false };
                lblThankYou.Text = AppDelegate.BundleToUse.GetLocalizedString("register_thank_you_message");
                lblThankYou.TextColor = UIColor.White;
                lblThankYou.TextAlignment = UITextAlignment.Center;
                newvwBlueBG.Add(lblThankYou);
                lblThankYou.TopAnchor.ConstraintEqualTo(newvwBlueBG.TopAnchor, margin).Active = true;
                lblThankYou.LeadingAnchor.ConstraintEqualTo(newvwBlueBG.LeadingAnchor, margin).Active = true;
                lblThankYou.TrailingAnchor.ConstraintEqualTo(newvwBlueBG.TrailingAnchor, -margin).Active = true;

                vwScrollView.SetContentOffset(new CoreGraphics.CGPoint(0, -vwScrollView.ContentInset.Top), true);
            };
        }
    }
}