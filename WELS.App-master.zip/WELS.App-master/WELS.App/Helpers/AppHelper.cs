﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;

namespace WELS.App.Helpers
{
    public class AppHelper
    {
        public static int GetResourceID(string name)
        {
            return (int)typeof(Resource.Id).GetField(name).GetValue(null);
        }

        public static int GetResourceDrawable(string name)
        {
            return (int)typeof(Resource.Drawable).GetField(name).GetValue(null);
        }

        public static int GetResourceColor(string name)
        {
            return (int)typeof(Resource.Color).GetField(name).GetValue(null);
        }


        // http://www.java2s.com/Code/Android/UI/setListViewHeightBasedOnChildren.htm
        public static void SetListHeightToChildren(ListView view)
        {
            IListAdapter listAdapter = view.Adapter;
            if (listAdapter == null) return;

            int totalHeight = 0;
            for (int i = 0; i < listAdapter.Count; i++)
            {
                View item = listAdapter.GetView(i, null, view);
                item.Measure(0, 0);
                totalHeight += item.MeasuredHeight;
            }

            ViewGroup.LayoutParams layoutParams = view.LayoutParameters;
            layoutParams.Height = totalHeight + (view.DividerHeight * (listAdapter.Count - 1)) + 60;
            view.LayoutParameters = layoutParams;
            view.RequestLayout();
        }
    }
}