﻿using Android.App;
using Android.Content;
using Android.OS;
using Android.Util;
using Android.Views.InputMethods;
using Firebase.Iid;
using Microsoft.AppCenter;
using Microsoft.AppCenter.Analytics;
using Microsoft.AppCenter.Crashes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WELS.App.Activities;
using WELS.App.Shared.Data;
using WELS.App.Shared.Helpers;
using WELS.App.Shared.Models.Response;
using WindowsAzure.Messaging;
using Xamarin.Facebook;
using Xamarin.Facebook.AppEvents;
using Xamarin.Facebook.Login;

namespace WELS.App
{
#if DEBUG
    [Application(Debuggable=true, LargeHeap = true)]
#else
[Application(Debuggable = false, LargeHeap = true)]
#endif
    public class App : Application
    {
        public static AppDataHelper DataHelper { get; } = new AppDataHelper(new AppDataHelperSettings()
        {
            DefaultEncouragementMessage = "May God bless you on your spiritual journey!"
        });
        public static Account CurrentAccount { get; set; }
        public static string AccountSource { get; set; }
        /// <summary>
        /// Set this to true once we start to sync courses via the API.  Prevent future attempts to pull via the API after the first attempt.
        /// </summary>
        public static bool CourseDownloadStarted { get; set; } = false;
        public static List<Course> Courses { get; private set; } = new List<Course>();
#if DEBUG
        public const string ListenConnectionString = "Endpoint=sb://wels-ns.servicebus.windows.net/;SharedAccessKeyName=DefaultListenSharedAccessSignature;SharedAccessKey=4WBRCY5gugg9pCVn6j/Fq7jP2Sk3bRTvCOprlMReiT4=";

        public const string NotificationHubName = "wels-tell-app-debug";
#else
        public const string ListenConnectionString = "Endpoint=sb://wels-ns.servicebus.windows.net/;SharedAccessKeyName=DefaultListenSharedAccessSignature;SharedAccessKey=b7nQPh7sjkov2LVihG1SVc1YAsQjJ0DQp7RxlbDFrbQ=";
        public const string NotificationHubName = "wels-tell-app";
#endif
        public const string NotificationChannel = "notification_channel";

        public static bool PreventRedirectToSignup = false;
        public static List<LanguageResponse> Languages;

        private static LanguageResponse _currentLanguage;
        public static async Task<LanguageResponse> CurrentLanguage()
        {
            if (_currentLanguage == null)
            {
                if (Languages == null || !Languages.Any())
                {
                    Languages = (await App.DataHelper.GetLanguages()).ToList();
#if (ACADEMIACRISTO)
            _currentLanguage = Languages.FirstOrDefault(l => l.CultureCode.ToLower() == "es-mx");
#else
                    _currentLanguage = Languages.FirstOrDefault(l => l.CultureCode.ToLower() == "en-us");
#endif
                }
            }
            return _currentLanguage;
        }

        public static MyProfileTracker ProfileTracker = new MyProfileTracker();

        public App(IntPtr javaReference, Android.Runtime.JniHandleOwnership transfer) : base(javaReference, transfer) { }        

        public override void OnCreate()
        {
            base.OnCreate();
#if DEBUG
            AppCenter.Start("957cf190-280d-4246-9ce9-62de4b8260d2", typeof(Analytics), typeof(Crashes));
#else
            AppCenter.Start("7cbfba52-63b2-4921-b7d3-e7b6f5765975", typeof(Analytics), typeof(Crashes));
#endif
        }

        public static void ShowLoadingActivity(Activity currentActivity)
        {
            // START LOADING ACTIVITY
            // Since we're manually triggering this activity, skip the "NextActivity" call
            Intent loadingIntent = new Intent(currentActivity, typeof(LoadingActivity));
            loadingIntent.PutExtra("SkipNextActivity", true);
            currentActivity.StartActivity(loadingIntent);
        }

        public static async Task NextActivity(Activity currentActivity)
        {
#if (ACADEMIACRISTO)
            App.AccountSource = currentActivity.GetString(Resource.String.account_source_es);
#else
            App.AccountSource = currentActivity.GetString(Resource.String.account_source);
#endif

            // check if user is logged in
            // https://github.com/facebook/facebook-android-sdk/tree/master/samples/FBLoginSample/src/main/java/com/facebook/fbloginsample
            var accessToken = AccessToken.CurrentAccessToken;
            var isLoggedInToFacebook = accessToken != null && !accessToken.IsExpired;
            var isLoggedInViaWhatsApp = !string.IsNullOrEmpty(DataHelper.WhatsAppNumberForLogin) && DataHelper.IsApiTokenActive();
            var completedFirstCourse = await App.DataHelper.HasAccountCompletedFirstCourse((await App.CurrentLanguage()).LanguageNodeID);

            // Redirect to welcome video if we haven't watched it yet
            if (!DataHelper.UserHasWatchedWelcomeVideo)
            {
                Intent welcomeVideoIntent = new Intent(currentActivity, typeof(WelcomeVideoActivity));
                currentActivity.StartActivity(welcomeVideoIntent);
            }
            // Only redirect to login if:  We are not already logged in AND we have completed the first course
            else if (!isLoggedInToFacebook && !isLoggedInViaWhatsApp && completedFirstCourse)
            {
                // START LOGIN ACTIVITY
                Intent loginIntent = new Intent(currentActivity, typeof(LoginActivity));
                currentActivity.StartActivity(loginIntent);
            }
            else
            {
                if (isLoggedInToFacebook)
                {
                    await DataHelper.SetFacebookLogin(accessToken.UserId, accessToken.Token, FacebookSdk.ApplicationId);
                    CurrentAccount = await App.DataHelper.GetAccount((await CurrentLanguage()).LanguageNodeID, App.AccountSource, Profile.CurrentProfile.Name, Profile.CurrentProfile.GetProfilePictureUri(68, 68).ToString());
                }
                else
                {
                    CurrentAccount = await App.DataHelper.GetAccount((await CurrentLanguage()).LanguageNodeID, App.AccountSource);
                }
                // Failsafe for pre-existing accounts that have logged in, but haven't had the new HasAuthenticated flag set
                if ((isLoggedInToFacebook || isLoggedInViaWhatsApp) && !App.CurrentAccount.HasAuthenticated)
                {
                    App.CurrentAccount.HasAuthenticated = true;
                    await App.DataHelper.SaveAccount(App.CurrentAccount);
                }
                App.RefreshPushNotificationTags();

                if ((await CurrentLanguage()) != null)
                {
                    ChangeLocale(currentActivity, (await CurrentLanguage()).CultureCode.Replace("-", "_"));
                }

                // Reload static Courses var from DB in case anything has changed
                ReloadCoursesFromDB();

                if (CurrentAccount.LanguageNodeID == null)
                {
                    //if (languages.Count() > 1)
                    //{
                    //    // START LANGUAGE SELECTION ACTIVITY
                    //    Intent i = new Intent(currentActivity, typeof(LanguageConfirmActivity));
                    //    currentActivity.StartActivity(i);
                    //}
                    //else 
                    if ((await CurrentLanguage()) != null)
                    {
                        App.CurrentAccount.LanguageNodeID = (await CurrentLanguage()).LanguageNodeID;
                        await App.DataHelper.SyncEncouragementMessages(App.CurrentAccount.LanguageNodeID.Value);
                        await App.DataHelper.SaveAccount(App.CurrentAccount);
                        await NextActivity(currentActivity);
                    }
                    else
                    {
                        // No languages found
                        Intent messageIntent = new Intent(currentActivity, typeof(MessageActivity));
                        messageIntent.PutExtra("Message", currentActivity.GetString(Resource.String.error_missing_languages));
                        currentActivity.StartActivity(messageIntent);
                    }
                }
                else if (CurrentAccount.DateCompletedOnboarding == null && completedFirstCourse)
                {
                    var onboarding = await App.DataHelper.GetOnboarding(App.CurrentAccount.LanguageNodeID ?? 0);
                    var sortedVideos = onboarding.Videos.OrderBy(v => v.MinimumScore);
                    var video = sortedVideos.FirstOrDefault();

                    // If there are no videos, complete onboarding and move on
                    if (video == null || string.IsNullOrWhiteSpace(video.VideoURL))
                    {
                        App.CurrentAccount.OnBoardingTotalScore = 99;
                        App.CurrentAccount.DateCompletedOnboarding = DateTime.UtcNow;
                        await App.DataHelper.SaveAccount(App.CurrentAccount);
                        await App.NextActivity(currentActivity);
                    }
                    else
                    {
                        // START ONBOARDING ACTIVITY
                        Intent onboardingIntent = new Intent(currentActivity, typeof(OnboardingFinishActivity));
                        currentActivity.StartActivity(onboardingIntent);
                    }
                }
                // Show course list if the user has downloaded all of their courses OR they haven't yet completed their (free) first course
                else if (Courses.Any() && (CurrentAccount.HasDownloadedAllCourses || !completedFirstCourse))
                {
                    // START COURSES ACTIVITY
                    Intent loginIntent = new Intent(currentActivity, typeof(CoursesActivity));
                    currentActivity.StartActivity(loginIntent);
                }
                else
                {
                    CourseDownloadStarted = true;

                    // Get all course data, then go to the next activity
                    await App.DataHelper.SyncCourses((await CurrentLanguage()).LanguageNodeID);
                    ReloadCoursesFromDB();
                    if (!Courses.Any())
                    {
                        Intent messageIntent = new Intent(currentActivity, typeof(MessageActivity));
                        messageIntent.PutExtra("Message", currentActivity.GetString(Resource.String.error_missing_courses));
                        currentActivity.StartActivity(messageIntent);
                    }
                    else
                    {
                        await NextActivity(currentActivity);
                    }
                }
            }
        }

        public static void ReloadCoursesFromDB()
        {
            if (CurrentAccount.LanguageNodeID != null)
            {
                Courses = DataHelper.GetCoursesFromDB(CurrentAccount.LanguageNodeID.Value).ToList();
            }
        }

        /// <summary>
        /// Device Independent Pixels to Actual Pixles conversion
        /// </summary>
        /// <param name="context"></param>
        /// <param name="valueInDp"></param>
        /// <returns></returns>
        public static int DpToPixels(Context context, int valueInDp)
        {
            DisplayMetrics metrics = context.Resources.DisplayMetrics;
            return Convert.ToInt32(TypedValue.ApplyDimension(ComplexUnitType.Dip, valueInDp, metrics));
        }

        /// <summary>
        /// Call this every time we change users or enable/disable notifications within the app
        /// </summary>
        public static void RefreshPushNotificationTags()
        {
            Task.Run(() =>
            {
                if (App.CurrentAccount != null)
                {
                    var hub = new NotificationHub(App.NotificationHubName,
                                                App.ListenConnectionString, App.Context);
                    if (App.CurrentAccount.EnablePushNotifications)
                    {

                        string[] tags = new string[] { $"user:{CurrentAccount.PushNotificationID()}" };
                        hub.Register(FirebaseInstanceId.Instance.Token, tags);
                        Log.Debug("App", $"Registered {FirebaseInstanceId.Instance.Token} Push Notification Tag: {tags[0]}");
                    }
                    else
                    {
                        hub.UnregisterAll(FirebaseInstanceId.Instance.Token);
                        Log.Debug("App", $"Unregistered {FirebaseInstanceId.Instance.Token} all tags");
                    }
                }
            });
        }

        public static void HideKeyboard(Context context)
        {
            var inputMethodManager = context.GetSystemService(Context.InputMethodService) as InputMethodManager;
            if (inputMethodManager != null && context is Activity)
            {
                var activity = context as Activity;
                var token = activity.CurrentFocus?.WindowToken;
                inputMethodManager.HideSoftInputFromWindow(token, HideSoftInputFlags.None);

                activity.Window.DecorView.ClearFocus();
            }
        }

        /// <summary>
        /// If we can find a better solution than this, please implement it :)
        /// Started from https://stackoverflow.com/questions/40221711/android-context-getresources-updateconfiguration-deprecated, modified for Xamarin,
        /// and modified as various devices were tested
        /// </summary>
        /// <returns></returns>
        public static bool ChangeLocale(Activity currentActivity, string androidLocale)
        {
            var split = androidLocale.Split("_");
            var locale = new Java.Util.Locale(split[0], split[1]);
            var resources = currentActivity.Resources;
            var configuration = resources.Configuration;
            DisplayMetrics displayMetrics = resources.DisplayMetrics;
            if (locale == configuration.Locale) return false;
            if (Build.VERSION.SdkInt >= Android.OS.BuildVersionCodes.JellyBeanMr1)
            {
                configuration.SetLocale(locale);
                configuration.Locale = locale;
            }
            else
            {
                configuration.Locale = locale;
            }
            if (Build.VERSION.SdkInt >= Android.OS.BuildVersionCodes.N)
            {
                currentActivity.ApplicationContext.CreateConfigurationContext(configuration);
                resources.UpdateConfiguration(configuration, displayMetrics);
            }
            else
            {
                resources.UpdateConfiguration(configuration, displayMetrics);
            }
            return true;
        }

        public static void ScrollToTop(CoursesActivity activity)
        {
            activity.ScrollView.ScrollTo(0, 0);
        }

        public static void LogViewContentEvent(Activity activity, string contentType, string contentData, string contentID)
        {
            var logger = AppEventsLogger.NewLogger(activity);
            Bundle parms = new Bundle();
            parms.PutString(AppEventsConstants.EventParamContentType, contentType);
            parms.PutString(AppEventsConstants.EventParamContent, contentData);
            parms.PutString(AppEventsConstants.EventParamContentId, contentID);
            logger.LogEvent(AppEventsConstants.EventNameViewedContent, parms);
        }

        public static void Logout()
        {
            LoginManager.Instance.LogOut();
            App.DataHelper.WhatsAppNumberForLogin = null;
            App.DataHelper.ClearToken();
            App.DataHelper.ClearData();
            Courses = new List<Course>();
            CourseDownloadStarted = false;
        }
    }
}