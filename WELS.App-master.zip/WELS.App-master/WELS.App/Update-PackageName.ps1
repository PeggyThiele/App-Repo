param ([string] $ProjectDir, [string] $ConfigurationName)
$ProjectDir = $ProjectDir.Trim(" ")
Write-Host "ProjectDir: $ProjectDir"
Write-Host "ConfigurationName: $ConfigurationName"

$ManifestPath = $ProjectDir + "Properties\AndroidManifest.xml"

Write-Host "ManifestPath: $ManifestPath"

[xml] $xdoc = Get-Content $ManifestPath

$package = $xdoc.manifest.package

If ($ConfigurationName -eq "ReleaseTell")
{
$package = "com.tellnetwork.tell"
$xdoc.SelectSingleNode("/manifest/application/meta-data").SetAttribute("android:value", "@string/facebook_app_id")
$xdoc.Save($ManifestPath)
}
If ($ConfigurationName -eq "ReleaseAcademiaCristo")
{
$package = "com.tellnetwork.academiacristo"
$xdoc.SelectSingleNode("/manifest/application/meta-data").SetAttribute("android:value", "@string/facebook_app_id_es")
$xdoc.Save($ManifestPath)
}
If ($ConfigurationName -eq "Debug")
{
$package = "com.tellnetwork.tell.debug"
$xdoc.SelectSingleNode("/manifest/application/meta-data").SetAttribute("android:value", "@string/facebook_app_id")
$xdoc.Save($ManifestPath)
}
If ($ConfigurationName -eq "DebugAcademiaCristo")
{
$package = "com.tellnetwork.academiacristo.debug"
$xdoc.SelectSingleNode("/manifest/application/meta-data").SetAttribute("android:value", "@string/facebook_app_id_es")
$xdoc.Save($ManifestPath)
}

If ($package -ne $xdoc.manifest.package)
{
$xdoc.manifest.package = $package
$xdoc.Save($ManifestPath)
Write-Host "AndroidManifest.xml package name updated to $package"
}