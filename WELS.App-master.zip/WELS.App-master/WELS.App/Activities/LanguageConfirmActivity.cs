﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;

namespace WELS.App.Activities
{
    [Activity(Label = "SelectLanguageActivity")]
    public class LanguageConfirmActivity : Activity
    {
        protected async override void OnCreate(Bundle savedInstanceState)
        {
            base.OnCreate(savedInstanceState);
            
            SetContentView(Resource.Layout.activity_language_confirm);

#if (ACADEMIACRISTO)
            var image = FindViewById<ImageView>(Resource.Id.logo);
            image.SetImageResource(Resource.Drawable.academia_cristo_w_tagline);
#endif

            // If we're here, the user can proceed with the device language or go to a selection page
            // to select a new language
            // We need to:
            // 1.  Determine the device language
            // 2.  Pull all languages from the API
            // 3.  Ensure that the device language is available as an option
            // 4.  If not, default to en-US
            // 5.  Get the display name of the language and load that into the TextViews Text
            // 6.  Handle clicks (either proceed with current language, or redirect to language selector
            var btnProceed = FindViewById<Button>(Resource.Id.btnProceed);
            var btnSelectDifferentLanguage = FindViewById<Button>(Resource.Id.btnSelectDifferentLanguage);
            var ddlSelectedLanguage = FindViewById<Spinner>(Resource.Id.ddlSelectedLanguage);
            
            var culture = Resources.Configuration.Locale.ToString().Replace("_", "-");
            var languages = await App.DataHelper.GetLanguages();
            var defaultLanguage = languages.FirstOrDefault(l => l.CultureCode == culture);
            if (defaultLanguage == null)
            {
#if (ACADEMIACRISTO)
                defaultLanguage = languages.FirstOrDefault(l => l.CultureCode == "es-MX");
#else
                defaultLanguage = languages.FirstOrDefault(l => l.CultureCode == "en-US");
#endif
            }
            var defaultLanguageIndex = languages.ToList().IndexOf(defaultLanguage);

            var adapter = new ArrayAdapter<string>(this, Resource.Layout.control_dropdown_style, languages.Select(l => l.Name).ToArray());
            adapter.SetDropDownViewResource(Resource.Layout.control_dropdown_item_style);
            ddlSelectedLanguage.Adapter = adapter;
            ddlSelectedLanguage.Visibility = ViewStates.Gone;
            ddlSelectedLanguage.SetSelection(defaultLanguageIndex);

            FindViewById<TextView>(Resource.Id.current_version_label).Text = string.Format(FindViewById<TextView>(Resource.Id.current_version_label).Text, defaultLanguage.Name);
            btnProceed.Text = string.Format(FindViewById<TextView>(Resource.Id.btnProceed).Text, defaultLanguage.Name);
            btnProceed.Click += async delegate
            {
                App.CurrentAccount.LanguageNodeID = languages.FirstOrDefault(l => l.Name == (string)ddlSelectedLanguage.SelectedItem).LanguageNodeID;
                await App.DataHelper.SyncEncouragementMessages(App.CurrentAccount.LanguageNodeID.Value);
                await App.DataHelper.SaveAccount(App.CurrentAccount);
                await App.NextActivity(this);
                Finish();
            };

            // If there is only one language, trigger the proceed click
            if (languages.Count() == 1)
            {
                btnProceed.CallOnClick();
            }

            btnSelectDifferentLanguage.Click += delegate
            {
                btnSelectDifferentLanguage.Visibility = ViewStates.Gone;
                ddlSelectedLanguage.Visibility = ViewStates.Visible;
                btnProceed.SetText(Resource.String.language_button_proceed_with_this_language);
            };
        }
    }
}