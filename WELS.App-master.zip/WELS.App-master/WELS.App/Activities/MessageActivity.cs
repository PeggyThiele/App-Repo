﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.Gms.Common;
using Android.OS;
using Android.Runtime;
using Android.Util;
using Android.Views;
using Android.Widget;

namespace WELS.App.Activities
{
    [Activity(Label = "Message")]
    public class MessageActivity : Activity
    {
        TextView txtMessage;
        /// <summary>
        /// This activity is displayed to the user when most the course content download takes place
        /// </summary>
        /// <param name="savedInstanceState"></param>
        protected override void OnCreate(Bundle savedInstanceState)
        {
            base.OnCreate(savedInstanceState);

            SetContentView(Resource.Layout.activity_message);

            txtMessage = FindViewById<TextView>(Resource.Id.txtMessage);
            txtMessage.Text = this.Intent.GetStringExtra("Message");
        }

        public override void OnBackPressed()
        {
            // prevent on back
        }
    }
}