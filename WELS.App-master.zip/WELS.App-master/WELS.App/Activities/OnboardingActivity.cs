﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Android.Animation;
using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Support.Constraints;
using Android.Views;
using Android.Widget;
using WELS.App.Shared.Interfaces;
using WELS.App.Shared.Models.Response;

namespace WELS.App
{
    [Activity(Label = "OnboardingActivity")]
    public class OnboardingActivity : Activity, OnboardingCardFragment.Listener
    {
        public int QuestionIndex = 0;
        public OnboardingCardFragment CurrentFragment { get; set; }
        public ProgressBar Progress { get; set; }
        public OnboardingResponse Onboarding { get; set; }
        private int _score { get; set; }

        protected override void OnCreate(Bundle savedInstanceState)
        {
            base.OnCreate(savedInstanceState);

            // Create your application here
            SetContentView(Resource.Layout.activity_onboarding);

#if (ACADEMIACRISTO)
            var image = FindViewById<ImageView>(Resource.Id.logo);
            image.SetImageResource(Resource.Drawable.academia_cristo_w_tagline);
#endif

            Progress = FindViewById<ProgressBar>(Resource.Id.progress);

            RunOnUiThread(async () =>
            {
                try
                {
                    Onboarding = await App.DataHelper.GetOnboarding(App.CurrentAccount.LanguageNodeID ?? 0);
                    NextQuestion();
                }
                catch (System.Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }
            });
        }

        public override void OnBackPressed()
        {
            // prevent on back
        }

        public void OnQuestionYesClick(int score)
        {
            _score += score;
            QuestionIndex++;
            NextQuestion();
        }

        public void OnQuestionNoClick(int score)
        {
            _score += score;
            QuestionIndex++;
            NextQuestion();
        }

        public void UpdateProgress()
        {
            double startProgress = ((double)QuestionIndex) / ((double)Onboarding.Questions.Count() + 1.0) * 100.0;
            double progress = ((double)QuestionIndex + 1.0) / ((double)Onboarding.Questions.Count() + 1.0) * 100.0;
            var animator = ValueAnimator.OfInt((int)startProgress, (int)progress);
            animator.SetDuration(1000);
            animator.Update += (object sender, ValueAnimator.AnimatorUpdateEventArgs e) =>
            {
                Progress.Progress = (int)e.Animation.AnimatedValue;
            };
            animator.Start();
        }

        public void NextQuestion()
        {
            // If we just completed the last question, update the account with the onboarding data and then start the Onboarding video activity
            if(QuestionIndex >= Onboarding.Questions.Count())
            {
                RunOnUiThread(async () =>
                {
                    App.ShowLoadingActivity(this);

                    // Update the account onboarding data
                    App.CurrentAccount.OnBoardingTotalScore = _score;
                    await App.DataHelper.SaveAccount(App.CurrentAccount);

                    // Load the video based on the score:  Find the highest minimum score video where the user score is at least as high
                    var sortedVideos = Onboarding.Videos.Where(v => _score >= v.MinimumScore).OrderBy(v => v.MinimumScore);
                    var video = sortedVideos.FirstOrDefault();
                    
                    Intent onboardingIntent = new Intent(this, typeof(OnboardingFinishActivity));
                    // If we have no video, just go to the next activity
                    if (video == null)
                    {
                        App.CurrentAccount.DateCompletedOnboarding = DateTime.UtcNow;
                        await App.DataHelper.SaveAccount(App.CurrentAccount);
                        await App.NextActivity(this);
                        Finish();
                    }
                    // if we have a video, go to the OnboardingFinishActivity
                    else
                    {
                        onboardingIntent.PutExtra("videoUrl", video.VideoURL);
                        StartActivity(onboardingIntent);
                        Finish();
                    }
                });
            }
            // Otherwise move onto the next question
            else
            {
                if(CurrentFragment != null)
                {
                    FragmentManager.BeginTransaction().Remove(CurrentFragment).Commit();
                }
                var cardFragment = new OnboardingCardFragment();
                cardFragment.PassQuestion(Onboarding.Questions.ElementAt(QuestionIndex));
                CurrentFragment = cardFragment;
                FragmentManager.BeginTransaction().Add(Resource.Id.frame_container, cardFragment).Commit();
                UpdateProgress();
            }
        }
    }
}