﻿using Android.App;
using Android.Content;
using Android.Net;
using Android.OS;
using Android.Runtime;
using Android.Support.Constraints;
using Android.Support.Design.Widget;
using Android.Support.V4.Widget;
using Android.Support.V7.App;
using Android.Views;
using Android.Widget;
using System.Linq;
using WELS.App.Fragments;
using Xamarin.Essentials;

namespace WELS.App
{
#if (ACADEMIACRISTO)
    [Activity(Label = "@string/app_name_es", Theme = "@style/AppTheme.NoActionBar")]
#else
    [Activity(Label = "@string/app_name", Theme = "@style/AppTheme.NoActionBar")]
#endif
    public class CoursesActivity : AppCompatActivity, BottomNavigationView.IOnNavigationItemSelectedListener
    {
        public DrawerLayout Drawer { get; set; }
        public ConstraintLayout ContentLayout { get; set; }
        public BottomNavigationView BottomNavigation { get; set; }
        public NavigationView Navigation { get; set; }
        private Bundle SavedInstanceState { get; set; }
        public ScrollView ScrollView { get; set; }

        protected override void OnCreate(Bundle savedInstanceState)
        {
            base.OnCreate(savedInstanceState);

            SavedInstanceState = savedInstanceState;

            // Set our view from the "main" layout resource
            SetContentView(Resource.Layout.activity_courses);

            ContentLayout = FindViewById<ConstraintLayout>(Resource.Id.contentLayout);
            Drawer = FindViewById<DrawerLayout>(Resource.Id.drawer);
            ScrollView = FindViewById<ScrollView>(Resource.Id.scrollViewMain);

            BottomNavigation = FindViewById<BottomNavigationView>(Resource.Id.navigation);
            BottomNavigation.SetOnNavigationItemSelectedListener(this);
            if (App.CurrentAccount == null || !App.CurrentAccount.HasAuthenticated)
            {
                HideAccountNav();
            }
            else
            {
                ShowAccountNav();
            }

            Navigation = FindViewById<NavigationView>(Resource.Id.nav);
            Navigation.NavigationItemSelected += Navigation_NavigationItemSelected;

            // Remove Facebook from TELL (English) app
#if (!ACADEMIACRISTO)
            Navigation.Menu.RemoveItem(Resource.Id.navigation_facebook);
#endif

            // If we're at the quiz end AND HAVENT YET COMPlETED ALL COURSES OR NOT BEEN AUTHENTICATED, open the quiz end fragment, else default to the courses
            if (this.Intent.GetBooleanExtra("ShowQuizEnd", false) && (App.Courses.Any(c => c.DateCompleted == null) || !App.CurrentAccount.HasAuthenticated))
            {
                this.Intent.PutExtra("ShowQuizEnd", false);
                var args = new Bundle();
                args.PutInt("CourseNodeID", this.Intent.GetIntExtra("CourseNodeID", 0));
                args.PutInt("LessonNodeID", this.Intent.GetIntExtra("LessonNodeID", 0));

                App.ScrollToTop(this);
                FragmentManager.BeginTransaction().Replace(Resource.Id.frame_container, new QuizEndFragment() { Arguments = args }).Commit();
            }
            else
            {
                // If saved instance is null, this is likely the first load
                if (SavedInstanceState == null)
                {
                    BottomNavigation.SelectedItemId = Resource.Id.navigation_courses;
                }
            }
        }

        private void Navigation_NavigationItemSelected(object sender, NavigationView.NavigationItemSelectedEventArgs e)
        {
            // HACK: Reset the locale after loading the webview:  https://stackoverflow.com/questions/40398528/android-webview-language-changes-abruptly-on-android-7-0-and-above
            // Force English for TELL, Spanish for Academia Cristo
#if (ACADEMIACRISTO)
            App.ChangeLocale(this, "es_MX");
#else
            App.ChangeLocale(this, "en_US");
#endif
            switch (e.MenuItem.ItemId)
            {
                case Resource.Id.navigation_contact:
                    var intent1 = new Intent(Intent.ActionView, Uri.Parse(this.GetString(Resource.String.nav_contact_link)));
                    StartActivity(intent1);
                    break;
                case Resource.Id.navigation_website:
                    var intent2 = new Intent(Intent.ActionView, Uri.Parse(this.GetString(Resource.String.nav_website_link)));
                    StartActivity(intent2);
                    break;
                case Resource.Id.navigation_facebook:
                    var intent3 = new Intent(Intent.ActionView, Uri.Parse(this.GetString(Resource.String.nav_facebook_link)));
                    StartActivity(intent3);
                    break;
                case Resource.Id.navigation_share:
                    var clipboard = (ClipboardManager)GetSystemService(ClipboardService);
                    var clip = ClipData.NewPlainText("TELL App Download", this.GetString(Resource.String.nav_share_link));
                    clipboard.PrimaryClip = clip;
                    
                    Android.App.AlertDialog.Builder dialog = new Android.App.AlertDialog.Builder(this);
                    Android.App.AlertDialog alert = dialog.Create();
                    alert.SetMessage(this.GetString(Resource.String.nav_link_copied));
                    alert.Show();
                    break;
                case Resource.Id.navigation_youtube:
                    var intent4 = new Intent(Intent.ActionView, Uri.Parse(this.GetString(Resource.String.nav_youtube_link)));
                    StartActivity(intent4);
                    break;
                case Resource.Id.navigation_instagram:
                    var intent5 = new Intent(Intent.ActionView, Uri.Parse(this.GetString(Resource.String.nav_instagram_link)));
                    StartActivity(intent5);
                    break;
                case Resource.Id.navigation_email:
                    var intent6 = new Intent(Intent.ActionView, Uri.Parse(this.GetString(Resource.String.nav_email_link)));
                    StartActivity(intent6);
                    break;
                case Resource.Id.navigation_whatsapp:
                    var intent7 = new Intent(Intent.ActionView, Uri.Parse(this.GetString(Resource.String.nav_whatsapp_link)));
                    StartActivity(intent7);
                    break;
            }
        }

        public override void OnRequestPermissionsResult(int requestCode, string[] permissions, [GeneratedEnum] Android.Content.PM.Permission[] grantResults)
        {
            Platform.OnRequestPermissionsResult(requestCode, permissions, grantResults);

            base.OnRequestPermissionsResult(requestCode, permissions, grantResults);
        }

        public bool OnNavigationItemSelected(IMenuItem item)
        {
            switch (item.ItemId)
            {
                case Resource.Id.navigation_courses:
                    App.ScrollToTop(this);
                    FragmentManager.BeginTransaction().Replace(Resource.Id.frame_container, new CoursesFragment()).Commit();
                    return true;
                case Resource.Id.navigation_profile:
                    App.ScrollToTop(this);
                    FragmentManager.BeginTransaction().Replace(Resource.Id.frame_container, new AccountFragment()).Commit();
                    return true;
                case Resource.Id.navigation_menu:
                    Drawer.OpenDrawer(Navigation);
                    return true;
            }
            return false;
        }

        /// <summary>
        /// Prevent anything from occurring during back button press while this activity is focused, with a few exceptions
        /// </summary>
        public override void OnBackPressed()
        {
            // If we're on the course fragment, allow going back to the courseS (landing) fragment
            Fragment fragment = (CourseFragment)FragmentManager.FindFragmentByTag("CourseFragmentTag");
            if (fragment != null && fragment.IsVisible)
            {
                App.ScrollToTop(this);
                FragmentManager.BeginTransaction().Replace(Resource.Id.frame_container, new CoursesFragment()).Commit();
            }
        }

        public void HideAccountNav()
        {
            BottomNavigation.Menu.FindItem(Resource.Id.navigation_courses).SetVisible(false);
            BottomNavigation.Menu.FindItem(Resource.Id.navigation_profile).SetVisible(false);
        }

        public void ShowAccountNav()
        {
            BottomNavigation.Menu.FindItem(Resource.Id.navigation_courses).SetVisible(true);
            BottomNavigation.Menu.FindItem(Resource.Id.navigation_profile).SetVisible(true);
        }
    }
}