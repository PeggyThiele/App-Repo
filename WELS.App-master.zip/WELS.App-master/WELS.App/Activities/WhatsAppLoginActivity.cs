﻿using Android.App;
using Android.Content;
using Android.OS;
using Android.Support.Constraints;
using Android.Views;
using Android.Views.InputMethods;
using Android.Widget;
using Java.Lang;
using Plugin.SecureStorage;
using ReactiveUI;
using System;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using WELS.App.Activities;
using Xamarin.Facebook;
using Xamarin.Facebook.Login;

namespace WELS.App
{
    [Activity(Label = "WhatsAppLoginActivity")]
    public class WhatsAppLoginActivity : Activity
    {
        protected override void OnCreate(Bundle savedInstanceState)
        {
            base.OnCreate(savedInstanceState);

            // Create your application here
            SetContentView(Resource.Layout.activity_whatsapp_login);

#if (ACADEMIACRISTO)
            var image = FindViewById<ImageView>(Resource.Id.logo);
            image.SetImageResource(Resource.Drawable.academia_cristo_w_tagline);
            var image2 = FindViewById<ImageView>(Resource.Id.logo2);
            image2.SetImageResource(Resource.Drawable.academia_cristo_w_tagline);
#endif

            var whatsappLoginButton = FindViewById<Button>(Resource.Id.login_whatsapp);
            var loginContainer = FindViewById<ConstraintLayout>(Resource.Id.login_container);
            var verifyContainer = FindViewById<ConstraintLayout>(Resource.Id.verify_container);
            var txtFullName = FindViewById<EditText>(Resource.Id.txtFullName);
            var txtWhatsAppNumber = FindViewById<EditText>(Resource.Id.txtWhatsAppNumber);
            var lblErrorRequired = FindViewById<TextView>(Resource.Id.lblErrorRequired);
            var ddlWhatsAppCountryCode = FindViewById<Spinner>(Resource.Id.ddlWhatsAppCountryCode);

            txtWhatsAppNumber.KeyPress += TxtWhatsAppNumber_KeyPress;
            txtWhatsAppNumber.EditorAction += TxtWhatsAppNumber_EditorAction;
            txtWhatsAppNumber.Text = App.DataHelper.WhatsAppNumberForLogin;

            var adapter = ArrayAdapter.CreateFromResource(this, Resource.Array.country_codes, Resource.Layout.spinner_item);
            adapter.SetDropDownViewResource(Resource.Layout.spinner_dropdown_item);
            ddlWhatsAppCountryCode.Adapter = adapter;

            whatsappLoginButton.Click += async delegate
            {
                App.HideKeyboard(this);

                // Get user-entered name and whatsapp number
                txtFullName.Text = txtFullName.Text.Trim();
                var fullName = txtFullName.Text;
                var countryCode = (string)ddlWhatsAppCountryCode.SelectedItem;
                var whatsAppNumber = txtWhatsAppNumber.Text;

                if (fullName.Length < 3 || whatsAppNumber.Length < 7 || string.IsNullOrEmpty(countryCode) || countryCode == "Country" || countryCode == "País")
                {
                    lblErrorRequired.Visibility = ViewStates.Visible;
                    return;
                }

                // Normalize the whatsapp number - remove all non-numeric chars and prefix with "+"
                whatsAppNumber = "+" + Regex.Replace(countryCode + whatsAppNumber, "[^0-9]", "");
                txtWhatsAppNumber.Text = whatsAppNumber;

                App.DataHelper.SendWhatsAppVerificationCode((await App.CurrentLanguage()).LanguageNodeID, whatsAppNumber);

                loginContainer.Visibility = Android.Views.ViewStates.Gone;
                verifyContainer.Visibility = Android.Views.ViewStates.Visible;
            };

            var btnVerifyCode = FindViewById<Button>(Resource.Id.btnVerifyCode);
            var txtVerificationCode = FindViewById<EditText>(Resource.Id.txtVerificationCode);
            txtVerificationCode.KeyPress += TxtWhatsAppNumber_KeyPress;
            txtVerificationCode.EditorAction += TxtWhatsAppNumber_EditorAction;
            var lblError = FindViewById<TextView>(Resource.Id.lblError);

            btnVerifyCode.Click += async delegate
            {
                App.HideKeyboard(this);
                lblError.Visibility = ViewStates.Gone;

                var code = txtVerificationCode.Text;

                // Attempt to login with this code as the password
                try
                {
                    await App.DataHelper.SetWhatsAppLogin(txtWhatsAppNumber.Text, (await App.CurrentLanguage()).LanguageNodeID, code);
                    App.CurrentAccount = await App.DataHelper.GetAccount((await App.CurrentLanguage()).LanguageNodeID, App.AccountSource, txtFullName.Text);
                    await App.DataHelper.LoadAccountDataFromAPI(App.CurrentAccount);
                    App.CurrentAccount.HasAuthenticated = true;
                    await App.DataHelper.SaveAccount(App.CurrentAccount);

                    // Store this for later
                    App.DataHelper.WhatsAppNumberForLogin = txtWhatsAppNumber.Text;
                    await App.NextActivity(this);
                }
                catch (System.Exception ex)
                {
                    lblError.Visibility = ViewStates.Visible;
                }
            };
        }

        private void TxtWhatsAppNumber_KeyPress(object sender, Android.Views.View.KeyEventArgs e)
        {
            if (e.Event.Action == KeyEventActions.Down && e.KeyCode == Keycode.Enter)
            {
                App.HideKeyboard(this);
            }
            else
            {
                e.Handled = false;
            }
        }

        private void TxtWhatsAppNumber_EditorAction(object sender, TextView.EditorActionEventArgs e)
        {
            if (e.ActionId == ImeAction.Done)
            {
                App.HideKeyboard(this);
            }
        }

        public override void OnBackPressed()
        {
            // prevent on back
        }
    }
}