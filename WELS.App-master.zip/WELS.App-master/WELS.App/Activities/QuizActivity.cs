﻿using Android.App;
using Android.Content;
using Android.Graphics;
using Android.OS;
using Android.Support.V7.App;
using Android.Views;
using Android.Widget;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WELS.App.Shared.Data;

namespace WELS.App
{
#if (ACADEMIACRISTO)
    [Activity(Label = "@string/app_name_es", Theme = "@style/AppTheme.NoActionBar", ConfigurationChanges = Android.Content.PM.ConfigChanges.Orientation | Android.Content.PM.ConfigChanges.ScreenSize)]
#else
    [Activity(Label = "@string/app_name", Theme = "@style/AppTheme.NoActionBar", ConfigurationChanges = Android.Content.PM.ConfigChanges.Orientation | Android.Content.PM.ConfigChanges.ScreenSize)]
#endif
    public class QuizActivity : AppCompatActivity
    {
        LinearLayout phQuizQuestion;
        LinearLayout phQuizBottom;
        TextView txtError, txtQuizGroup;
        private Course _course;
        private Lesson _lesson;
        private int? _currentQuestionIndex;
        private Question _currentQuestion;
        private List<RadioButton> _currentQuestionAnswerOptions;
        private EditText _currentQuestionEssayAnswer;
        private CheckBox _currentQuestionCheckbox;

        protected override void OnCreate(Bundle savedInstanceState)
        {
            base.OnCreate(savedInstanceState);

            // Create your application here
            SetContentView(Resource.Layout.activity_quiz);

            _course = App.Courses.FirstOrDefault(c => c.CourseNodeID == this.Intent.GetIntExtra("CourseNodeID", 0));
            _lesson = _course.Lessons.FirstOrDefault(c => c.LessonNodeID == this.Intent.GetIntExtra("LessonNodeID", 0));

            phQuizQuestion = FindViewById<LinearLayout>(Resource.Id.phQuizQuestion);
            phQuizBottom = FindViewById<LinearLayout>(Resource.Id.phQuizBottom);
            txtError = FindViewById<TextView>(Resource.Id.txtError);
            txtQuizGroup = FindViewById<TextView>(Resource.Id.txtQuizGroup);

            RunOnUiThread(async () =>
            {
                await NextQuestion();

                // HACK: Assume they watched the video if they started the quiz
                if (_lesson != null && _lesson.DateWatchedVideo == null)
                {
                    _lesson.DateWatchedVideo = DateTime.UtcNow;
                    await App.DataHelper.SaveData(_lesson, App.CurrentAccount);
                }
            });
        }

        private void BtnBack_Click(object sender, EventArgs e)
        {
            // TODO: Show "Confirmation" modal
            GoToCourseFragment();
        }

        private void GoToCourseFragment()
        {
            var args = new Bundle();
            args.PutInt("CourseNodeID", this.Intent.GetIntExtra("CourseNodeID", 0));

            FragmentManager.BeginTransaction().Replace(Resource.Id.frame_container, new CourseFragment() { Arguments = args }, "CourseFragmentTag").Commit();
        }

        private void GoToQuizEndFragment()
        {
            Intent intent = new Intent(this, typeof(CoursesActivity));

            intent.PutExtra("ShowQuizEnd", true);
            intent.PutExtra("CourseNodeID", this.Intent.GetIntExtra("CourseNodeID", 0));
            intent.PutExtra("LessonNodeID", this.Intent.GetIntExtra("LessonNodeID", 0));

            StartActivity(intent);
            Finish();
        }

        private async Task NextQuestion()
        {
            if (_currentQuestionIndex == null)
            {
                _currentQuestionIndex = 0;
            }
            else
            {
                _currentQuestionIndex = _currentQuestionIndex + 1;
            }

            // HACK: If there are no lessons in this course, don't crash.  Just mark the course completed and return.
            if (_lesson == null)
            {
                _course.DateCompleted = DateTime.UtcNow;
                await App.DataHelper.SaveData(_course, App.CurrentAccount);

                GoToQuizEndFragment();
            }
            // If we've reached the last question, save lesson completion dates and go back to the course fragment
            else if (_currentQuestionIndex >= _lesson.Questions.Count)
            {
                foreach (var item in _lesson.LessonItems)
                {
                    item.DateCompleted = DateTime.UtcNow;
                    await App.DataHelper.SaveData(item, App.CurrentAccount);
                }
                _lesson.DateCompletedAllLessonItems = DateTime.UtcNow;
                _lesson.DateCompletedQuiz = DateTime.UtcNow;
                await App.DataHelper.SaveData(_lesson, App.CurrentAccount);

                // If all lessons are complete, set completion date on this course
                if (!_course.Lessons.Any(l => l.DateCompletedAllLessonItems == null))
                {
                    _course.DateCompleted = DateTime.UtcNow;
                    await App.DataHelper.SaveData(_course, App.CurrentAccount);
                }

                GoToQuizEndFragment();
            }
            else
            {
                // Move on to the next question
                phQuizQuestion.RemoveViews(0, phQuizQuestion.ChildCount);
                phQuizBottom.RemoveViews(0, phQuizBottom.ChildCount);
                txtQuizGroup.Visibility = ViewStates.Gone;
                _currentQuestion = _lesson.Questions.Skip(_currentQuestionIndex.Value).FirstOrDefault();
                var txtQuestion = new TextView(this)
                {
                    Text = _currentQuestion.QuestionText,
                    TextSize = 15
                };
                txtQuestion.SetTextSize(Android.Util.ComplexUnitType.Sp, 15);
                txtQuestion.SetTypeface(txtQuestion.Typeface, TypefaceStyle.Bold);
                txtQuestion.SetTextColor(Color.ParseColor("#ff0b304b"));
                var l5 = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MatchParent, LinearLayout.LayoutParams.WrapContent);
                l5.SetMargins(0, App.DpToPixels(this, 16), 0, App.DpToPixels(this, 20));
                txtQuestion.LayoutParameters = l5;
                phQuizQuestion.AddView(txtQuestion);
                var quizGroups = new List<string>();
                if (_currentQuestion.IsEvaluate) quizGroups.Add(this.GetString(Resource.String.quiz_grouping_evaluate));
                if (_currentQuestion.IsLearn) quizGroups.Add(this.GetString(Resource.String.quiz_grouping_learn));
                if (quizGroups.Any())
                {
                    txtQuizGroup.Text = string.Join(" / ", quizGroups);
                    txtQuizGroup.Visibility = ViewStates.Visible;
                }
                switch (_currentQuestion.Type)
                {
                    case Constants.QuestionType.Essay:
                        _currentQuestionEssayAnswer = new EditText(this)
                        {
                            TextSize = 15,
                            Hint = this.GetString(Resource.String.quiz_textbox_hint)
                        };
                        var l1 = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MatchParent, 200);
                        _currentQuestionEssayAnswer.LayoutParameters = l1;
                        _currentQuestionEssayAnswer.Gravity = GravityFlags.Top;
                        _currentQuestionEssayAnswer.SetPadding(App.DpToPixels(this, 14), App.DpToPixels(this, 14), App.DpToPixels(this, 14), App.DpToPixels(this, 14));
                        _currentQuestionEssayAnswer.SetTextSize(Android.Util.ComplexUnitType.Sp, 15);
                        _currentQuestionEssayAnswer.SetBackgroundResource(Resource.Drawable.edittext_box);
                        phQuizQuestion.AddView(_currentQuestionEssayAnswer);
                        break;
                    case Constants.QuestionType.MultipleChoice:
                        var group = new RadioGroup(this);
                        var layout = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MatchParent, ViewGroup.LayoutParams.WrapContent);
                        group.LayoutParameters = layout;
                        _currentQuestionAnswerOptions = new List<RadioButton>();
                        char answerNumber = 'A';
                        foreach (var answer in _currentQuestion.Answers)
                        {
                            var rb = new RadioButton(this)
                            {
                                Text = answerNumber + ". " + answer.AnswerText,
                                Tag = answer.IsCorrectAnswer,
                                TextSize = 15
                            };
                            var l2 = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MatchParent, LinearLayout.LayoutParams.WrapContent);
                            l2.SetMargins(0, 0, 0, App.DpToPixels(this, 5));
                            rb.LayoutParameters = l2;
                            rb.SetPadding(App.DpToPixels(this, 5), App.DpToPixels(this, 5), App.DpToPixels(this, 5), App.DpToPixels(this, 5));
                            rb.SetTextSize(Android.Util.ComplexUnitType.Sp, 15);
                            _currentQuestionAnswerOptions.Add(rb);
                            group.AddView(rb);
                            answerNumber++;
                        }
                        phQuizQuestion.AddView(group);
                        break;
                    case Constants.QuestionType.Checkbox:
                        _currentQuestionCheckbox = new CheckBox(this)
                        {
                            TextSize = 15,
                            Text = _currentQuestion.CheckboxText
                        };
                        _currentQuestionCheckbox.SetTextSize(Android.Util.ComplexUnitType.Sp, 15);
                        phQuizQuestion.AddView(_currentQuestionCheckbox);
                        break;
                }

                var btnCheckAnswer = new Button(this)
                {
                    Text = _currentQuestion.Type == Constants.QuestionType.Checkbox ? this.GetString(Resource.String.quiz_continue) : this.GetString(Resource.String.quiz_check_answer)
                };
                var l3 = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MatchParent, LinearLayout.LayoutParams.WrapContent);
                btnCheckAnswer.LayoutParameters = l3;
                btnCheckAnswer.SetAllCaps(false);
                btnCheckAnswer.SetTextColor(Color.White);
                btnCheckAnswer.SetBackgroundColor(Color.ParseColor("#ff1c75bc"));
                btnCheckAnswer.SetTextSize(Android.Util.ComplexUnitType.Sp, 18);
                btnCheckAnswer.Click += BtnCheckAnswer_Click;
                phQuizBottom.SetPadding(0, 0, 0, 0);
                phQuizBottom.AddView(btnCheckAnswer);
            }
        }

        private void BtnCheckAnswer_Click(object sender, EventArgs e)
        {
            App.HideKeyboard(this);
            txtError.Visibility = ViewStates.Gone;

            switch (_currentQuestion.Type)
            {
                case Constants.QuestionType.MultipleChoice:
                    // check if answer is correct.  If not, highlight the correct answer.
                    var selected = _currentQuestionAnswerOptions.FirstOrDefault(o => o.Checked);
                    if (selected == null)
                    {
                        txtError.Text = this.GetString(Resource.String.quiz_no_answer_selected);
                        txtError.Visibility = ViewStates.Visible;
                        return;
                    }
                    phQuizBottom.RemoveViews(0, phQuizBottom.ChildCount);
                    phQuizBottom.SetPadding(App.DpToPixels(this, 15), App.DpToPixels(this, 15), App.DpToPixels(this, 15), App.DpToPixels(this, 15));
                    var correct = _currentQuestionAnswerOptions.FirstOrDefault(o => (bool)o.Tag == true);
                    // Check the "Tag" where we stored whether this is the correct answer
                    if ((bool)selected.Tag == true)
                    {
                        correct.SetBackgroundResource(Resource.Color.colorSuccessMuted);
                        phQuizBottom.SetBackgroundResource(Resource.Color.colorSuccess);
                        var txt = new TextView(this)
                        {
                            Text = this.GetString(Resource.String.quiz_correct)
                        };
                        var l1 = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MatchParent, LinearLayout.LayoutParams.WrapContent);
                        l1.SetMargins(0, 0, 0, App.DpToPixels(this, 5));
                        txt.LayoutParameters = l1;
                        txt.SetTextSize(Android.Util.ComplexUnitType.Sp, 18);
                        txt.SetTextColor(Color.White);
                        txt.SetTypeface(txt.Typeface, TypefaceStyle.Bold);
                        txt.TextAlignment = TextAlignment.Center;
                        phQuizBottom.AddView(txt);
                    }
                    else
                    {
                        selected.SetBackgroundResource(Resource.Color.colorGrayHighlight);
                        phQuizBottom.SetBackgroundResource(Resource.Color.colorHeavyGrayHighlight);
                        correct.SetBackgroundResource(Resource.Color.colorSuccessMuted);
                        var txt = new TextView(this)
                        {
                            Text = string.Format(this.GetString(Resource.String.quiz_incorrect), correct.Text[0])
                        };
                        var l1 = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MatchParent, LinearLayout.LayoutParams.WrapContent);
                        l1.SetMargins(0, 0, 0, App.DpToPixels(this, 5));
                        txt.LayoutParameters = l1;
                        txt.SetTextSize(Android.Util.ComplexUnitType.Sp, 18);
                        txt.SetTextColor(Color.White);
                        txt.SetTypeface(txt.Typeface, TypefaceStyle.Bold);
                        txt.TextAlignment = TextAlignment.Center;
                        phQuizBottom.AddView(txt);
                    }
                    break;
                case Constants.QuestionType.Essay:
                    phQuizBottom.RemoveViews(0, phQuizBottom.ChildCount);
                    phQuizBottom.SetPadding(App.DpToPixels(this, 15), App.DpToPixels(this, 15), App.DpToPixels(this, 15), App.DpToPixels(this, 15));
                    var l = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MatchParent, LinearLayout.LayoutParams.WrapContent);
                    l.SetMargins(0, 10, 0, 0);
                    var t = new TextView(this)
                    {
                        Text = this.GetString(Resource.String.quiz_your_answer),
                        TextSize = 15
                    };
                    t.SetTypeface(t.Typeface, TypefaceStyle.Bold);
                    t.SetTextColor(Color.ParseColor("#ff0b304b"));
                    t.SetPadding(0, App.DpToPixels(this, 15), 0, 0);
                    t.LayoutParameters = l;
                    phQuizQuestion.AddView(t);
                    var t2 = new TextView(this)
                    {
                        Text = _currentQuestionEssayAnswer.Text,
                        TextSize = 15
                    };
                    t2.SetTextColor(Color.ParseColor("#ff0b304b"));
                    phQuizQuestion.AddView(t2);
                    var t3 = new TextView(this)
                    {
                        Text = this.GetString(Resource.String.quiz_our_answer),
                        TextSize = 15
                    };
                    t3.SetTypeface(t.Typeface, TypefaceStyle.Bold);
                    t3.SetTextColor(Color.ParseColor("#ff0b304b"));
                    t3.SetPadding(0, App.DpToPixels(this, 20), 0, 0);
                    t3.LayoutParameters = l;
                    phQuizQuestion.AddView(t3);
                    var t4 = new TextView(this)
                    {
                        Text = _currentQuestion.TeacherAnswer,
                        TextSize = 15
                    };
                    t4.SetTextColor(Color.ParseColor("#ff0b304b"));
                    phQuizQuestion.AddView(t4);
                    _currentQuestionEssayAnswer.Visibility = ViewStates.Gone;
                    break;

                case Constants.QuestionType.Checkbox:
                    // Checkbox questions must simply be checked to move on.  If they do not check the box, show a message.
                    if (_currentQuestionCheckbox.Checked)
                    {
                        NextQuestion();
                    }
                    else
                    {
                        txtError.Text = this.GetString(Resource.String.quiz_check_the_box);
                        txtError.Visibility = ViewStates.Visible;
                    }
                    // No need for a continue button on a checkbox question - just return
                    return;
            }
            var btnContinue = new Button(this)
            {
                Text = this.GetString(Resource.String.quiz_continue),
                TextSize = 14
            };

            var l3 = new LinearLayout.LayoutParams(App.DpToPixels(this, 124), App.DpToPixels(this, 31));
            btnContinue.LayoutParameters = l3;
            btnContinue.SetTextColor(Color.ParseColor("#ff1c75bc"));
            btnContinue.SetBackgroundResource(Resource.Drawable.button_round);
            btnContinue.SetTextSize(Android.Util.ComplexUnitType.Sp, 14);
            btnContinue.SetAllCaps(true);
            btnContinue.SetPadding(0, 0, 0, 0);
            btnContinue.Click += delegate
            {
                NextQuestion();
            };
            phQuizBottom.AddView(btnContinue);
            phQuizBottom.RequestLayout();
        }

        /// <summary>
        /// Go back to course page.  TODO: Confirmation modal?
        /// </summary>
        public override void OnBackPressed()
        {
            base.OnBackPressed();
        }
    }
}