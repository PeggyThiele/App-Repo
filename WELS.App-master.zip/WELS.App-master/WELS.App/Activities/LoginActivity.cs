﻿using Android.App;
using Android.Content;
using Android.OS;
using Android.Widget;
using Java.Lang;
using Plugin.SecureStorage;
using ReactiveUI;
using System;
using System.Threading.Tasks;
using Xamarin.Facebook;
using Xamarin.Facebook.Login;

namespace WELS.App
{
    public class OnProfileChangedEventArgs : EventArgs
    {
        public Profile mProfile;

        public OnProfileChangedEventArgs(Profile profile) { mProfile = profile; }
    }
    public class MyProfileTracker : ProfileTracker //Listener for profile
    {
        public event EventHandler<OnProfileChangedEventArgs> mOnProfileChanged;
        protected override void OnCurrentProfileChanged(Profile oldProfile, Profile currentProfile)
        {
            if (mOnProfileChanged != null)
            {
                mOnProfileChanged.Invoke(this, new OnProfileChangedEventArgs(currentProfile));
            }
        }
    }

    [Activity(Label = "LoginActivity")]
    public class LoginActivity : Activity, IFacebookCallback
    {
        private static string EMAIL = "email";
        private static string AUTH_TYPE = "rerequest";
        private ICallbackManager callbackManager { get; set; }

        private long uiThreadId = Thread.CurrentThread().Id;
        private Handler handler = new Handler();

        internal static ProfileTracker tracker = new MyProfileTracker();

        public void OnCancel()
        {
            SetResult(Result.Canceled);
            // Finish();
        }

        public void OnError(FacebookException error)
        {
            // handle exception
            var e = error;
        }

        LoginResult loginResult;
        public void OnSuccess(Java.Lang.Object result)
        {
            loginResult = (LoginResult)result;

            App.ShowLoadingActivity(this);

            SetResult(Result.Ok);
        }

        protected override void OnActivityResult(int requestCode, Result resultCode, Intent data)
        {
            callbackManager.OnActivityResult(requestCode, (int)resultCode, data);
            base.OnActivityResult(requestCode, resultCode, data);
        }

        protected override void OnCreate(Bundle savedInstanceState)
        {
            base.OnCreate(savedInstanceState);

            // Create your application here
            SetContentView(Resource.Layout.activity_login);
            callbackManager = CallbackManagerFactory.Create();

#if (ACADEMIACRISTO)
            var image = FindViewById<ImageView>(Resource.Id.logo);
            image.SetImageResource(Resource.Drawable.academia_cristo_w_tagline);
#endif

            var loginButton = FindViewById<Button>(Resource.Id.login_button);

            LoginManager.Instance.RegisterCallback(callbackManager, this);
            loginButton.Click += delegate
            {
                LoginManager.Instance.LogInWithReadPermissions(this, new string[] { EMAIL });
            };

            var whatsappLoginButton = FindViewById<Button>(Resource.Id.login_whatsapp);
            whatsappLoginButton.Click += delegate
            {
                App.ProfileTracker.mOnProfileChanged -= OnProfileChanged;
                Intent intent = new Intent(this, typeof(WhatsAppLoginActivity));
                this.StartActivity(intent);
            };

            App.ProfileTracker.mOnProfileChanged += OnProfileChanged;
            App.ProfileTracker.StartTracking();
        }

        public async void OnProfileChanged(object sender, OnProfileChangedEventArgs e)
        {
            if (e.mProfile == null)
                return;

            var count = 0;
            while (loginResult == null && count <= 20)
            {
                Thread.Sleep(500);
                count++;
            }
            // If we waited 10 seconds and we still never got our login result, attempt to go to the next activity
            if (loginResult == null)
                await App.NextActivity(this);

            await App.DataHelper.SetFacebookLogin(loginResult.AccessToken.UserId, loginResult.AccessToken.Token, FacebookSdk.ApplicationId);
            App.CurrentAccount = await App.DataHelper.GetAccount((await App.CurrentLanguage()).LanguageNodeID, App.AccountSource, e.mProfile.Name, e.mProfile.GetProfilePictureUri(68, 68).ToString());
            await App.DataHelper.LoadAccountDataFromAPI(App.CurrentAccount);
            App.CurrentAccount.Name = Profile.CurrentProfile.Name;
            App.CurrentAccount.FacebookProfileImageURL = Profile.CurrentProfile.GetProfilePictureUri(68, 68).ToString();
#if (ACADEMIACRISTO)
            App.CurrentAccount.Source = this.GetString(Resource.String.account_source_es);
#else
            App.CurrentAccount.Source = this.GetString(Resource.String.account_source);
#endif
            App.CurrentAccount.HasAuthenticated = true;

            await App.DataHelper.SaveAccount(App.CurrentAccount);


            App.RefreshPushNotificationTags();


            await App.NextActivity(this);

            App.ProfileTracker.mOnProfileChanged -= OnProfileChanged;

            Finish();
        }

        public override void OnBackPressed()
        {
            // prevent on back
        }
    }
}