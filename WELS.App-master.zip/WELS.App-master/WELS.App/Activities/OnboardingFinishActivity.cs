﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Android.Animation;
using Android.App;
using Android.Content;
using Android.Graphics;
using Android.OS;
using Android.Runtime;
using Android.Support.Constraints;
using Android.Support.Design.Widget;
using Android.Support.V4.Widget;
using Android.Views;
using Android.Webkit;
using Android.Widget;
using WELS.App.Extensions;
using WELS.App.Shared.Helpers;

namespace WELS.App
{
    [Activity(Label = "OnboardingFinishActivity")]
    public class OnboardingFinishActivity : Activity
    {
        public RelativeLayout RelativeLayout { get; set; }
        public ConstraintLayout ContentLayout { get; set; }
        public WebView webVideoPlayer { get; set; }

        protected async override void OnCreate(Bundle savedInstanceState)
        {
            base.OnCreate(savedInstanceState);

            // Since we're now skipping the on-boarding questions, set the score to 99, so we can easily
            // query all accounts that in fact skipped the questions
            App.CurrentAccount.OnBoardingTotalScore = 99;
            await App.DataHelper.SaveAccount(App.CurrentAccount);

            // HACK: Reset the locale after loading the webview:  https://stackoverflow.com/questions/40398528/android-webview-language-changes-abruptly-on-android-7-0-and-above
            // Force English for TELL, Spanish for Academia Cristo
#if (ACADEMIACRISTO)
            App.ChangeLocale(this, "es_MX");
#else
            App.ChangeLocale(this, "en_US");
#endif

            // Create your application here
            SetContentView(Resource.Layout.activity_onboarding_finish);

            ContentLayout = FindViewById<ConstraintLayout>(Resource.Id.contentLayout);
            RelativeLayout = FindViewById<RelativeLayout>(Resource.Id.relativeLayout);

#if (ACADEMIACRISTO)
            var image = FindViewById<ImageView>(Resource.Id.logo);
            image.SetImageResource(Resource.Drawable.academia_cristo_w_tagline);
#endif

            var progress = FindViewById<ProgressBar>(Resource.Id.progress);

            var animator = ValueAnimator.OfInt(0, 100);
            animator.SetDuration(1000);
            animator.Update += (object sender, ValueAnimator.AnimatorUpdateEventArgs e) =>
            {
                progress.Progress = (int)e.Animation.AnimatedValue;
            };
            animator.Start();

            var onboarding = await App.DataHelper.GetOnboarding(App.CurrentAccount.LanguageNodeID ?? 0);
            var sortedVideos = onboarding.Videos.Where(v => App.CurrentAccount.OnBoardingTotalScore >= v.MinimumScore).OrderBy(v => v.MinimumScore);
            var video = sortedVideos.FirstOrDefault();

            // If there are no videos, complete onboarding and move on
            if (video == null || string.IsNullOrWhiteSpace(video.VideoURL))
            {
                App.CurrentAccount.DateCompletedOnboarding = DateTime.UtcNow;
                await App.DataHelper.SaveAccount(App.CurrentAccount);
                await App.NextActivity(this);
                Finish();
                return;
            }
            
            webVideoPlayer = new WebView(this);
            webVideoPlayer.Settings.JavaScriptEnabled = true;
            webVideoPlayer.SetWebChromeClient(new FullScreenWebChromeClient(this, this.RelativeLayout, this.ContentLayout));
            var youtubeID = VideoHelper.ParseYouTubeID(video.VideoURL);
            webVideoPlayer.LoadData($"<html><body style=\"padding: 0; margin: 0\"><iframe width=\"100%\" height=\"100%\" src=\"https://www.youtube-nocookie.com/embed/{youtubeID}?modestbranding=1\" frameborder=\"0\" allow=\"accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture\" allowfullscreen></iframe></body></html>", "text/html", "utf-8");
            var layout = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MatchParent, LinearLayout.LayoutParams.MatchParent);
            layout.SetMargins(0, 0, 0, 0);
            webVideoPlayer.LayoutParameters = layout;
            this.FindViewById<LinearLayout>(Resource.Id.video_container).AddView(webVideoPlayer);

            var next = FindViewById<Button>(Resource.Id.next);
            next.Click += async delegate
            {
                App.CurrentAccount.DateCompletedOnboarding = DateTime.UtcNow;
                await App.DataHelper.SaveAccount(App.CurrentAccount);
                await App.NextActivity(this);
                Finish();
            };
        }

        public override void OnBackPressed()
        {
            // base.OnBackPressed();
        }


        protected async override void OnPause()
        {
            if (webVideoPlayer != null)
            {
                webVideoPlayer.OnPause();
                webVideoPlayer.PauseTimers();
            }
            base.OnPause();
        }

        protected async override void OnResume()
        {
            if (webVideoPlayer != null)
            {
                webVideoPlayer.OnResume();
                webVideoPlayer.ResumeTimers();
            }
            base.OnPause();
        }
        protected async override void OnDestroy()
        {
            if (webVideoPlayer != null)
            {
                webVideoPlayer.Destroy();
                webVideoPlayer = null;
            }
            base.OnPause();
        }
    }
}