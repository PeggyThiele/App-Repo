﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.Gms.Common;
using Android.OS;
using Android.Runtime;
using Android.Util;
using Android.Views;
using Android.Widget;
using Xamarin.Facebook;

namespace WELS.App.Activities
{
    /// <summary>
    /// This is the Main Launcher activity.  The layout is a simple splash screen.  The logic here is to simply determine what the next activity 
    /// should be.  Ensure NoHistory is true, so we cannot return to this activity.
    /// </summary>
#if (ACADEMIACRISTO)
    [Activity(Label = "@string/app_name_es", Icon = "@drawable/app_icon_es", MainLauncher = true, NoHistory = true)]
#else
    [Activity(Label = "@string/app_name", Icon = "@drawable/app_icon", MainLauncher = true, NoHistory = true)]
#endif
    public class LoadingActivity : Activity
    {
        protected override void OnCreate(Bundle savedInstanceState)
        {
            base.OnCreate(savedInstanceState);

            SetContentView(Resource.Layout.activity_loading);

            // Force English for TELL, Spanish for Academia Cristo
#if (ACADEMIACRISTO)
            App.ChangeLocale(this, "es_MX");
#else
            App.ChangeLocale(this, "en_US");
#endif

            var skipNextActivity = this.Intent.GetBooleanExtra("SkipNextActivity", false);

            Xamarin.Essentials.Platform.Init(this, savedInstanceState);

            // Ask to allow push notifications
            // See:  https://docs.microsoft.com/en-us/azure/notification-hubs/xamarin-notification-hubs-push-notifications-android-gcm
            if (Intent.Extras != null)
            {
                foreach (var key in Intent.Extras.KeySet())
                {
                    if (key != null)
                    {
                        var value = Intent.Extras.GetString(key);
                        Log.Debug("LoadingActivity", "Key: {0} Value: {1}", key, value);
                    }
                }
            }

            IsPlayServicesAvailable();
            CreateNotificationChannel();

            RunOnUiThread(async () =>
            {
                //try
                //{
                    // We ONLY want to execute NextActivity during the initial app start splash
                    if (!skipNextActivity)
                    {
                        await App.NextActivity(this);
                        Finish();
                    }
                //}
                //catch (Exception ex)
                //{
                //    Android.App.AlertDialog.Builder dialog = new AlertDialog.Builder(this);
                //    AlertDialog alert = dialog.Create();
                //    alert.SetTitle(this.GetString(Resource.String.error_internet_title));
                //    alert.SetMessage(this.GetString(Resource.String.error_internet_description));
                //    alert.SetButton(this.GetString(Resource.String.error_internet_retry), async (c, ev) =>
                //    {
                //        await App.NextActivity(this);
                //    });
                //    alert.Show();
                //}
            });
        }


        public bool IsPlayServicesAvailable()
        {
            int resultCode = GoogleApiAvailability.Instance.IsGooglePlayServicesAvailable(this);
            if (resultCode != ConnectionResult.Success)
            {
                if (GoogleApiAvailability.Instance.IsUserResolvableError(resultCode))
                    Log.Debug("LoadingActivity", GoogleApiAvailability.Instance.GetErrorString(resultCode));
                else
                {
                    Log.Debug("LoadingActivity", "This device is not supported");
                    Finish();
                }
                return false;
            }

            Log.Debug("LoadingActivity", "Google Play Services is available.");
            return true;
        }

        private void CreateNotificationChannel()
        {
            if (Build.VERSION.SdkInt < BuildVersionCodes.O)
            {
                // Notification channels are new in API 26 (and not a part of the
                // support library). There is no need to create a notification
                // channel on older versions of Android.
                return;
            }

            var channelDescription = string.Empty;
            var channel = new NotificationChannel(App.NotificationChannel, App.NotificationChannel, NotificationImportance.Default)
            {
                Description = channelDescription
            };

            var notificationManager = (NotificationManager)GetSystemService(NotificationService);
            notificationManager.CreateNotificationChannel(channel);
        }

        /// <summary>
        /// Prevent anything from occurring during back button press while this activity is focused
        /// </summary>
        public override void OnBackPressed() { }
        public byte[] ReadAllBytes(Stream instream)
        {
            if (instream is MemoryStream)
                return ((MemoryStream)instream).ToArray();

            using (var memoryStream = new MemoryStream())
            {
                instream.CopyTo(memoryStream);
                return memoryStream.ToArray();
            }
        }
    }
}