﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Util;
using Android.Views;
using Android.Widget;
using WELS.App.Helpers;
using WELS.App.Shared.Interfaces;
using WELS.App.Shared.Models.Response;

namespace WELS.App
{
    public class OnboardingCardFragment : Fragment
    {
        private OnboardingQuestionResponse _question { get; set; }

        public interface Listener
        {
            void OnQuestionYesClick(int score);
            void OnQuestionNoClick(int score);
        }

        public override void OnCreate(Bundle savedInstanceState)
        {
            base.OnCreate(savedInstanceState);

            // Create your fragment here
        }

        public override View OnCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
        {
            var view = inflater.Inflate(Resource.Layout.fragment_onboarding_card, container, false);

            for (int btnIndex = 0; btnIndex <= 3; btnIndex++)
            {
                var btn = view.FindViewById<Button>(AppHelper.GetResourceID("button" + (btnIndex + 1)));
                var answer = _question.Answers.Skip(btnIndex).FirstOrDefault();
                if (answer != null)
                {
                    btn.Text = answer.AnswerText;
                    btn.Click += delegate
                    {
                        ((Listener)Activity).OnQuestionYesClick(answer.Score);
                    };
                }
                else
                {
                    btn.Visibility = ViewStates.Gone;
                }
            }
            var text = view.FindViewById<TextView>(Resource.Id.card_text);
            text.Text = _question.QuestionText;

            return view;
        }

        public void PassQuestion(OnboardingQuestionResponse question)
        {
            _question = question;
        }
    }
}