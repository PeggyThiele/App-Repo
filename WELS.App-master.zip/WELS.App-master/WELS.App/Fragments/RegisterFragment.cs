﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using Org.Apache.Http.Client.Params;
using WELS.App.Shared.Data;

namespace WELS.App.Fragments
{
    class RegisterFragment : Fragment
    {
        LinearLayout layoutForm, layoutThankYou;
        EditText txtFullName, txtCity, txtCountry, txtFacebookUsername, txtWhatsAppNumber, txtFinishedBeginnerCourses, txtLocalChurch, txtTELLTraining, txtComments;
        TextView lblValidation, txtRegisterMessage;
        Button btnSubmit;

        public override void OnCreate(Bundle savedInstanceState)
        {
            base.OnCreate(savedInstanceState);
        }

        public override View OnCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
        {
            var view = inflater.Inflate(Resource.Layout.fragment_register, container, false);

            layoutForm = view.FindViewById<LinearLayout>(Resource.Id.layoutForm);
            layoutThankYou = view.FindViewById<LinearLayout>(Resource.Id.layoutThankYou);

            txtFullName = view.FindViewById<EditText>(Resource.Id.txtFullName);
            txtCity = view.FindViewById<EditText>(Resource.Id.txtCity);
            txtCountry = view.FindViewById<EditText>(Resource.Id.txtCountry);
            txtFacebookUsername = view.FindViewById<EditText>(Resource.Id.txtFacebookUsername);
            txtWhatsAppNumber = view.FindViewById<EditText>(Resource.Id.txtWhatsAppNumber);
            txtFinishedBeginnerCourses = view.FindViewById<EditText>(Resource.Id.txtFinishedBeginnerCourses);
            txtLocalChurch = view.FindViewById<EditText>(Resource.Id.txtLocalChurch);
            txtTELLTraining = view.FindViewById<EditText>(Resource.Id.txtTELLTraining);
            txtComments = view.FindViewById<EditText>(Resource.Id.txtComments);

            lblValidation = view.FindViewById<TextView>(Resource.Id.lblValidation);
            btnSubmit = view.FindViewById<Button>(Resource.Id.btnSubmit);

            txtFullName.Text = App.CurrentAccount.Name;

            btnSubmit.Click += BtnSubmit_Click;

            // Reload copy that needs some formatting
            txtRegisterMessage = view.FindViewById<TextView>(Resource.Id.txtRegisterMessage);
            txtRegisterMessage.Text = string.Format(this.GetString(Resource.String.register_message), App.CurrentAccount.Name);

            return view;
        }

        private async void BtnSubmit_Click(object sender, EventArgs e)
        {
            // Validate all required fields
            if (string.IsNullOrWhiteSpace(txtFullName.Text))
            {
                lblValidation.Text = this.GetString(Resource.String.register_v_fullname);
                lblValidation.Visibility = ViewStates.Visible;
                App.ScrollToTop((CoursesActivity)this.Activity);
                return;
            }
            if (string.IsNullOrWhiteSpace(txtCity.Text))
            {
                lblValidation.Text = this.GetString(Resource.String.register_v_city);
                lblValidation.Visibility = ViewStates.Visible;
                App.ScrollToTop((CoursesActivity)this.Activity);
                return;
            }
            if (string.IsNullOrWhiteSpace(txtCountry.Text))
            {
                lblValidation.Text = this.GetString(Resource.String.register_v_country);
                lblValidation.Visibility = ViewStates.Visible;
                App.ScrollToTop((CoursesActivity)this.Activity);
                return;
            }
            if (string.IsNullOrWhiteSpace(txtFacebookUsername.Text))
            {
                lblValidation.Text = this.GetString(Resource.String.register_v_facebook_username);
                lblValidation.Visibility = ViewStates.Visible;
                App.ScrollToTop((CoursesActivity)this.Activity);
                return;
            }
            if (string.IsNullOrWhiteSpace(txtFinishedBeginnerCourses.Text))
            {
                lblValidation.Text = this.GetString(Resource.String.register_v_finished_beginner_courses);
                lblValidation.Visibility = ViewStates.Visible;
                App.ScrollToTop((CoursesActivity)this.Activity);
                return;
            }
            if (string.IsNullOrWhiteSpace(txtLocalChurch.Text))
            {
                lblValidation.Text = this.GetString(Resource.String.register_v_local_church);
                lblValidation.Visibility = ViewStates.Visible;
                App.ScrollToTop((CoursesActivity)this.Activity);
                return;
            }
            if (string.IsNullOrWhiteSpace(txtTELLTraining.Text))
            {
                lblValidation.Text = this.GetString(Resource.String.register_v_tell_training);
                lblValidation.Visibility = ViewStates.Visible;
                App.ScrollToTop((CoursesActivity)this.Activity);
                return;
            }

            var postTo = this.GetString(Resource.String.register_post_url);
            var source = this.GetString(Resource.String.register_source);

            var parms = new Dictionary<string, string>();
            parms.Add("Name", txtFullName.Text);
            parms.Add("City", txtCity.Text);
            parms.Add("Country", txtCountry.Text);
            parms.Add("FacebookUserName", txtFacebookUsername.Text);
            parms.Add("WhatsAppNum", txtWhatsAppNumber.Text);
            parms.Add("CoursesCompleted", txtFinishedBeginnerCourses.Text);
            parms.Add("Local", txtLocalChurch.Text);
            parms.Add("Training", txtTELLTraining.Text);
            parms.Add("MoreInfo", txtComments.Text);
            parms.Add("Source", source);

            var request = new HttpRequestMessage(System.Net.Http.HttpMethod.Post, postTo) { Content = new FormUrlEncodedContent(parms) };

            var client = new HttpClient();
            await client.SendAsync(request);

            layoutForm.Visibility = ViewStates.Gone;
            layoutThankYou.Visibility = ViewStates.Visible;
        }
    }
}