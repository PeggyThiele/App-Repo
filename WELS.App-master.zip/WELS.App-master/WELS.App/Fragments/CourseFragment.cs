﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Util;
using Android.Views;
using Android.Webkit;
using Android.Widget;
using WELS.App.Adapters;
using WELS.App.Extensions;
using WELS.App.Fragments;
using WELS.App.Helpers;
using WELS.App.Shared.Data;
using WELS.App.Shared.Helpers;
using WELS.App.Shared.Models.Response;

namespace WELS.App
{
    public class CourseFragment : Fragment
    {
        TextView txtCourseNumber, txtCourseName, txtLessonCount, txtCourseDescription;
        ListView lstNextLessons, lstCompletedLessons;
        LinearLayout UpNextLayout, CompletedLayout;
        Button btnTakeTheQuiz;
        Lesson CurrentLesson;
        
        public LinearLayout ContentLayout { get; set; }
        public LinearLayout TextLayout { get; set; }
        public LinearLayout VideoLayout { get; set; }
        public TextView txtLessonNumber { get; set; }
        public TextView txtLessonName { get; set; }
        public TextView txtText { get; set; }
        public WebView webVideoPlayer { get; set; }

        int _currentLessonNodeID;

        public override void OnCreate(Bundle savedInstanceState)
        {
            base.OnCreate(savedInstanceState);
        }

        public override View OnCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
        {
            var view = inflater.Inflate(Resource.Layout.fragment_course, container, false);

            // HACK: Reset the locale after loading the webview:  https://stackoverflow.com/questions/40398528/android-webview-language-changes-abruptly-on-android-7-0-and-above
            // Force English for TELL, Spanish for Academia Cristo
#if (ACADEMIACRISTO)
            App.ChangeLocale(this.Activity, "es_MX");
#else
            App.ChangeLocale(this.Activity, "en_US");
#endif

            var course = App.Courses.FirstOrDefault(c => c.CourseNodeID == this.Arguments.GetInt("CourseNodeID"));

            // If this course is already completed, go back to courses landing
            //if (course.DateCompleted != null)
            //{
            //    App.ScrollToTop((CoursesActivity)this.Activity);
            //    this.Activity.FragmentManager.BeginTransaction().Replace(Resource.Id.frame_container, new CoursesFragment()).Commit();
            //}

            ContentLayout = view.FindViewById<LinearLayout>(Resource.Id.contentLayout);

            txtCourseNumber = view.FindViewById<TextView>(Resource.Id.txtCourseNumber);
            txtCourseNumber.Text = string.Format(this.GetString(Resource.String.course_page_course_number), course.SortOrder);

            txtCourseName = view.FindViewById<TextView>(Resource.Id.txtCourseName);
            txtCourseName.Text = course.Name;

            txtLessonCount = view.FindViewById<TextView>(Resource.Id.txtLessonCount);
            txtLessonCount.Text = string.Format(this.GetString(Resource.String.course_page_lesson_count_and_timing), course.Lessons.Count, course.EstimatedDuration);

            txtCourseDescription = view.FindViewById<TextView>(Resource.Id.txtCourseDescription);
            txtCourseDescription.Text = course.Description;

            btnTakeTheQuiz = view.FindViewById<Button>(Resource.Id.btnTakeTheQuiz);
            btnTakeTheQuiz.Click += BtnTakeTheQuiz_Click;

            var incomplete = course.Lessons.Where(c => c.DateCompletedAllLessonItems == null).OrderBy(c => c.SortOrder).ToList();
            var complete = course.Lessons.Where(c => c.DateCompletedAllLessonItems != null).OrderBy(c => c.SortOrder).ToList();
            UpNextLayout = view.FindViewById<LinearLayout>(Resource.Id.UpNextLayout);
            CompletedLayout = view.FindViewById<LinearLayout>(Resource.Id.CompletedLayout);
            lstNextLessons = view.FindViewById<ListView>(Resource.Id.lstNextLessons);
            lstCompletedLessons = view.FindViewById<ListView>(Resource.Id.lstCompletedLessons);
            
            Activity.RunOnUiThread(async () =>
            {
                if (course.DateStarted == null)
                {
                    course.DateStarted = DateTime.UtcNow;
                    await App.DataHelper.SaveData(course, App.CurrentAccount);
                }

                if (incomplete.Any())
                {
                    var lesson = incomplete.FirstOrDefault();
                    if (lesson.DateStarted == null)
                    {
                        lesson.DateStarted = DateTime.UtcNow;
                        await App.DataHelper.SaveData(lesson, App.CurrentAccount);
                    }
                }
            });

            UpNextLayout.Visibility = ViewStates.Gone;
            CompletedLayout.Visibility = ViewStates.Gone;

            // If a specific lesson ID was requested, show that lesson instead of the next lesson
            if (this.Arguments.ContainsKey("LessonNodeID"))
            {
                CurrentLesson = course.Lessons.FirstOrDefault(l => l.LessonNodeID == this.Arguments.GetInt("LessonNodeID") && l.DateCompletedAllLessonItems != null);
                btnTakeTheQuiz.Visibility = ViewStates.Gone;
            }
            if (CurrentLesson == null)
            {
                CurrentLesson = incomplete.FirstOrDefault();
            }
            if (CurrentLesson != null)
            {
                LoadCurrentLesson(view, course, CurrentLesson);

                _currentLessonNodeID = CurrentLesson.LessonNodeID;
                if (incomplete.Count > 1)
                {
                    lstNextLessons.Adapter = new LessonListAdapter(Activity, course, incomplete.Skip(1), false);
                    AppHelper.SetListHeightToChildren(lstNextLessons);
                    UpNextLayout.Visibility = ViewStates.Visible;
                }
            }
            else
            {
                btnTakeTheQuiz.Visibility = ViewStates.Gone;
                view.FindViewById<LinearLayout>(Resource.Id.VideoLayout).Visibility = ViewStates.Gone;
            }
            if (complete.Any())
            {
                lstCompletedLessons.Adapter = new LessonListAdapter(Activity, course, complete, true);
                AppHelper.SetListHeightToChildren(lstCompletedLessons);
                CompletedLayout.Visibility = ViewStates.Visible;
            }

            Activity.RunOnUiThread(() =>
            {
                App.ScrollToTop((CoursesActivity)this.Activity);
            });

            return view;
        }

        private void BtnTakeTheQuiz_Click(object sender, EventArgs e)
        {
            var args = new Bundle();
            args.PutInt("CourseNodeID", this.Arguments.GetInt("CourseNodeID"));
            args.PutInt("LessonNodeID", _currentLessonNodeID);

            Intent intent = new Intent(this.Activity, typeof(QuizActivity));

            intent.PutExtra("CourseNodeID", this.Arguments.GetInt("CourseNodeID"));
            intent.PutExtra("LessonNodeID", _currentLessonNodeID);

            StartActivity(intent);
        }

        public override void OnPause()
        {
            if (webVideoPlayer != null)
            {
                webVideoPlayer.OnPause();
            }
            base.OnPause();
        }
        public override void OnResume()
        {
            if (webVideoPlayer != null)
            {
                webVideoPlayer.OnResume();
                webVideoPlayer.ResumeTimers();
            }
            base.OnResume();
        }
        public override void OnDestroy()
        {
            if (webVideoPlayer != null)
            {
                webVideoPlayer.Destroy();
                webVideoPlayer = null;
            }
            base.OnDestroy();
        }

        private void LoadCurrentLesson(View view, Course course, Lesson lesson)
        {
            var lessonItems = lesson.LessonItems;
            // if any Video items, re-sort Lesson Items, so that the first video is moved to the beginning
            if (lessonItems.Any(i => i.Type == Constants.LessonItemType.Video))
            {
                lessonItems = lessonItems.OrderBy(i => i.SortOrder == lessonItems.FirstOrDefault(ii => ii.Type == Constants.LessonItemType.Video).SortOrder ? 0 : 1).ThenBy(i => i.SortOrder).ToList();
            }
            
            TextLayout = view.FindViewById<LinearLayout>(Resource.Id.TextLayout);
            VideoLayout = view.FindViewById<LinearLayout>(Resource.Id.VideoLayout);
            txtLessonNumber = view.FindViewById<TextView>(Resource.Id.txtLessonNumber);
            txtLessonName = view.FindViewById<TextView>(Resource.Id.txtLessonName);
            txtText = view.FindViewById<TextView>(Resource.Id.txtText);
            txtText.Text = "";

            foreach (var lessonItem in lessonItems)
            {
                if (lessonItem.Type == Constants.LessonItemType.Video)
                {
                    webVideoPlayer = new WebView(this.Activity);
                    VideoLayout.Visibility = ViewStates.Visible;
                    webVideoPlayer.Settings.JavaScriptEnabled = true;
                    var parentActivity = ((CoursesActivity)this.Activity);
                    webVideoPlayer.SetWebChromeClient(new FullScreenWebChromeClient(parentActivity, parentActivity.Drawer, parentActivity.ContentLayout, parentActivity.Navigation));
                    var youtubeID = VideoHelper.ParseYouTubeID(lessonItem.VideoURL);
                    webVideoPlayer.LoadData($"<html><body style=\"padding: 0; margin: 0\"><iframe width=\"100%\" height=\"100%\" src=\"https://www.youtube-nocookie.com/embed/{youtubeID}?modestbranding=1\" frameborder=\"0\" allow=\"accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture\" allowfullscreen></iframe></body></html>", "text/html", "utf-8");
                    var layout = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MatchParent, LinearLayout.LayoutParams.MatchParent);
                    layout.SetMargins(0, 0, 0, 0);
                    webVideoPlayer.LayoutParameters = layout;

                    view.FindViewById<LinearLayout>(Resource.Id.VideoLayout).AddView(webVideoPlayer);
                }
                else if (lessonItem.Type == Constants.LessonItemType.Text)
                {
                    // if this is the first text item, include lesson number and name
                    if (lessonItem.SortOrder == lessonItems.FirstOrDefault(i => i.Type == Constants.LessonItemType.Text).SortOrder)
                    {
                        txtLessonNumber.Text = course.Name;
                        txtLessonName.Text = lesson.Name;
                    }
                    TextLayout.Visibility = ViewStates.Visible;
                    txtText.Text += lessonItem.Text;
                }
            }
            // HACK: Reset the locale after loading the webview:  https://stackoverflow.com/questions/40398528/android-webview-language-changes-abruptly-on-android-7-0-and-above
            // Force English for TELL, Spanish for Academia Cristo
#if (ACADEMIACRISTO)
            App.ChangeLocale(this.Activity, "es_MX");
#else
            App.ChangeLocale(this.Activity, "en_US");
#endif
        }
    }
}