﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Util;
using Android.Views;
using Android.Widget;
using WELS.App.Fragments;
using WELS.App.Helpers;
using WELS.App.Shared.Data;
using WELS.App.Shared.Models.Response;

namespace WELS.App
{
    public class CoursesFragment : Fragment
    {
        public LinearLayout NextCourse { get; set; }
        public LinearLayout NextCoursesList { get; set; }
        public LinearLayout CompletedCoursesList { get; set; }
        public TextView lblUpNext { get; set; }
        public TextView lblCompleted { get; set; }
        public Button btnReset { get; set; }

        public override void OnCreate(Bundle savedInstanceState)
        {
            base.OnCreate(savedInstanceState);
        }

        public override View OnCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
        {
            Activity.RunOnUiThread(async () =>
            {
                // If we've completed all courses, set date completed all courses and redirect to the Course End fragment
                // However, if this account hasn't authenticated yet, assume they are not truly done with all courses
                if (!App.PreventRedirectToSignup && App.CurrentAccount.HasAuthenticated)
                {
                    if (!App.Courses.Any(c => c.DateCompleted == null))
                    {
                        if (App.CurrentAccount.DateCompletedAllCourses == null)
                        {
                            App.CurrentAccount.DateCompletedAllCourses = DateTime.UtcNow;
                            await App.DataHelper.SaveAccount(App.CurrentAccount);
                        }
                        FragmentManager.BeginTransaction().Replace(Resource.Id.frame_container, new CoursesEndFragment()).Commit();
                        App.ScrollToTop((CoursesActivity)this.Activity);
                    }
                }
            });

            var view = inflater.Inflate(Resource.Layout.fragment_courses, container, false);

            NextCourse = view.FindViewById<LinearLayout>(Resource.Id.nextCourse);
            NextCoursesList = view.FindViewById<LinearLayout>(Resource.Id.nextCoursesList);
            CompletedCoursesList = view.FindViewById<LinearLayout>(Resource.Id.completedCoursesList);
            lblUpNext = view.FindViewById<TextView>(Resource.Id.lblUpNext);
            lblCompleted = view.FindViewById<TextView>(Resource.Id.lblCompleted);

#if (DEBUG)
            btnReset = view.FindViewById<Button>(Resource.Id.btnReset);
            btnReset.Visibility = ViewStates.Visible;
            btnReset.Click += delegate
            {
                Activity.RunOnUiThread(async () =>
                {
                    await App.DataHelper.ResetStatuses();
                    App.ReloadCoursesFromDB();

                    App.ScrollToTop((CoursesActivity)this.Activity);
                    FragmentManager.BeginTransaction().Replace(Resource.Id.frame_container, new CoursesFragment()).Commit();
                });
            };
#endif

            try
            {
                Activity.RunOnUiThread(() =>
                {
                    // Organize course list into "Current", "Next", and "Completed" sections
                    var incomplete = App.Courses.Where(c => c.DateCompleted == null).OrderBy(c => c.SortOrder).ToList();
                    var complete = App.Courses.Where(c => c.DateCompleted != null).OrderBy(c => c.SortOrder).ToList();
                    if (incomplete.Any())
                    {
                        NextCourse.Visibility = ViewStates.Visible;
                        NextCourse.AddView(new CoursesListAdapter(Activity, incomplete.Take(1), CourseListState.Current).GetView(0, null, NextCourse));
                    }
                    if (incomplete.Count > 1)
                    {
                        lblUpNext.Visibility = ViewStates.Visible;
                        NextCoursesList.Visibility = ViewStates.Visible;
                        var adapter = new CoursesListAdapter(Activity, incomplete.Skip(1), CourseListState.UpNext);
                        for (int i = 0; i < adapter.Count; i++)
                        {
                            NextCoursesList.AddView(adapter.GetView(i, null, NextCoursesList));
                        }
                    }
                    if (complete.Any())
                    {
                        lblCompleted.Visibility = ViewStates.Visible;
                        CompletedCoursesList.Visibility = ViewStates.Visible;
                        var adapter = new CoursesListAdapter(Activity, complete, CourseListState.Complete);
                        for (int i = 0; i < adapter.Count; i++)
                        {
                            CompletedCoursesList.AddView(adapter.GetView(i, null, CompletedCoursesList));
                        }
                    }
                });
            }
            catch (System.Exception ex)
            {
                Console.WriteLine(ex.Message);
            }

            App.ScrollToTop((CoursesActivity)this.Activity);

            return view;
        }
    }
}