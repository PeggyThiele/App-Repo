﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using Org.Apache.Http.Client.Params;
using WELS.App.Shared.Data;

namespace WELS.App.Fragments
{
    class RegisterACFragment : Fragment
    {
        LinearLayout layoutForm, layoutThankYou;
        EditText txtFirstName, txtLastName, txtPhoneNumber, txtCity, txtCountry, txtTellUsAboutYourself, txtEmail, txtWhichChurch;
        TextView lblValidation, txtRegisterMessage;
        CheckBox chkDataPrivacyAccept;
        Button btnSubmit;

        public override void OnCreate(Bundle savedInstanceState)
        {
            base.OnCreate(savedInstanceState);
        }

        public override View OnCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
        {
            var view = inflater.Inflate(Resource.Layout.fragment_register_ac, container, false);

            layoutForm = view.FindViewById<LinearLayout>(Resource.Id.layoutForm);
            layoutThankYou = view.FindViewById<LinearLayout>(Resource.Id.layoutThankYou);

            txtFirstName = view.FindViewById<EditText>(Resource.Id.txtFirstName);
            txtLastName = view.FindViewById<EditText>(Resource.Id.txtLastName);
            txtPhoneNumber = view.FindViewById<EditText>(Resource.Id.txtPhoneNumber);
            txtCity = view.FindViewById<EditText>(Resource.Id.txtCity);
            txtCountry = view.FindViewById<EditText>(Resource.Id.txtCountry);
            //txtContactPreference = view.FindViewById<EditText>(Resource.Id.txtContactPreference);
            txtTellUsAboutYourself = view.FindViewById<EditText>(Resource.Id.txtTellUsAboutYourself);
            txtEmail = view.FindViewById<EditText>(Resource.Id.txtEmail);
            //txtShareTheWord = view.FindViewById<EditText>(Resource.Id.txtShareTheWord);
            txtWhichChurch = view.FindViewById<EditText>(Resource.Id.txtWhichChurch);
            chkDataPrivacyAccept = view.FindViewById<CheckBox>(Resource.Id.chkDataPrivacyAccept);

            lblValidation = view.FindViewById<TextView>(Resource.Id.lblValidation);
            btnSubmit = view.FindViewById<Button>(Resource.Id.btnSubmit);
            btnSubmit.Click += BtnSubmit_Click;

            // Reload copy that needs some formatting
            txtRegisterMessage = view.FindViewById<TextView>(Resource.Id.txtRegisterMessage);
            txtRegisterMessage.Text = this.GetString(Resource.String.register_message);

            return view;
        }

        private async void BtnSubmit_Click(object sender, EventArgs e)
        {
            // Validate all required fields
            if (string.IsNullOrWhiteSpace(txtFirstName.Text))
            {
                lblValidation.Text = this.GetString(Resource.String.register_v_firstname);
                lblValidation.Visibility = ViewStates.Visible;
                App.ScrollToTop((CoursesActivity)this.Activity);
                return;
            }
            if (string.IsNullOrWhiteSpace(txtLastName.Text))
            {
                lblValidation.Text = this.GetString(Resource.String.register_v_lastname);
                lblValidation.Visibility = ViewStates.Visible;
                App.ScrollToTop((CoursesActivity)this.Activity);
                return;
            }
            if (string.IsNullOrWhiteSpace(txtPhoneNumber.Text))
            {
                lblValidation.Text = this.GetString(Resource.String.register_v_phone_number);
                lblValidation.Visibility = ViewStates.Visible;
                App.ScrollToTop((CoursesActivity)this.Activity);
                return;
            }
            if (string.IsNullOrWhiteSpace(txtCity.Text))
            {
                lblValidation.Text = this.GetString(Resource.String.register_v_city);
                lblValidation.Visibility = ViewStates.Visible;
                App.ScrollToTop((CoursesActivity)this.Activity);
                return;
            }
            if (string.IsNullOrWhiteSpace(txtCountry.Text))
            {
                lblValidation.Text = this.GetString(Resource.String.register_v_country);
                lblValidation.Visibility = ViewStates.Visible;
                App.ScrollToTop((CoursesActivity)this.Activity);
                return;
            }
            if (!chkDataPrivacyAccept.Checked)
            {
                lblValidation.Text = this.GetString(Resource.String.register_v_data_privacy);
                lblValidation.Visibility = ViewStates.Visible;
                App.ScrollToTop((CoursesActivity)this.Activity);
                return;
            }

            var postTo = this.GetString(Resource.String.register_post_url);
            var source = this.GetString(Resource.String.register_source);

            var parms = new Dictionary<string, string>();
            parms.Add("FirstName", txtFirstName.Text);
            parms.Add("LastName", txtLastName.Text);
            parms.Add("PhoneNumber", txtPhoneNumber.Text);
            parms.Add("City", txtCity.Text);
            parms.Add("Country", txtCountry.Text);
            //parms.Add("ContactPreference", txtContactPreference.Text);
            parms.Add("TellUsAboutYourself", txtTellUsAboutYourself.Text);
            parms.Add("Email", txtEmail.Text);
            //parms.Add("ShareTheWord", txtShareTheWord.Text);
            parms.Add("WhichChurch", txtWhichChurch.Text);
            parms.Add("DataPrivacy", chkDataPrivacyAccept.Checked.ToString());
            parms.Add("Source", source);

            var request = new HttpRequestMessage(System.Net.Http.HttpMethod.Post, postTo) { Content = new FormUrlEncodedContent(parms) };

            var client = new HttpClient();
            await client.SendAsync(request);

            layoutForm.Visibility = ViewStates.Gone;
            layoutThankYou.Visibility = ViewStates.Visible;
        }
    }
}