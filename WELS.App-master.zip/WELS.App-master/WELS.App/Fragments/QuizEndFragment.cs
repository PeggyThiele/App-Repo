﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Webkit;
using Android.Widget;
using WELS.App.Extensions;
using WELS.App.Shared.Data;
using WELS.App.Shared.Helpers;
using Xamarin.Facebook.AppEvents;

namespace WELS.App.Fragments
{
    class QuizEndFragment : Fragment
    {
        private Course _course;
        private Lesson _lesson;
        private TextView txtEncouragementMessage, txtCongrats;
        private Button btnBackToCourses, btnNextLesson;

        public override void OnCreate(Bundle savedInstanceState)
        {
            base.OnCreate(savedInstanceState);
        }

        public override View OnCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
        {
            var view = inflater.Inflate(Resource.Layout.fragment_quiz_end, container, false);
            
            _course = App.Courses.FirstOrDefault(c => c.CourseNodeID == this.Arguments.GetInt("CourseNodeID"));
            _lesson = _course.Lessons.FirstOrDefault(c => c.LessonNodeID == this.Arguments.GetInt("LessonNodeID"));

            txtEncouragementMessage = view.FindViewById<TextView>(Resource.Id.txtEncouragementMessage);
            txtCongrats = view.FindViewById<TextView>(Resource.Id.txtCongrats);
            btnNextLesson = view.FindViewById<Button>(Resource.Id.btnNextLesson);
            btnBackToCourses = view.FindViewById<Button>(Resource.Id.btnBackToCourses);

            Activity.RunOnUiThread(async () =>
            {
                EncouragementMessage message = null;
                // If a specific encouragement message is set, assign it now
                if (_lesson.EncouragementMessageNodeID > 0)
                {
                    message = App.DataHelper.GetEncouragementMessages().FirstOrDefault(m => m.LanguageEncouragementMessageNodeID == _lesson.EncouragementMessageNodeID);
                }
                // If our message is still null, get a random one
                if (message == null)
                {
                    message = await App.DataHelper.GetRandomEncouragementMessage((await App.CurrentLanguage()).LanguageNodeID);
                }
                txtEncouragementMessage.Text = message.Message;
                
                // Log a Facebook "View Content" event
                App.LogViewContentEvent(this.Activity, "Quiz End", message.Message, message.LanguageEncouragementMessageNodeID.ToString());

                // Show video, if set
                var videoLayout = view.FindViewById<LinearLayout>(Resource.Id.VideoLayout);
                if (!string.IsNullOrWhiteSpace(message.VideoURL))
                {
                    var VideoLayout = view.FindViewById<LinearLayout>(Resource.Id.VideoLayout);
                    var webVideoPlayer = new WebView(this.Activity);
                    VideoLayout.Visibility = ViewStates.Visible;
                    webVideoPlayer.Settings.JavaScriptEnabled = true;
                    var parentActivity = ((CoursesActivity)this.Activity);
                    webVideoPlayer.SetWebChromeClient(new FullScreenWebChromeClient(parentActivity, parentActivity.Drawer, parentActivity.ContentLayout, parentActivity.Navigation));
                    var youtubeID = VideoHelper.ParseYouTubeID(message.VideoURL);
                    webVideoPlayer.LoadData($"<html><body style=\"padding: 0; margin: 0\"><iframe width=\"100%\" height=\"100%\" src=\"https://www.youtube-nocookie.com/embed/{youtubeID}?modestbranding=1\" frameborder=\"0\" allow=\"accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture\" allowfullscreen></iframe></body></html>", "text/html", "utf-8");
                    var layout = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MatchParent, LinearLayout.LayoutParams.MatchParent);
                    layout.SetMargins(0, 0, 0, 0);
                    webVideoPlayer.LayoutParameters = layout;

                    videoLayout.AddView(webVideoPlayer);
                }
                else
                {
                    videoLayout.Visibility = ViewStates.Gone;
                }
                btnNextLesson.Visibility = ViewStates.Gone;
                if (_lesson != null)
                {
                    txtCongrats.Text = string.Format(this.GetString(Resource.String.quiz_end_congrats), _lesson.SortOrder);
                    var nextLesson = _course.Lessons.FirstOrDefault(l => l.SortOrder > _lesson.SortOrder && l.DateCompletedAllLessonItems == null);
                    if (nextLesson != null)
                    {
                        btnNextLesson.Text = string.Format(this.GetString(Resource.String.quiz_end_next), _lesson.SortOrder + 1);
                        btnNextLesson.Click += delegate
                        {
                            var args = new Bundle();
                            args.PutInt("CourseNodeID", nextLesson.CourseNodeID);

                            App.ScrollToTop((CoursesActivity)this.Activity);
                            FragmentManager.BeginTransaction().Replace(Resource.Id.frame_container, new CourseFragment() { Arguments = args }, "CourseFragmentTag").Commit();
                        };
                        btnNextLesson.Visibility = ViewStates.Visible;
                    }
                }
                btnBackToCourses.Click += delegate
                {
                    GoToCoursesFragment();
                };
            });

            return view;
        }

        private void GoToCoursesFragment()
        {
            // If we've authenticated, redirect to the course list, otherwise use NextActivity to determine what to do next
            if (App.CurrentAccount.HasAuthenticated)
            {
                App.ScrollToTop((CoursesActivity)this.Activity);
                FragmentManager.BeginTransaction().Replace(Resource.Id.frame_container, new CoursesFragment()).Commit();
            }
            else
            {
                App.NextActivity(this.Activity);
            }
        }
    }
}