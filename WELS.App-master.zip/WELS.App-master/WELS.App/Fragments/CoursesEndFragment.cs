﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using WELS.App.Shared.Data;

namespace WELS.App.Fragments
{
    class CoursesEndFragment : Fragment
    {
        private TextView txtSummary;
        private Button btnSignMeUp, btnNoThankYou;

        public override void OnCreate(Bundle savedInstanceState)
        {
            base.OnCreate(savedInstanceState);
        }

        public override View OnCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
        {
            var view = inflater.Inflate(Resource.Layout.fragment_courses_end, container, false);

            txtSummary = view.FindViewById<TextView>(Resource.Id.txtSummary);
            btnSignMeUp = view.FindViewById<Button>(Resource.Id.btnSignMeUp);
            btnNoThankYou = view.FindViewById<Button>(Resource.Id.btnNoThankYou);

            Activity.RunOnUiThread(() =>
            {
                txtSummary.Text = string.Format(this.GetString(Resource.String.course_end_summary), App.Courses.Count, App.Courses.Sum(c => c.Lessons.Count), App.CurrentAccount.Name);
                btnSignMeUp.Click += delegate
                {
                    //var intent1 = new Intent(Intent.ActionView, Android.Net.Uri.Parse(GetString(Resource.String.course_end_sign_up_link)));
                    //StartActivity(intent1);
                    App.ScrollToTop((CoursesActivity)this.Activity);
#if (ACADEMIACRISTO)
                    FragmentManager.BeginTransaction().Replace(Resource.Id.frame_container, new RegisterACFragment()).Commit();
#else
                    FragmentManager.BeginTransaction().Replace(Resource.Id.frame_container, new RegisterFragment()).Commit();
#endif
                };
                btnNoThankYou.Click += delegate
                {
                    var args = new Bundle();
                    App.PreventRedirectToSignup = true;

                    App.ScrollToTop((CoursesActivity)this.Activity);
                    FragmentManager.BeginTransaction().Replace(Resource.Id.frame_container, new CoursesFragment() { Arguments = args }).Commit();
                };
            });

            return view;
        }
    }
}