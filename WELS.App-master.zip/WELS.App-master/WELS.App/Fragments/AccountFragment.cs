﻿using Android.App;
using Android.Content;
using Android.Graphics;
using Android.OS;
using Android.Views;
using Android.Views.InputMethods;
using Android.Widget;
using Com.Bumptech.Glide;
using Refractored.Controls;
using System;
using System.Net;
using Xamarin.Facebook.Login;

namespace WELS.App.Fragments
{
    public class AccountFragment : Fragment
    {
        Button btnLogOut, btnSaveNumber;
        ImageButton btnEditNumber;
        TextView account_name, account_joined, account_number;
        EditText account_number_edit;
        ToggleButton chkAllowPushNotifications, chkAllowTextReminders;
        CircleImageView profileImageView;

        public override void OnCreate(Bundle savedInstanceState)
        {
            base.OnCreate(savedInstanceState);
        }

        public override View OnCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
        {
            var view = inflater.Inflate(Resource.Layout.fragment_account, container, false);
            
            // Logout button
            btnLogOut = view.FindViewById<Button>(Resource.Id.btnLogOut);
            btnLogOut.Click += delegate
            {
                // Log out of both facebook and whatsapp
                App.Logout();

                Intent loginIntent = new Intent(this.Activity, typeof(LoginActivity));
                StartActivity(loginIntent);
            };

            // Edit button(s)
            btnEditNumber = view.FindViewById<ImageButton>(Resource.Id.btnEditNumber);
            btnSaveNumber = view.FindViewById<Button>(Resource.Id.btnSaveNumber);
            account_number_edit = view.FindViewById<EditText>(Resource.Id.account_number_edit);

            // If this is a WhatsApp account, disable editing of the WhatsApp number
            if (!string.IsNullOrEmpty(App.CurrentAccount.WhatsAppUserID))
            {
                btnEditNumber.Visibility = ViewStates.Gone;
            }
            else
            {
                btnEditNumber.Click += delegate
                {
                    btnEditNumber.Visibility = ViewStates.Invisible;
                    account_number.Visibility = ViewStates.Invisible;
                    btnSaveNumber.Visibility = ViewStates.Visible;
                    account_number_edit.Visibility = ViewStates.Visible;
                    account_number_edit.SelectAll();
                    // Ensure the keyboard shows
                    InputMethodManager imm = (InputMethodManager)this.Activity.GetSystemService(Context.InputMethodService);
                    imm.ShowSoftInput(account_number_edit, ShowFlags.Implicit);
                };
                btnSaveNumber.Click += delegate
                {
                    this.Activity.RunOnUiThread(async () =>
                    {
                        App.HideKeyboard(this.Activity);
                        App.CurrentAccount.WhatsAppNumber = account_number_edit.Text;
                        await App.DataHelper.SaveAccount(App.CurrentAccount);

                        account_number.Text = App.CurrentAccount.WhatsAppNumber;
                        btnSaveNumber.Visibility = ViewStates.Invisible;
                        account_number_edit.Visibility = ViewStates.Invisible;
                        btnEditNumber.Visibility = ViewStates.Visible;
                        account_number.Visibility = ViewStates.Visible;
                    });
                };
            }

            // Load account details
            account_name = view.FindViewById<TextView>(Resource.Id.account_name);
            account_joined = view.FindViewById<TextView>(Resource.Id.account_joined);
            account_number = view.FindViewById<TextView>(Resource.Id.account_number);
            chkAllowPushNotifications = view.FindViewById<ToggleButton>(Resource.Id.chkAllowPushNotifications);
            chkAllowTextReminders = view.FindViewById<ToggleButton>(Resource.Id.chkAllowTextReminders);
            profileImageView = view.FindViewById<CircleImageView>(Resource.Id.profile_image);
            
            // Load vales from Account
            account_name.Text = App.CurrentAccount.Name;
            account_joined.Text = App.CurrentAccount.DateCreated.ToLongDateString();
            account_number.Text = App.CurrentAccount.WhatsAppNumber;
            account_number_edit.Text = App.CurrentAccount.WhatsAppNumber;
            chkAllowPushNotifications.Checked = App.CurrentAccount.EnablePushNotifications;
            chkAllowPushNotifications.CheckedChange += ChkAllowPushNotifications_CheckedChange;
            chkAllowTextReminders.Checked = App.CurrentAccount.EnableTextNotifications;
            chkAllowTextReminders.CheckedChange += ChkAllowTextReminders_CheckedChange;
            if (!string.IsNullOrEmpty(App.CurrentAccount.FacebookProfileImageURL))
            {
                Glide.With(this.Activity).Load(App.CurrentAccount.FacebookProfileImageURL).Into(profileImageView);
            }

            return view;
        }

        private void ChkAllowTextReminders_CheckedChange(object sender, CompoundButton.CheckedChangeEventArgs e)
        {
            this.Activity.RunOnUiThread(async () =>
            {
                App.CurrentAccount.EnableTextNotifications = chkAllowTextReminders.Checked;
                await App.DataHelper.SaveAccount(App.CurrentAccount);
            });
        }

        private void ChkAllowPushNotifications_CheckedChange(object sender, CompoundButton.CheckedChangeEventArgs e)
        {
            this.Activity.RunOnUiThread(async () =>
            {
                App.CurrentAccount.EnablePushNotifications = chkAllowPushNotifications.Checked;
                await App.DataHelper.SaveAccount(App.CurrentAccount);

                App.RefreshPushNotificationTags();
            });
        }
    }
}