﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Webkit;
using Android.Widget;

namespace WELS.App.Extensions
{
    public class FullScreenWebChromeClient : Android.Webkit.WebChromeClient
    {
        readonly FrameLayout.LayoutParams matchParentLayout = new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MatchParent,
                                                                                                     ViewGroup.LayoutParams.MatchParent);
        readonly Activity activity;
        readonly ViewGroup content;
        readonly ViewGroup parent;
        readonly View[] additionalContent;
        View customView;

        /// <summary>
        /// Create a web chrome client that hides and shows various views
        /// </summary>
        /// <param name="parent">The video will replace this view group when full screen</param>
        /// <param name="content">The main view group (layout) to hide when full screen</param>
        /// <param name="additionalContent">(Optional) Any additional views to hide</param>
        /// 
        public FullScreenWebChromeClient(Activity activity, ViewGroup parent, ViewGroup content, params View[] additionalContent)
        {
            this.activity = activity;
            this.parent = parent;
            this.content = content;
            this.additionalContent = additionalContent;
        }

        public override void OnShowCustomView(View view, ICustomViewCallback callback)
        {
            activity.RequestedOrientation = Android.Content.PM.ScreenOrientation.Locked;
            customView = view;
            view.LayoutParameters = matchParentLayout;
            parent.AddView(view);
            content.Visibility = ViewStates.Gone;
            if (additionalContent != null)
            {
                foreach (var c in additionalContent)
                {
                    c.Visibility = ViewStates.Gone;
                }
            }
        }

        public override void OnHideCustomView()
        {
            activity.RequestedOrientation = Android.Content.PM.ScreenOrientation.Unspecified;
            content.Visibility = ViewStates.Visible;
            if (additionalContent != null)
            {
                foreach (var c in additionalContent)
                {
                    c.Visibility = ViewStates.Visible;
                }
            }
            parent.RemoveView(customView);
            customView = null;
        }
    }
}