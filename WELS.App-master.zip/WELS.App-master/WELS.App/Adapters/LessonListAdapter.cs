﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Webkit;
using Android.Widget;
using Com.Bumptech.Glide;
using WELS.App.Shared.Data;
using WELS.App.Shared.Helpers;

namespace WELS.App.Adapters
{
    class LessonListAdapter : BaseAdapter<Lesson>
    {
        readonly Activity context;
        private Course _course;
        private IEnumerable<Lesson> _lessons;
        private bool _includeVideo;

        public LessonListAdapter(Activity context, Course course, IEnumerable<Lesson> lessons, bool includeVideo)
        {
            this.context = context;
            this._course = course;
            this._lessons = lessons;
            this._includeVideo = includeVideo;
        }

        public override Lesson this[int position]
        {
            get
            {
                return _lessons.ElementAt(position);
            }
        }

        public override int Count
        {
            get
            {
                return _lessons.Count();
            }
        }

        public override long GetItemId(int position)
        {
            return position;
        }

        public override View GetView(int position, View convertView, ViewGroup parent)
        {
            var view = convertView;
            LessonListAdapterViewHolder holder = null;

            if (view != null)
                holder = view.Tag as LessonListAdapterViewHolder;

            var lesson = this[position];

            if (holder == null)
            {
                holder = new LessonListAdapterViewHolder();
                var inflater = context.GetSystemService(Context.LayoutInflaterService).JavaCast<LayoutInflater>();

                view = inflater.Inflate(Resource.Layout.fragment_course_lesson, parent, false);
                holder.Layout = view.FindViewById<LinearLayout>(Resource.Id.lessonItemLayout);
                holder.txtLessonNumber = view.FindViewById<TextView>(Resource.Id.txtLessonNumber);
                holder.txtLessonName = view.FindViewById<TextView>(Resource.Id.txtLessonName);
                holder.Image = view.FindViewById<ImageView>(Resource.Id.completedLessonImage);
                view.Tag = holder;
            }
            holder.txtLessonNumber.Text = _course.Name;
            holder.txtLessonName.Text = lesson.Name;
            if (_includeVideo && lesson.LessonItems.Any(i => i.Type == Constants.LessonItemType.Video))
            {
                holder.Image.Visibility = ViewStates.Visible;
                var youtubeURL = lesson.LessonItems.FirstOrDefault(i => i.Type == Constants.LessonItemType.Video).VideoURL;
                var youtubeID = VideoHelper.ParseYouTubeID(youtubeURL);
                var youtubeImageUrl = $"https://img.youtube.com/vi/{youtubeID}/default.jpg";
                Glide.With(holder.Layout).Load(youtubeImageUrl).Into(holder.Image);
            }
            // Allow viewing completed lessons when the course itself is completed
            if (lesson.DateCompletedAllLessonItems != null && _course.DateCompleted != null)
            {
                holder.Layout.SetOnClickListener(new ButtonClickListener(lesson.CourseNodeID, lesson.LessonNodeID, (CoursesActivity)this.context));
            }
            return view;
        }
    }

    class ButtonClickListener : Java.Lang.Object, View.IOnClickListener
    {
        private int _courseNodeID;
        private int _lessonNodeID;
        private CoursesActivity _activity;

        public ButtonClickListener(int courseNodeID, int lessonNodeID, CoursesActivity activity)
        {
            this._courseNodeID = courseNodeID;
            this._lessonNodeID = lessonNodeID;
            this._activity = activity;
        }

        public void OnClick(View v)
        {
            var args = new Bundle();
            args.PutInt("CourseNodeID", _courseNodeID);
            args.PutInt("LessonNodeID", _lessonNodeID);

            _activity.FragmentManager.BeginTransaction().Replace(Resource.Id.frame_container, new CourseFragment() { Arguments = args }, "CourseFragmentTag").Commit();
        }
    }

    class LessonListAdapterViewHolder : Java.Lang.Object
    {
        public LinearLayout Layout { get; set; }
        public TextView txtLessonNumber { get; set; }
        public TextView txtLessonName { get; set; }
        public ImageView Image { get; set; }
    }
}