﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Support.Constraints;
using Android.Views;
using Android.Widget;
using WELS.App.Fragments;
using WELS.App.Helpers;
using WELS.App.Shared.Data;
using WELS.App.Shared.Models.Response;

namespace WELS.App
{
    public enum CourseListState
    {
        Current,
        UpNext,
        Complete
    }

    class CoursesListAdapter : BaseAdapter<Course>
    {
        readonly Activity context;
        private IEnumerable<Course> _courses;
        private CourseListState _state;

        public CoursesListAdapter(Activity context, IEnumerable<Course> courses, CourseListState state)
        {
            this.context = context;
            this._courses = courses;
            this._state = state;
        }

        public override Course this[int position]
        {
            get
            {
                return _courses.ElementAt(position);
            }
        }

        public override long GetItemId(int position)
        {
            return position;
        }

        public override View GetView(int position, View convertView, ViewGroup parent)
        {
            var view = convertView;
            CoursesListAdapterViewHolder holder = null;

            if (view != null)
                holder = view.Tag as CoursesListAdapterViewHolder;

            var course = this[position];

            if (holder == null)
            {
                holder = new CoursesListAdapterViewHolder();
                var inflater = context.GetSystemService(Context.LayoutInflaterService).JavaCast<LayoutInflater>();
                //replace with your item and your holder items
                //comment back in
                view = inflater.Inflate(Resource.Layout.fragment_courses_course_item, parent, false);
                holder.BorderTop = view.FindViewById<LinearLayout>(Resource.Id.borderTop);
                holder.BorderTop.SetBackgroundResource(AppHelper.GetResourceColor("colorAccent" + ((course.SortOrder - 1) % 5)));
                holder.Course = view.FindViewById<TextView>(Resource.Id.course);
                holder.LockImage = view.FindViewById<ImageView>(Resource.Id.lockImage);
                holder.CourseName = view.FindViewById<TextView>(Resource.Id.courseName);
                holder.CourseLessons = view.FindViewById<TextView>(Resource.Id.courseLessons);
                holder.CourseLength = view.FindViewById<TextView>(Resource.Id.courseLength);
                holder.CourseDescription = view.FindViewById<TextView>(Resource.Id.courseDescription);
                holder.btnArrow = view.FindViewById<ImageButton>(Resource.Id.btnArrow);
                switch (_state)
                {
                    case CourseListState.Current:
                        holder.btnStartLesson = view.FindViewById<Button>(Resource.Id.btnStartLesson);
                        holder.LockImage.Visibility = ViewStates.Gone;
                        holder.btnArrow.Visibility = ViewStates.Visible;
                        holder.btnStartLesson.Visibility = ViewStates.Visible;
                        holder.btnArrow.SetOnClickListener(new ButtonClickListener(course.CourseNodeID, (CoursesActivity)this.context));
                        holder.btnStartLesson.SetOnClickListener(new ButtonClickListener(course.CourseNodeID, (CoursesActivity)this.context));
                        break;
                    case CourseListState.Complete:
                        holder.LockImage.Visibility = ViewStates.Gone;
                        holder.btnArrow.Visibility = ViewStates.Visible;
                        holder.btnArrow.SetOnClickListener(new ButtonClickListener(course.CourseNodeID, (CoursesActivity)this.context));
                        break;
                }
                view.Tag = holder;
            }


            //load the values from the course
            holder.Course.Text = string.Format(parent.Context.GetString(Resource.String.course_card_course_number), course.SortOrder);
            holder.CourseName.Text = course.Name;
            holder.CourseLessons.Text = string.Format(parent.Context.GetString(Resource.String.course_card_lesson_count), course.Lessons.Count());
            holder.CourseLength.Text = course.EstimatedDuration;
            holder.CourseDescription.Text = course.ShortDescription;

            return view;
        }

        public override int Count
        {
            get
            {
                return _courses.Count();
            }
        }

    }
    class ButtonClickListener : Java.Lang.Object, View.IOnClickListener
    {
        private int _courseNodeID;
        private CoursesActivity _activity;

        public ButtonClickListener(int courseNodeID, CoursesActivity activity)
        {
            this._courseNodeID = courseNodeID;
            this._activity = activity;
        }

        public void OnClick(View v)
        {
            var args = new Bundle();
            args.PutInt("CourseNodeID", _courseNodeID);

            App.ScrollToTop(_activity);
            _activity.FragmentManager.BeginTransaction().Replace(Resource.Id.frame_container, new CourseFragment() { Arguments = args }, "CourseFragmentTag").Commit();
        }
    }

    class CoursesListAdapterViewHolder : Java.Lang.Object
    {
        public LinearLayout BorderTop { get; set; }
        public TextView Course { get; set; }
        public ImageView LockImage { get; set; }
        public ImageButton btnArrow { get; set; }
        public TextView CourseName { get; set; }
        public TextView CourseLessons { get; set; }
        public TextView CourseLength { get; set; }
        public TextView CourseDescription { get; set; }
        public Button btnStartLesson { get; set; }
    }
}