# WELS.App

## Build

### Build errors

If you run into an error where it mentions not being able to execute a .ps1 file, this is a pre-build command that ensures a swap of some configuration data based on current build configuration.  Essentially, you will need to set your execution policy in PowerShell to Unrestricted for the Current User as well as Local Machine:  `Set-ExecutionPolicy -ExecutionPolicy Unrestricted CurrentUser`.  See https://docs.microsoft.com/en-us/powershell/module/microsoft.powershell.core/about/about_execution_policies?view=powershell-6 for more details.

## Deployment (Google Play)

https://play.google.com/apps/publish  
Account:  lightburndesigns1@gmail.com  
App Name:  WELS Tell

### Alpha/Beta

**Important!**: Make sure to add new testers to the facebook app @ https://developers.facebook.com/, otherwise they will not be able to log in (and it may not be obvious as to why in some OS's)

Play Console, Under App releases, Internal test track

### To Build the APK (Android):

1. Change to Release Mode
2. Update the version number in the Project Properties => Android Manifest
3. Clean and Rebuild the solution
4. Right-click the project, and click "Archive".  If archiving stalls with an error, restarting Visual Studio can often resolve this issue.
5. Once archiving is complete, select the archive, and click the Distribute Button
6. Click the Ad-Hoc option, then Next
7. Create a new signing identity or select existing identity
8. Click "Save As" to create the .apk file

The resulting file can be uploaded into the Google Play Console.

### Crash Reports

Crash reports are collected by the App Center @ https://appcenter.ms

### Facebook Stuff

To Generate a Hash Key for Facebook (run from c:\Program Files\Java\jdk1.8.0_181\bin):

keytool -exportcert -alias Lightburn -keystore "C:\Users\Keith\AppData\Local\Xamarin\Mono for Android\Keystore\Lightburn\Lightburn.keystore" | "C:\openSSL\bin\openssl" sha1 -binary | "C:\openSSL\bin\openssl" base64

Notes:
1.  Replace alias "Lightburn" and keystore path if using a different key store. 
2.  OpenSSL can be downloaded at https://code.google.com/archive/p/openssl-for-windows/downloads
3.  Lightburn key store can be downloaded at https://www.dropbox.com/home/Client%20Projects/WELS


### To publish the iOS app to TestFlight

1. Ensure that you are paired to the MacInCloud mac
2. Ensure you have downloaded all certificates and publish profiles from the apple@lightburndesigns.com Apple account.  This can be found under Tools => Options => Xamarin => Apple Accounts.  Once there, log in with the account, then scroll down and select "Lightburn Designs, LLC" from the list and then click the "View Details.." button.  Once the lists load, click the "Download All Profiles" button.  If doing this for the first time, I would recommend closing all Visual Studio instances and re-open.
3. **Ensure you are in the "Release" build configuration**, with device set to 'iPhone' (NOT 'iPhoneSimulator')
4. Ensure the correct bundle options are set:  Right-click on the iOS project, and select "Properties".  Click "iOS Bundle Signing".  Set Signing Identity to "Wisconsin Evangelical Lutheran Synod" and Provisioning Profile to "Automatic".
5. Open the info.plist settings file, and increment the Build and Version numbers (i.e. Old build number: 1.01; New build number: 1.02).  Note that all app-specific settings are replaced in Info.plist by the pre-build script named "Update-PackageName.ps1", so version numbers are the only thing that should need to be manually updated.
6. Clean and rebuild the iOS project.
7. Right-click the iOS project and select "Archive"
8. Once the archive completes, log into the MacInCloud mac.
9. Open XCode, then open Window => Organizer.  The new archive should appear in the list.
10. Select the new archive, and click the "Distribute App" button.  Complete the wizard, and the new version will be on TestFlight.
11. Log into App Store Connect (with the apple@lightburndesigns.com account) to verify that the app successfully deployed to TestFlight.
12. Repeat for TELL/Academia Cristo