﻿using SQLite;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using WELS.App.Shared.Interfaces;
using WELS.App.Shared.Models.Request;

namespace WELS.App.Shared.Data
{
    [Table("LessonItem")]
    public class LessonItem : ISyncable
    {
        [PrimaryKey]
        public int LessonItemNodeID { get; set; }
        public int LessonNodeID { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
        public string Type { get; set; }
        public string VideoURL { get; set; }
        public string Text { get; set; }
        public int SortOrder { get; set; }
        public DateTime? DateCompleted { get; set; }
        public DateTime? LastStatusSync { get; set; }
        public bool NeedsSync { get; set; }

        public async Task Sync(IApi api)
        {
            await api.SaveLessonItemStatus(this.LessonItemNodeID, new LessonItemStatusRequest()
            {
                DateCompleted = this.DateCompleted
            });
        }
    }
}
