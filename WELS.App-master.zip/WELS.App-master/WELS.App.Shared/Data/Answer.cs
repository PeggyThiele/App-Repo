﻿using SQLite;
using System;
using System.Collections.Generic;
using System.Text;

namespace WELS.App.Shared.Data
{
    [Table("Answer")]
    public class Answer
    {
        [PrimaryKey]
        public int AnswerNodeID { get; set; }
        public int QuestionNodeID { get; set; }
        public string AnswerText { get; set; }
        public bool IsCorrectAnswer { get; set; }
        public int SortOrder { get; set; }
    }
}
