﻿using SQLite;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using WELS.App.Shared.Interfaces;
using WELS.App.Shared.Models.Request;

namespace WELS.App.Shared.Data
{
    [Table("Lesson")]
    public class Lesson : ISyncable
    {
        [PrimaryKey]
        public int LessonNodeID { get; set; }
        public int CourseNodeID { get; set; }
        public string Name { get; set; }
        public int EncouragementMessageNodeID { get; set; }
        public int SortOrder { get; set; }
        public DateTime? DateStarted { get; set; }
        public DateTime? DateWatchedVideo { get; set; }
        public DateTime? DateCompletedAllLessonItems { get; set; }
        public DateTime? DateCompletedQuiz { get; set; }
        public DateTime? LastStatusSync { get; set; }
        public bool NeedsSync { get; set; }
        [Ignore]
        public List<LessonItem> LessonItems { get; set; }
        [Ignore]
        public List<Question> Questions { get; set; }

        public async Task Sync(IApi api)
        {
            await api.SaveLessonStatus(this.LessonNodeID, new LessonStatusRequest()
            {
                DateStarted = this.DateStarted,
                DateWatchedVideo = this.DateWatchedVideo,
                DateCompletedAllLessonItems = this.DateCompletedAllLessonItems,
                DateCompletedQuiz = this.DateCompletedQuiz
            });
        }
    }
}
