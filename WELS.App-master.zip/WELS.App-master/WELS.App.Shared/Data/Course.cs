﻿using SQLite;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using WELS.App.Shared.Interfaces;
using WELS.App.Shared.Models.Request;

namespace WELS.App.Shared.Data
{
    [Table("Course")]
    public class Course : ISyncable
    {
        [PrimaryKey]
        public int CourseNodeID { get; set; }
        public int LanguageNodeID { get; set; }
        public string Name { get; set; }
        public string ShortDescription { get; set; }
        public string Description { get; set; }
        public string EstimatedDuration { get; set; }
        public int Version { get; set; }
        public int CourseType { get; set; }
        public int SortOrder { get; set; }
        public DateTime? DateStarted { get; set; }
        public DateTime? DateCompleted { get; set; }
        public DateTime? DateDownloaded { get; set; }
        public DateTime? LastStatusSync { get; set; }
        public bool NeedsSync { get; set; }
        [Ignore]
        public List<Lesson> Lessons { get; set; }

        public async Task Sync(IApi api)
        {
            await api.SaveCourseStatus(this.CourseNodeID, new CourseStatusRequest()
            {
                DateStarted = this.DateStarted,
                DateCompleted = this.DateCompleted,
                DateDownloaded = this.DateDownloaded
            });
        }
    }
}
