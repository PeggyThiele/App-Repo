﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using SQLite;

namespace WELS.App.Shared.Data
{
    public class LocalDatabase
    {
        private SQLiteConnection _db;

        public LocalDatabase()
        {
            var path = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Personal), "data.db3");
            _db = new SQLiteConnection(path);
            
            _db.CreateTable<Account>();
            _db.CreateTable<Course>();
            _db.CreateTable<Lesson>();
            _db.CreateTable<LessonItem>();
            _db.CreateTable<Question>();
            _db.CreateTable<Answer>();
            _db.CreateTable<EncouragementMessage>();
        }

        internal void DeleteAllData()
        {
            _db.DeleteAll<Account>();
            _db.DeleteAll<Course>();
            _db.DeleteAll<Lesson>();
            _db.DeleteAll<LessonItem>();
            _db.DeleteAll<Question>();
            _db.DeleteAll<Answer>();
            _db.DeleteAll<EncouragementMessage>();
        }

        internal void DeleteCourse(Course course)
        {
            _db.Delete(course);
        }

        public Account GetAccount(int languageNodeID)
        {
            if (_db.Table<Account>().Count() == 0)
            {
                var account = new Account();
                account.DateCreated = DateTime.UtcNow;
                account.IsSynced = false;
                account.HasAuthenticated = false;
                account.HasDownloadedAllCourses = false;
                account.LanguageNodeID = languageNodeID;
                _db.Insert(account);
            }

            return _db.Table<Account>().FirstOrDefault();
        }

        public List<Course> GetCourses(int languageNodeID)
        {
            var courses = _db.Table<Course>().Where(c => c.LanguageNodeID == languageNodeID).OrderBy(c => c.SortOrder).ToList();
            foreach (var course in courses)
            {
                course.Lessons = _db.Table<Lesson>().Where(l => l.CourseNodeID == course.CourseNodeID).OrderBy(l => l.SortOrder).ToList();
                foreach (var lesson in course.Lessons)
                {
                    lesson.LessonItems = _db.Table<LessonItem>().Where(i => i.LessonNodeID == lesson.LessonNodeID).OrderBy(i => i.SortOrder).ToList();
                    lesson.Questions = _db.Table<Question>().Where(q => q.LessonNodeID == lesson.LessonNodeID).OrderBy(q => q.SortOrder).ToList();
                    foreach (var question in lesson.Questions)
                    {
                        question.Answers = _db.Table<Answer>().Where(a => a.QuestionNodeID == question.QuestionNodeID).OrderBy(a => a.SortOrder).ToList();
                    }
                }
            }
            return courses;
        }

        public void SaveObject(object o)
        {
            var rowsUpdated = _db.Update(o);
            if (rowsUpdated == 0)
            {
                _db.Insert(o);
            }
        }

        internal IEnumerable<Course> GetCourseData()
        {
            return _db.Table<Course>();
        }

        internal IEnumerable<Lesson> GetLessonData()
        {
            return _db.Table<Lesson>();
        }

        internal IEnumerable<LessonItem> GetLessonItemData()
        {
            return _db.Table<LessonItem>();
        }

        internal void ClearEncouragementMessages()
        {
            _db.DeleteAll<EncouragementMessage>();
        }

        internal IEnumerable<EncouragementMessage> GetEncouragementMessages()
        {
            return _db.Table<EncouragementMessage>();
        }
    }
}
