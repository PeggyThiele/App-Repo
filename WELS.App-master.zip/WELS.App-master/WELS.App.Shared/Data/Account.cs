﻿using System;
using System.Collections.Generic;
using System.Text;
using SQLite;
using WELS.App.Shared.Interfaces;

namespace WELS.App.Shared.Data
{
    [Table("Account")]
    public class Account
    {
        [PrimaryKey]
        public int PK { get; set; } = 1;
        public string Name { get; set; }
        public string FacebookUserID { get; set; }
        public string WhatsAppUserID { get; set; }
        public string FacebookProfileImageURL { get; set; }
        public string WhatsAppNumber { get; set; }
        public int? LanguageNodeID { get; set; }
        public string CultureCode { get; set; }
        public bool EnablePushNotifications { get; set; }
        public bool EnableTextNotifications { get; set; }
        public DateTime DateCreated { get; set; }
        public DateTime AccountLastModified { get; set; }
        public DateTime DateLastLogin { get; set; }
        public DateTime? DateCompletedOnboarding { get; set; }
        public DateTime? DateCompletedAllCourses { get; set; }
        public int? OnBoardingTotalScore { get; set; }
        public string Source { get; set; }

        /// <summary>
        /// This determines if the local data has been synced with the API.  Once synced, the local data becomes the "master" data and will only 
        /// ever be synced one-way (to the API) going forward.  Until then, we have to assume there is a possibility there is account data on 
        /// the API server for the user (i.e. if they got a new phone and downloaded the data)
        /// </summary>
        public bool IsSynced { get; set; }
        /// <summary>
        /// Since we allow anonymous users to access the first course, this flag will determine whether or not this particular user/account has 
        /// ever authenticated with the API.
        /// </summary>
        public bool HasAuthenticated { get; set; }

        /// <summary>
        /// Set this to TRUE once the account is authenticated AND all of their courses have been downloaded
        /// </summary>
        public bool HasDownloadedAllCourses { get; set; }

        public string PushNotificationID()
        {
            if (!string.IsNullOrEmpty(FacebookUserID))
            {
                return FacebookUserID;
            }
            else if (!string.IsNullOrEmpty(WhatsAppUserID))
            {
                return WhatsAppUserID;
            }

            return Guid.NewGuid().ToString();
        }
    }
}
