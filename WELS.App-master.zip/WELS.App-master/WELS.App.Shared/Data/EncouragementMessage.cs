﻿using SQLite;
using System;
using System.Collections.Generic;
using System.Text;

namespace WELS.App.Shared.Data
{
    [Table("EncouragementMessage")]
    public class EncouragementMessage
    {
        [PrimaryKey]
        public int LanguageEncouragementMessageNodeID { get; set; }
        public string Message { get; set; }
        public string VideoURL { get; set; }
        public bool DontRandomize { get; set; }
    }
}
