﻿using SQLite;
using System;
using System.Collections.Generic;
using System.Text;

namespace WELS.App.Shared.Data
{
    [Table("Question")]
    public class Question
    {
        [PrimaryKey]
        public int QuestionNodeID { get; set; }
        public int LessonNodeID { get; set; }
        public string QuestionText { get; set; }
        public string Type { get; set; }
        public string TeacherAnswer { get; set; }
        public string CheckboxText { get; set; }
        public bool IsEvaluate { get; set; }
        public bool IsLearn { get; set; }
        public int SortOrder { get; set; }
        [Ignore]
        public List<Answer> Answers { get; set; }
    }
}
