﻿using System;
using System.Collections.Generic;
using System.Text;

public class Constants
{
#if DEBUG
    // Swap below to test against the dev/staging API
    //public static readonly string EndpointUri = "https://wels-tellapi-staging.azurewebsites.net";
    public static readonly string EndpointUri = "https://api.tellnetwork.org";
#else
    public static readonly string EndpointUri = "https://api.tellnetwork.org";
#endif

    public class LessonItemType
    {
        public const string Video = "VIDEO";
        public const string Text = "TEXT";
    }

    public class QuestionType
    {
        public const string Essay = "ESSAY";
        public const string MultipleChoice = "MULTIPLECHOICE";
        public const string Checkbox = "CHECKBOX";
    }
}