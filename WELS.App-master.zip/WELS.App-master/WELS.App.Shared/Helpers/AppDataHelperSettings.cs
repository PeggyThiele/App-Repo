﻿namespace WELS.App.Shared.Helpers
{
    public class AppDataHelperSettings
    {
        public string DefaultEncouragementMessage { get; set; }
    }
}