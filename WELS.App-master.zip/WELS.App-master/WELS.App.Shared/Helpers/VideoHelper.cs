﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;

namespace WELS.App.Shared.Helpers
{
    public class VideoHelper
    {
        public static string ParseYouTubeID(string videoURL)
        {
            if (!videoURL.ToLower().StartsWith("http"))
            {
                videoURL = "http://" + videoURL;
            }
            var uri = new Uri(videoURL);
            
            var query = HttpUtility.ParseQueryString(uri.Query);

            var videoId = string.Empty;

            if (query.AllKeys.Contains("v"))
            {
                videoId = query["v"];
            }
            else
            {
                videoId = uri.Segments.Last();
            }

            return videoId;
        }
    }
}
