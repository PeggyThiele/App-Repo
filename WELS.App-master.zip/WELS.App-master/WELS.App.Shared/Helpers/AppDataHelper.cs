﻿using Newtonsoft.Json;
using Plugin.SecureStorage;
using Refit;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;
using WELS.App.Shared.Data;
using WELS.App.Shared.Exceptions;
using WELS.App.Shared.Extensions;
using WELS.App.Shared.Interfaces;
using WELS.App.Shared.Models.Request;
using WELS.App.Shared.Models.Response;

namespace WELS.App.Shared.Helpers
{
    public class AppDataHelper
    {
        private readonly IApi _api;
        private readonly LocalDatabase _db;
        public AppDataHelperSettings Settings { get; set; }
        private bool? _isOffline;

        public async Task<bool> IsOffline()
        {
            if (_isOffline == null || _isOffline == true)
            {
                PingResponse response = null;

                response = await this._api.Ping();

                _isOffline = (response == null || !response.success);
            }

            return _isOffline.Value;
        }

        public FetchTokenRequest LoginInfo
        {
            get
            {
                if (CrossSecureStorage.Current == null) { return new FetchTokenRequest(); }

                // if facebook token hasn't been set, return empty tokens
                var fbInfo = CrossSecureStorage.Current.GetValue("FacebookInfo");
                if (string.IsNullOrWhiteSpace(fbInfo)) { return new FetchTokenRequest(); }

                return JsonConvert.DeserializeObject<FetchTokenRequest>(fbInfo);
            }
            set
            {
                CrossSecureStorage.Current.SetValue("FacebookInfo", JsonConvert.SerializeObject(value));
            }
        }

        internal FetchTokenResponse ApiToken
        {
            get
            {
                if (CrossSecureStorage.Current.GetValue("SessionToken") == null) return null;
                var tokenString = CrossSecureStorage.Current.GetValue("SessionToken");
                try
                {
                    return JsonConvert.DeserializeObject<FetchTokenResponse>(tokenString);
                }
                catch
                {
                    return null;
                }
            }
            set
            {
                CrossSecureStorage.Current.SetValue("SessionToken", JsonConvert.SerializeObject(value));
            }
        }

        public string WhatsAppNumberForLogin
        {
            get
            {
                if (CrossSecureStorage.Current.GetValue("WhatsAppNumberForLogin") == null) return null;
                var whatsAppUserID = CrossSecureStorage.Current.GetValue("WhatsAppNumberForLogin");
                return whatsAppUserID;
            }
            set
            {
                if (value == null)
                {
                    if (CrossSecureStorage.Current.HasKey("WhatsAppNumberForLogin"))
                    {
                        CrossSecureStorage.Current.DeleteKey("WhatsAppNumberForLogin");
                    }
                }
                else
                {
                    CrossSecureStorage.Current.SetValue("WhatsAppNumberForLogin", value);
                }
            }
        }

        public bool UserHasWatchedWelcomeVideo
        {
            get
            {
                if (CrossSecureStorage.Current.GetValue("UserHasWatchedWelcomeVideo") == null) return false;
                return Convert.ToBoolean(CrossSecureStorage.Current.GetValue("UserHasWatchedWelcomeVideo"));
            }
            set
            {
                CrossSecureStorage.Current.SetValue("UserHasWatchedWelcomeVideo", value.ToString());
            }
        }

        public bool IsApiTokenActive()
        {
            return ApiToken != null && !string.IsNullOrEmpty(ApiToken.AccessToken) && ApiToken.Expires > DateTime.UtcNow;
        }

        public AppDataHelper(AppDataHelperSettings settings)
        {
            this.Settings = settings;
            this._api = RestService.For<IApi>(
                new HttpClient(new AppHttpClientHandler(this))
                {
                    BaseAddress = new Uri(Constants.EndpointUri)
                }
            );

            this._db = new LocalDatabase();
        }

        public async Task SetFacebookLogin(string facebookUserID, string facebookAuthToken, string facebookAppID)
        {
            LoginInfo = new FetchTokenRequest(facebookAppID + "_" + facebookUserID, facebookAuthToken);
        }

        public async Task SetWhatsAppLogin(string whatsAppNumber, int languageNodeID, string verificationCode)
        {
            LoginInfo = new FetchTokenRequest($"WHATSAPP:{languageNodeID}:{whatsAppNumber}", verificationCode);
        }

        public async Task<bool> HasAccountCompletedFirstCourse(int languageNodeID)
        {
            // First check if we have any courses downloaded - if not, download the first course
            if (!_db.GetCourses(languageNodeID).Any())
            {
                await SyncCourses(languageNodeID);
            }

            // If we still have no courses, then return false
            if (!_db.GetCourses(languageNodeID).Any()) return false;

            return _db.GetCourses(languageNodeID).OrderBy(c => c.SortOrder).FirstOrDefault().DateCompleted != null;
        }

        /// <summary>
        /// Call this ONLY when logging in on a device for the first time
        /// </summary>
        /// <returns></returns>
        public async Task<Account> LoadAccountDataFromAPI(Account currentAccount)
        {
            // Perform a simple request for the account data from the API
            // Handle the "refresh_token" code here
            try
            {
                var account = await _api.GetAccount();

                currentAccount.DateCompletedAllCourses = account.DateCompletedAllCourses;
                currentAccount.DateCompletedOnboarding = account.DateCompletedOnboarding;
                currentAccount.DateCreated = account.DateCreated;
                currentAccount.EnablePushNotifications = account.EnablePushNotifications;
                currentAccount.EnableTextNotifications = account.EnableTextNotifications;
                currentAccount.Source = account.Source;
                currentAccount.WhatsAppNumber = account.WhatsAppNumber;

                await SaveAccount(currentAccount);

                return currentAccount;
            }
            catch (Refit.ApiException ex)
            {
                // If we're able to deserialize the response, we have a "handled" error
                // Handle the "refresh_token" code here - this is sent back when the API server believes a token refresh is in order
                try
                {
                    var errorResponse = JsonConvert.DeserializeObject<HandledExceptionData>(ex.Content);
                    switch (APIHandledExceptionCodeEnumManager.FromString(errorResponse.code))
                    {
                        case APIHandledExceptionCodeEnum.RefreshToken:
                            var response = await RefreshToken();
                            return await LoadAccountDataFromAPI(currentAccount);
                        default:
                            // if we have a different error, throw a new exception with the message we got back, adding original exception as an inner exception
                            throw new Exception(errorResponse.message, ex);
                    }
                }
                catch
                {
                    // if we fail to deserialize, throw the original exception
                    throw ex;
                }
            }
            catch (Exception ex)
            {
                // All other exception types, throw 'em
                throw ex;
            }
        }

        public Task<FetchTokenResponse> RefreshToken()
        {
            return Task.Run(async () =>
            {
                var response = await _api.FetchToken(LoginInfo);

                this.ApiToken = response;

                return this.ApiToken;
            });
        }

        public void ClearToken()
        {
            this.ApiToken = null;
        }

        public void ClearData()
        {
            this._db.DeleteAllData();
        }

        public async Task<Account> GetAccount(int languageNodeID, string currentAccountSource = null, string currentName = null, string currentFacebookProfileImageURL = null)
        {
            var account = _db.GetAccount(languageNodeID);

            if (!account.IsSynced && account.HasAuthenticated)
            {
                var apiAccount = await _api.GetAccount();
                apiAccount.CopyPropertiesTo(account);
            }

            // Update Name and Profile Image if passed
            bool save = false;
            if (!string.IsNullOrEmpty(currentName) && currentName != account.Name)
            {
                account.Name = currentName;
                save = true;
            }
            if (!string.IsNullOrEmpty(currentFacebookProfileImageURL) && currentFacebookProfileImageURL != account.FacebookProfileImageURL)
            {
                account.FacebookProfileImageURL = currentFacebookProfileImageURL;
                save = true;
            }
            if (!string.IsNullOrEmpty(currentAccountSource) && account.Source != currentAccountSource)
            {
                account.Source = currentAccountSource;
                save = true;
            }
            if (save)
                await SaveAccount(account);

            return account;
        }

        public async Task SaveAccount(Account account)
        {
            _db.SaveObject(account);
            if (!await this.IsOffline() && account.HasAuthenticated)
            {
                var apiAccount = new Account();
                account.CopyPropertiesTo(apiAccount);

                var response = await _api.SaveAccount(apiAccount);
                if (!response.success) throw new Exception(response.message);

                account.IsSynced = true;
                _db.SaveObject(account);
            }
        }

        public async Task SaveData(ISyncable obj, Account currentAccount)
        {
            obj.NeedsSync = true;
            _db.SaveObject(obj);

            if (currentAccount.HasAuthenticated)
            {
                // Sync all objects to the API
                foreach (var lessonItem in _db.GetLessonItemData().Where(i => i.NeedsSync))
                {
                    await lessonItem.Sync(_api);
                    lessonItem.LastStatusSync = DateTime.UtcNow;
                    lessonItem.NeedsSync = false;
                    _db.SaveObject(lessonItem);
                }
                foreach (var lesson in _db.GetLessonData().Where(i => i.NeedsSync))
                {
                    await lesson.Sync(_api);
                    lesson.LastStatusSync = DateTime.UtcNow;
                    lesson.NeedsSync = false;
                    _db.SaveObject(lesson);
                }
                foreach (var course in _db.GetCourseData().Where(i => i.NeedsSync))
                {
                    await course.Sync(_api);
                    course.LastStatusSync = DateTime.UtcNow;
                    course.NeedsSync = false;
                    _db.SaveObject(course);
                }
            }
        }

        public async Task ResetStatuses()
        {
            foreach (var lessonItem in _db.GetLessonItemData())
            {
                lessonItem.DateCompleted = DateTime.MinValue;
                try
                {
                    await lessonItem.Sync(_api);
                }
                catch (Exception ex)
                {
                    // Do nothing - maybe this item doesn't exist anymore
                    System.Diagnostics.Debug.WriteLine($"Lesson Item {lessonItem.LessonItemNodeID} reset failed: " + ex.ToString());
                }
                lessonItem.DateCompleted = null;
                _db.SaveObject(lessonItem);
            }
            foreach (var lesson in _db.GetLessonData())
            {
                lesson.DateCompletedAllLessonItems = DateTime.MinValue;
                lesson.DateCompletedQuiz = DateTime.MinValue;
                lesson.DateStarted = DateTime.MinValue;
                lesson.DateWatchedVideo = DateTime.MinValue;
                try
                {
                    await lesson.Sync(_api);
                }
                catch (Exception ex)
                {
                    // Do nothing - maybe this item doesn't exist anymore
                    System.Diagnostics.Debug.WriteLine($"Lesson {lesson.LessonNodeID} reset failed: " + ex.ToString());
                }
                lesson.DateCompletedAllLessonItems = null;
                lesson.DateCompletedQuiz = null;
                lesson.DateStarted = null;
                lesson.DateWatchedVideo = null;
                _db.SaveObject(lesson);
            }
            foreach (var course in _db.GetCourseData())
            {
                course.DateStarted = DateTime.MinValue;
                course.DateCompleted = DateTime.MinValue;
                try
                {
                    await course.Sync(_api);
                }
                catch (Exception ex)
                {
                    // Do nothing - maybe this item doesn't exist anymore
                    System.Diagnostics.Debug.WriteLine($"Course {course.CourseNodeID} reset failed: " + ex.ToString());
                }
                course.DateStarted = null;
                course.DateCompleted = null;
                _db.SaveObject(course);
            }
        }

        public async Task<OnboardingResponse> GetOnboarding(int languageNodeID)
        {
            var onboarding = await _api.GetOnboarding(languageNodeID);

            return onboarding;
        }

        public IEnumerable<Course> GetCoursesFromDB(int languageNodeID)
        {
            return _db.GetCourses(languageNodeID);
        }


        public async Task<IEnumerable<LanguageResponse>> GetLanguages()
        {
            var languages = await _api.GetLanguages();

            return languages;
        }

        /// <summary>
        /// Retrieve all of the courses data and save in local database, then post empty course statuses via the API to let them know which courses we downloaded.
        /// </summary>
        /// <returns></returns>
        public async Task SyncCourses(int languageNodeID)
        {
            var account = await GetAccount(languageNodeID, null);
            IEnumerable<Course> courses;
            if (account.HasAuthenticated)
            {
                courses = await _api.GetCourses(account.LanguageNodeID ?? 0);
            }
            else
            {
                courses = await _api.GetFirstCourse(account.LanguageNodeID ?? 0);
            }

            int cOrder = 1, lOrder, qOrder, aOrder, iOrder;
            foreach (var course in courses.OrderBy(c => c.SortOrder))
            {
                // Find any existing course of the same type
                var existingCourse = _db.GetCourseData().Where(c => c.CourseType == course.CourseType).FirstOrDefault();

                // If we found this course, check the ID - if it's a different ID, delete the existing course
                if (existingCourse != null && existingCourse.CourseNodeID != course.CourseNodeID)
                {
                    _db.DeleteCourse(existingCourse);
                    existingCourse = null;
                }

                // if we already have this course downloaded, update its sort order
                // else create the course and its lessons
                if (existingCourse != null)
                {
                    course.SortOrder = cOrder++;
                    _db.SaveObject(existingCourse);
                }
                else
                {
                    lOrder = 1;
                    course.SortOrder = cOrder++;
                    course.DateDownloaded = DateTime.UtcNow;
                    _db.SaveObject(course);
                    foreach (var lesson in course.Lessons.OrderBy(l => l.SortOrder))
                    {
                        iOrder = 1;
                        qOrder = 1;
                        lesson.SortOrder = lOrder++;
                        _db.SaveObject(lesson);
                        foreach (var lessonItem in lesson.LessonItems.OrderBy(i => i.SortOrder))
                        {
                            lessonItem.SortOrder = iOrder++;
                            _db.SaveObject(lessonItem);
                        }
                        foreach (var question in lesson.Questions.OrderBy(q => q.SortOrder))
                        {
                            aOrder = 1;
                            question.SortOrder = qOrder++;
                            _db.SaveObject(question);
                            foreach (var answer in question.Answers.OrderBy(a => a.SortOrder))
                            {
                                answer.SortOrder = aOrder++;
                                _db.SaveObject(answer);
                            }
                        }
                    }
                }
            }

            if (account.HasAuthenticated)
            {
                account.HasDownloadedAllCourses = true;
                await SaveAccount(account);
                // sync the course status to denote the version (node id) downloaded
                foreach (var course in _db.GetCourses(languageNodeID).OrderBy(c => c.SortOrder))
                {
                    try
                    {
                        await course.Sync(_api);
                    }
                    catch (Exception ex)
                    {
                        throw ex;
                    }
                }
            }
        }

        public async Task SyncEncouragementMessages(int languageNodeID)
        {
            _db.ClearEncouragementMessages();
            try
            {
                var messages = await _api.GetEncouragementMessages(languageNodeID);
                foreach (var message in messages)
                {
                    _db.SaveObject(message);
                }
            }
            catch(Exception ex)
            {
                // leave the table empty
            }
        }

        public IEnumerable<EncouragementMessage> GetEncouragementMessages()
        {
            return _db.GetEncouragementMessages();
        }

        public async Task<EncouragementMessage> GetRandomEncouragementMessage(int languageNodeID)
        {
            var messages = _db.GetEncouragementMessages().Where(m => !m.DontRandomize);
            var count = messages.Count();
            // If we have no encouragement messages, attempt to re-sync based on the specified language
            // If we still have zero after that, then return the default encouragement message stored in the Settings object
            if (count == 0)
            {
                await this.SyncEncouragementMessages(languageNodeID);
                messages = _db.GetEncouragementMessages().Where(m => !m.DontRandomize);
                count = messages.Count();
                if (count == 0)
                {
                    return new EncouragementMessage() { Message = this.Settings.DefaultEncouragementMessage };
                }
            }

            // Randomly choose an encouragement message
            var rand = new Random();
            var index = rand.Next(0, count - 1);
            return messages.Skip(index).FirstOrDefault();
        }

        public void SendWhatsAppVerificationCode(int languageNodeID, string whatsAppNumber)
        {
            _api.WhatsAppVerification(new WhatsAppVerificationRequest()
            {
                LanguageNodeID = languageNodeID,
                WhatsAppNumber = whatsAppNumber
            });
        }
    }
}
