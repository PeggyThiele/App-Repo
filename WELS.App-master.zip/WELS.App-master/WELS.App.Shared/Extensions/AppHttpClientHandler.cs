﻿using Plugin.SecureStorage;
using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using WELS.App.Shared.Exceptions;
using WELS.App.Shared.Helpers;
using Newtonsoft.Json;

namespace WELS.App.Shared.Extensions
{
    public class AppHttpClientHandler : HttpClientHandler
    {
        private AppDataHelper _dataHelper;
        public AppHttpClientHandler(AppDataHelper dataHelper) : base()
        {
            _dataHelper = dataHelper;
        }

        protected override async Task<HttpResponseMessage> SendAsync(HttpRequestMessage request, CancellationToken cancellationToken)
        {
            if (request.RequestUri.PathAndQuery != "/oauth/token"
                && request.RequestUri.PathAndQuery != "/api/ping"
                && request.RequestUri.PathAndQuery != "/api/languages"
                && request.RequestUri.PathAndQuery != "/api/whatsappverification"
                && !request.RequestUri.PathAndQuery.EndsWith("/encouragement-messages")
                && !request.RequestUri.PathAndQuery.EndsWith("/courses/first"))
            {
                var token = _dataHelper.ApiToken;
                if (token == null || token.Expires < DateTime.UtcNow)
                {
                    token = await _dataHelper.RefreshToken();
                }
                if (token != null)
                {
                    request.Headers.Add("Authorization", string.Format("Bearer {0}", token.AccessToken));
                }
            }
            return await base.SendAsync(request, cancellationToken);
        }
    }
}
