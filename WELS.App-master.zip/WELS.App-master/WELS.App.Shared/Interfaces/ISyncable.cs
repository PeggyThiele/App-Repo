﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace WELS.App.Shared.Interfaces
{
    public interface ISyncable
    {
        DateTime? LastStatusSync { get; set; }
        bool NeedsSync { get; set; }
        Task Sync(IApi api);
    }
}
