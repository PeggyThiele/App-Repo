﻿using Refit;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using WELS.App.Shared.Models.Request;
using WELS.App.Shared.Models.Response;
using WELS.App.Shared.Data;

namespace WELS.App.Shared.Interfaces
{
    public interface IApi
    {
        [Post("/oauth/token")]
        Task<FetchTokenResponse> FetchToken([Body(BodySerializationMethod.UrlEncoded)] FetchTokenRequest request);

        [Get("/api/ping")]
        Task<PingResponse> Ping();

        [Post("/api/account")]
        Task<SuccessResponse> SaveAccount([Body(BodySerializationMethod.UrlEncoded)] Account request);

        [Get("/api/account")]
        Task<Account> GetAccount();

        [Get("/api/languages")]
        Task<IEnumerable<LanguageResponse>> GetLanguages();

        [Get("/api/languages/{id}/on-boarding")]
        Task<OnboardingResponse> GetOnboarding([AliasAs("id")] int languageNodeID);

        [Get("/api/languages/{id}/courses/?recursive=1")]
        Task<IEnumerable<Course>> GetCourses([AliasAs("id")] int languageNodeID);

        [Get("/api/languages/{id}/courses/first")]
        Task<IEnumerable<Course>> GetFirstCourse([AliasAs("id")] int languageNodeID);

        [Post("/api/lesson-items/{id}/status")]
        Task<SuccessResponse> SaveLessonItemStatus([AliasAs("id")] int lessonItemNodeID, [Body(BodySerializationMethod.UrlEncoded)] LessonItemStatusRequest request);

        [Post("/api/lessons/{id}/status")]
        Task<SuccessResponse> SaveLessonStatus([AliasAs("id")] int lessonNodeID, [Body(BodySerializationMethod.UrlEncoded)] LessonStatusRequest request);

        [Post("/api/courses/{id}/status")]
        Task<SuccessResponse> SaveCourseStatus([AliasAs("id")] int courseNodeID, [Body(BodySerializationMethod.UrlEncoded)] CourseStatusRequest request);

        [Get("/api/languages/{id}/encouragement-messages")]
        Task<IEnumerable<EncouragementMessage>> GetEncouragementMessages([AliasAs("id")] int languageNodeID);

        [Post("/api/whatsappverification")]
        Task<SuccessResponse> WhatsAppVerification([Body(BodySerializationMethod.UrlEncoded)] WhatsAppVerificationRequest request);
    }
}
