﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WELS.App.Shared.Models.Response
{
    public class SuccessResponse
    {
        public bool success { get; set; }
        public string message { get; set; }
    }
}
