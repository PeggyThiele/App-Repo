﻿using System;
using System.Collections.Generic;
using WELS.App.Shared.Interfaces;

namespace WELS.App.Shared.Models.Response
{
    public class OnboardingResponse
    {
        public int CurrentTotalScore { get; set; }
        public List<OnboardingVideoResponse> Videos { get; set; }
        public List<OnboardingQuestionResponse> Questions { get; set; }
    }
}
