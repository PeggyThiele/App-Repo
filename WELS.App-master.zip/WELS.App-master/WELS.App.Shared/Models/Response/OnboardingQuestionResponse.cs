﻿using System;
using System.Collections.Generic;
using WELS.App.Shared.Interfaces;

namespace WELS.App.Shared.Models.Response
{
    public class OnboardingQuestionResponse
    {
        public string QuestionText { get; set; }
        public int QuestionNodeID { get; set; }
        public int? CurrentAnswerNodeID { get; set; }
        public List<OnboardingQuestionAnswerResponse> Answers { get; set; }
    }
}
