﻿using Newtonsoft.Json;
using System;

namespace WELS.App.Shared.Models.Response
{
    public class FetchTokenResponse
    {
        [JsonProperty(PropertyName = "access_token")]
        public string AccessToken { get; set; }

        [JsonProperty(PropertyName = ".issued")]
        public DateTime Issued { get; set; }

        [JsonProperty(PropertyName = ".expires")]
        public DateTime Expires { get; set; }
    }
}
