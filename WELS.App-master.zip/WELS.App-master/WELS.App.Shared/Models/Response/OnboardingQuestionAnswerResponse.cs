﻿using System;
using System.Collections.Generic;
using WELS.App.Shared.Interfaces;

namespace WELS.App.Shared.Models.Response
{
    public class OnboardingQuestionAnswerResponse
    {
        public string AnswerText { get; set; }
        public int AnswerNodeID { get; set; }
        public int Score { get; set; }
    }
}
