﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WELS.App.Shared.Models.Response
{
    public class LanguageResponse
    {
        public int LanguageNodeID { get; set; }
        public string Name { get; set; }
        public string CultureCode { get; set; }
        public string ForumLinkURL { get; set; }
        public string WelcomeVideoURL { get; set; }
    }
}
