﻿using System;
using WELS.App.Shared.Interfaces;

namespace WELS.App.Shared.Models.Response
{
    public class OnboardingVideoResponse
    {
        public string VideoURL { get; set; }
        public int MinimumScore { get; set; }
    }
}
