﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WELS.App.Shared.Models.Response
{
    public class PingResponse
    {
        public bool success { get; set; }
    }
}
