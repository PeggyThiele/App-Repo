﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WELS.App.Shared.Models.Request
{
    public class CourseStatusRequest
    {
        public DateTime? DateStarted { get; set; }
        public DateTime? DateCompleted { get; set; }
        public DateTime? DateDownloaded { get; set; }
    }
}
