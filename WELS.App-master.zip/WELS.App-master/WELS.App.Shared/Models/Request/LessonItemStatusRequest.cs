﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WELS.App.Shared.Models.Request
{
    public class LessonItemStatusRequest
    {
        public DateTime? DateCompleted { get; set; }
    }
}
