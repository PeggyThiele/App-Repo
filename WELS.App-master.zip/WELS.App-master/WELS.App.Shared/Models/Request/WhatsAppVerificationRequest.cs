﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WELS.App.Shared.Models.Request
{
    public class WhatsAppVerificationRequest
    {
        public int LanguageNodeID { get; set; }
        public string WhatsAppNumber { get; set; }
    }
}
