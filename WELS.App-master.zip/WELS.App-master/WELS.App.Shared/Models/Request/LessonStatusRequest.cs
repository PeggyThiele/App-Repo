﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WELS.App.Shared.Models.Request
{
    public class LessonStatusRequest
    {
        public DateTime? DateStarted { get; set; }
        public DateTime? DateWatchedVideo { get; set; }
        public DateTime? DateCompletedAllLessonItems { get; set; }
        public DateTime? DateCompletedQuiz { get; set; }
    }
}
