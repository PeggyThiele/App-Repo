﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WELS.App.Shared.Exceptions
{
    public enum APIHandledExceptionCodeEnum
    {
        Unknown,
        RefreshToken
    }

    public class APIHandledExceptionCodeEnumManager
    {
        private static Dictionary<string, APIHandledExceptionCodeEnum> _codeLookup = new Dictionary<string, APIHandledExceptionCodeEnum>()
        {
            { "refresh_token", APIHandledExceptionCodeEnum.RefreshToken }
        };
        public static APIHandledExceptionCodeEnum FromString(string code)
        {
            if (_codeLookup.ContainsKey(code))
            {
                return _codeLookup[code];
            }
            else
            {
                return APIHandledExceptionCodeEnum.Unknown;
            }
        }
    }
}
