﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WELS.App.Shared.Exceptions
{
    public class HandledExceptionData
    {
        public bool success { get; set; }
        public string message { get; set; }
        public string code { get; set; }
    }
}
